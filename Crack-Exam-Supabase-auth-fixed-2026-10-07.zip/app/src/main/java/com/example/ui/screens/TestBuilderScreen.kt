package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*
import com.example.viewmodel.CrackExamViewModel
import com.example.viewmodel.ScreenDestination

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TestBuilderScreen(
    viewModel: CrackExamViewModel,
    modifier: Modifier = Modifier
) {
    val tests by viewModel.tests.collectAsState()
    val folders by viewModel.testFolders.collectAsState()
    val questionBank by viewModel.questionBank.collectAsState()

    var activeTab by remember { mutableStateOf("Tests") } // "Tests", "Folders", "CreateQuestion", "Lifecycle"
    var showCreateTestModal by remember { mutableStateOf(false) }
    var showCreateFolderModal by remember { mutableStateOf(false) }
    var showAddQuestionModal by remember { mutableStateOf(false) }
    var testToDelete by remember { mutableStateOf<ExamTest?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NeutralBg)
    ) {
        // Toolbar
        Surface(
            color = BrandNavyDark,
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { viewModel.navigateTo(ScreenDestination.Home) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "एडवांस्ड टेस्ट बिल्डर (Advanced Test Builder)",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                            Text(
                                text = "Draft → Review → Approved → Published → Scheduled → Archived",
                                fontSize = 10.sp,
                                color = BrandAmberPrimary
                            )
                        }
                    }

                    Button(
                        onClick = { showCreateTestModal = true },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandAmberPrimary, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("tb_create_test_btn")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("नया टेस्ट", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Navigation Tabs
                val tabs = listOf("Tests", "Folders", "CreateQuestion", "Lifecycle")
                ScrollableTabRow(
                    selectedTabIndex = tabs.indexOf(activeTab),
                    edgePadding = 0.dp,
                    containerColor = Color.Transparent,
                    divider = {}
                ) {
                    tabs.forEach { tab ->
                        val isSelected = activeTab == tab
                        Tab(
                            selected = isSelected,
                            onClick = { activeTab = tab },
                            text = {
                                Text(
                                    text = when (tab) {
                                        "Tests" -> "टेस्ट प्रबंधन (${tests.size})"
                                        "Folders" -> "फोल्डर्स (${folders.size})"
                                        "CreateQuestion" -> "प्रश्न निर्माण"
                                        else -> "लाइफसाइकिल"
                                    },
                                    color = if (isSelected) BrandAmberPrimary else Color(0xFFCBD5E1),
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 12.sp
                                )
                            }
                        )
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (activeTab) {
                "Tests" -> {
                    items(tests) { test ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            shape = RoundedCornerShape(14.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        color = when (test.lifecycleStatus) {
                                            TestLifecycleStatus.PUBLISHED -> EmeraldLight
                                            TestLifecycleStatus.DRAFT -> SurfaceVariantCard
                                            TestLifecycleStatus.REVIEW -> BrandAmberLight
                                            TestLifecycleStatus.ARCHIVED -> RoseLight
                                            else -> BlueLight
                                        },
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = test.lifecycleStatus.name,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = when (test.lifecycleStatus) {
                                                TestLifecycleStatus.PUBLISHED -> EmeraldSuccess
                                                TestLifecycleStatus.DRAFT -> TextSecondary
                                                TestLifecycleStatus.REVIEW -> BrandNavyDark
                                                TestLifecycleStatus.ARCHIVED -> RoseError
                                                else -> BlueInfo
                                            },
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }

                                    Row {
                                        IconButton(
                                            onClick = { viewModel.duplicateTest(test.id) },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate", tint = BlueInfo, modifier = Modifier.size(18.dp))
                                        }
                                        IconButton(
                                            onClick = { testToDelete = test },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = RoseError, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Text(test.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextPrimary)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "अवधि: ${test.durationMinutes} मिनट • प्रश्न: ${test.questions.size} • कुल अंक: ${test.totalMarks.toInt()} • नेगेटिव: 1/${(1.0 / test.negativeMarkRatio).toInt()}",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = { viewModel.startLiveTest(test) },
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Preview", fontSize = 11.sp)
                                    }

                                    Button(
                                        onClick = {
                                            val next = if (test.lifecycleStatus == TestLifecycleStatus.PUBLISHED) TestLifecycleStatus.ARCHIVED else TestLifecycleStatus.PUBLISHED
                                            viewModel.updateTestLifecycle(test.id, next)
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (test.lifecycleStatus == TestLifecycleStatus.PUBLISHED) BrandNavyLight else EmeraldSuccess
                                        ),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(
                                            if (test.lifecycleStatus == TestLifecycleStatus.PUBLISHED) "Archive" else "Publish",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                "Folders" -> {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("टेस्ट व प्रश्न फोल्डर्स (${folders.size})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Button(
                                onClick = { showCreateFolderModal = true },
                                colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.CreateNewFolder, contentDescription = null, modifier = Modifier.size(16.dp), tint = BrandAmberPrimary)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("नया फोल्डर", fontSize = 11.sp, color = BrandAmberPrimary)
                            }
                        }
                    }

                    items(folders) { fld ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Folder, contentDescription = null, tint = BrandAmberPrimary, modifier = Modifier.size(24.dp))
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(fld.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("${fld.category} • ${fld.itemCount} सामग्री", fontSize = 11.sp, color = TextSecondary)
                                    }
                                }
                                IconButton(onClick = { viewModel.deleteTestFolder(fld.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete Folder", tint = RoseError, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }

                "CreateQuestion" -> {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("प्रश्न निर्माण स्रोत (Question Sources)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("1. Manual Entry • 2. Bulk Text Import • 3. OCR Image • 4. AI Engine", fontSize = 12.sp, color = TextSecondary)
                                Spacer(modifier = Modifier.height(14.dp))

                                Button(
                                    onClick = { showAddQuestionModal = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, tint = BrandAmberPrimary)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("मैनुअल नया प्रश्न बनाएं (Create Question)", color = BrandAmberPrimary, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    item {
                        Text("वर्तमान में बैंक में उपलब्ध प्रश्न: ${questionBank.size}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    items(questionBank.take(5)) { q ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("${q.subject} • ${q.chapter}", fontSize = 10.sp, color = TextSecondary)
                                    Surface(color = if (q.isAiGenerated) BrandAmberLight else SurfaceVariantCard, shape = RoundedCornerShape(4.dp)) {
                                        Text(if (q.isAiGenerated) "AI Draft" else "Manual", fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(3.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(q.questionHindi, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }

                "Lifecycle" -> {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("टेस्ट व प्रश्न लाइफसाइकिल अनुक्रम", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("1. DRAFT → टेस्ट या प्रश्न तैयार होता है।", fontSize = 12.sp)
                                Text("2. REVIEW → विषय विशेषज्ञ द्वारा प्रूफ-रीड।", fontSize = 12.sp)
                                Text("3. APPROVED → परीक्षा समिति द्वारा स्वीकृत।", fontSize = 12.sp)
                                Text("4. PUBLISHED → छात्र डैशबोर्ड पर सक्रिय।", fontSize = 12.sp, color = EmeraldSuccess, fontWeight = FontWeight.Bold)
                                Text("5. ARCHIVED → परीक्षा पूर्ण होने पर संग्रहीत।", fontSize = 12.sp, color = TextSecondary)
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal: Create Test
    if (showCreateTestModal) {
        var testTitle by remember { mutableStateOf("") }
        var duration by remember { mutableStateOf("90") }
        var marks by remember { mutableStateOf("100") }

        AlertDialog(
            onDismissRequest = { showCreateTestModal = false },
            title = { Text("नया परीक्षा टेस्ट बनाएं", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = testTitle, onValueChange = { testTitle = it }, label = { Text("टेस्ट शीर्षक (Title)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = duration, onValueChange = { duration = it }, label = { Text("अवधि (मिनट)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = marks, onValueChange = { marks = it }, label = { Text("कुल अंक") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (testTitle.isNotBlank()) {
                            val newT = ExamTest(
                                id = "TEST-${System.currentTimeMillis()}",
                                examCategory = ExamCategory.RAILWAY,
                                testSeriesId = "TS-RRB-01",
                                title = testTitle,
                                description = "TCS 2026 Examination pattern compliant test created via Test Builder.",
                                durationMinutes = duration.toIntOrNull() ?: 90,
                                totalQuestions = 5,
                                totalMarks = marks.toDoubleOrNull() ?: 100.0,
                                negativeMarkRatio = 0.33,
                                languages = listOf("Hindi", "English"),
                                sections = listOf("Mathematics", "Reasoning", "General Awareness"),
                                questions = viewModel.repository.questionBank.value.take(5),
                                status = ReviewStatus.PUBLISHED,
                                lifecycleStatus = TestLifecycleStatus.PUBLISHED
                            )
                            viewModel.createNewTest(newT)
                            showCreateTestModal = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark)
                ) { Text("सुरक्षित करें", color = BrandAmberPrimary) }
            },
            dismissButton = { TextButton(onClick = { showCreateTestModal = false }) { Text("रद्द करें") } }
        )
    }

    // Modal: Create Folder
    if (showCreateFolderModal) {
        var fldName by remember { mutableStateOf("") }
        var cat by remember { mutableStateOf("Exam") }

        AlertDialog(
            onDismissRequest = { showCreateFolderModal = false },
            title = { Text("नया फोल्डर बनाएं", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = fldName, onValueChange = { fldName = it }, label = { Text("फोल्डर का नाम") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = cat, onValueChange = { cat = it }, label = { Text("श्रेणी (Exam / Question / TestSeries)") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (fldName.isNotBlank()) {
                            viewModel.addTestFolder(TestFolder(id = "FLD-${System.currentTimeMillis()}", name = fldName, category = cat, itemCount = 0))
                            showCreateFolderModal = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark)
                ) { Text("फोल्डर बनाएं", color = BrandAmberPrimary) }
            },
            dismissButton = { TextButton(onClick = { showCreateFolderModal = false }) { Text("रद्द करें") } }
        )
    }

    // Modal: Add Question
    if (showAddQuestionModal) {
        var qText by remember { mutableStateOf("") }
        var optA by remember { mutableStateOf("") }
        var optB by remember { mutableStateOf("") }
        var explanation by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddQuestionModal = false },
            title = { Text("नया प्रश्न जोड़ें", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = qText, onValueChange = { qText = it }, label = { Text("प्रश्न (Hindi)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = optA, onValueChange = { optA = it }, label = { Text("विकल्प A") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = optB, onValueChange = { optB = it }, label = { Text("विकल्प B (सही)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = explanation, onValueChange = { explanation = it }, label = { Text("व्याख्या (Explanation)") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (qText.isNotBlank()) {
                            val newQ = Question(
                                id = "QB-${System.currentTimeMillis()}",
                                questionHindi = qText,
                                questionEnglish = qText,
                                optionsHindi = listOf(optA.ifBlank { "Option A" }, optB.ifBlank { "Option B" }, "Option C", "Option D"),
                                optionsEnglish = listOf("Option A", "Option B", "Option C", "Option D"),
                                correctOptionIndices = listOf(1),
                                explanationHindi = explanation.ifBlank { "Correct explanation" },
                                explanationEnglish = explanation.ifBlank { "Correct explanation" },
                                subject = "General Awareness",
                                chapter = "Mock Series",
                                topic = "Test Builder Q",
                                difficulty = "Medium",
                                marks = 2.0,
                                negativeMarks = 0.66,
                                reviewStatus = ReviewStatus.PUBLISHED
                            )
                            viewModel.addQuestionToBank(newQ)
                            showAddQuestionModal = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark)
                ) { Text("जोड़ें", color = BrandAmberPrimary) }
            },
            dismissButton = { TextButton(onClick = { showAddQuestionModal = false }) { Text("रद्द करें") } }
        )
    }

    // Safe Delete Confirmation Dialog
    testToDelete?.let { t ->
        AlertDialog(
            onDismissRequest = { testToDelete = null },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = RoseError) },
            title = { Text("सुरक्षित टेस्ट निष्कासन (Safe Delete)", fontWeight = FontWeight.Bold) },
            text = {
                Text("क्या आप निश्चित रूप से '${t.title}' को हटाना चाहते हैं? यह टेस्ट सभी एक्टिव मॉक लिस्टिंग से सुरक्षित रूप से हटा दिया जाएगा।")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteTest(t.id)
                        testToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoseError)
                ) {
                    Text("हां, टेस्ट हटाएं", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { testToDelete = null }) { Text("रद्द करें") }
            }
        )
    }
}

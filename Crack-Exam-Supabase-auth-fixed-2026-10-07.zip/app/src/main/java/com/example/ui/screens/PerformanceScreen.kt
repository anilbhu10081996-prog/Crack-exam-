package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.CrackExamViewModel
import com.example.viewmodel.ScreenDestination

@Composable
fun PerformanceScreen(
    viewModel: CrackExamViewModel,
    modifier: Modifier = Modifier
) {
    val user by viewModel.currentUser.collectAsState()
    val results by viewModel.results.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NeutralBg)
    ) {
        // Toolbar
        Surface(
            color = SurfaceCard,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.Home) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "प्रदर्शन विश्लेषण (Performance Analytics)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = BrandNavyDark
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Overall Stats
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("समग्र प्रगति (Overall Overview)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = BrandNavyDark)
                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            PerfBox("सटीकता (Accuracy)", "${user.accuracyPercentage}%", EmeraldSuccess)
                            PerfBox("औसत स्कोर (Avg)", "84.2", BrandAmberPrimary)
                            PerfBox("स्पीड (Speed)", "42s / Q", BlueInfo)
                            PerfBox("रैंक (Rank)", "#${user.overallRank}", PurpleAccent)
                        }
                    }
                }
            }

            // Subject-wise Breakdown
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("विषयवार दक्षता (Subject Mastery)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = BrandNavyDark)
                        Spacer(modifier = Modifier.height(12.dp))

                        SubjectBar("गणित (Mathematics)", 0.88f, EmeraldSuccess)
                        SubjectBar("तर्कशक्ति (Reasoning)", 0.92f, EmeraldSuccess)
                        SubjectBar("सामान्य विज्ञान (General Science)", 0.74f, BrandAmberPrimary)
                        SubjectBar("सामान्य अध्ययन (Polity & GS)", 0.68f, RoseError)
                    }
                }
            }

            // Past Test Attempts History
            item {
                Text("हाल के टेस्ट प्रयास (Recent Attempts)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = BrandNavyDark)
            }

            items(results) { res ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(res.testTitle, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                            Text("स्कोर: ${String.format("%.1f", res.scoredMarks)}/${res.totalMarks.toInt()} • रैंक: #${res.rank}", fontSize = 11.sp, color = TextSecondary)
                        }

                        Surface(
                            color = EmeraldLight,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "${String.format("%.1f", res.accuracyPercentage)}% सटीकता",
                                color = EmeraldSuccess,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PerfBox(title: String, stat: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(stat, fontWeight = FontWeight.Black, fontSize = 16.sp, color = color)
        Text(title, fontSize = 10.sp, color = TextSecondary)
    }
}

@Composable
fun SubjectBar(subject: String, progress: Float, color: Color) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(subject, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text("${(progress * 100).toInt()}%", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = color,
            trackColor = SurfaceVariantCard
        )
    }
}

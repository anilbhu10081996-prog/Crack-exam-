package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Question
import com.example.ui.theme.*
import com.example.viewmodel.CrackExamViewModel
import com.example.viewmodel.ScreenDestination

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuestionBankScreen(
    viewModel: CrackExamViewModel,
    modifier: Modifier = Modifier
) {
    val questions by viewModel.questionBank.collectAsState()
    var selectedSubject by remember { mutableStateOf("All") }
    var bookmarkedSet by remember { mutableStateOf(setOf<String>()) }
    var expandedSolutionId by remember { mutableStateOf<String?>(null) }

    val subjects = listOf("All", "General Awareness", "Mathematics", "General Science", "Reasoning Ability")
    val filteredQuestions = if (selectedSubject == "All") {
        questions
    } else {
        questions.filter { it.subject.equals(selectedSubject, ignoreCase = true) }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NeutralBg)
    ) {
        // Toolbar
        Surface(
            color = SurfaceCard,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.Home) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "प्रश्न बैंक (Question Bank & Folders)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = BrandNavyDark
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Subject filters
                ScrollableTabRow(
                    selectedTabIndex = subjects.indexOf(selectedSubject),
                    edgePadding = 0.dp,
                    containerColor = Color.Transparent,
                    divider = {}
                ) {
                    subjects.forEach { subj ->
                        val isSelected = selectedSubject == subj
                        Tab(
                            selected = isSelected,
                            onClick = { selectedSubject = subj },
                            text = {
                                Text(
                                    text = subj,
                                    color = if (isSelected) BrandAmberPrimary else TextSecondary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        )
                    }
                }
            }
        }

        // Questions List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "कुल प्रश्न: ${filteredQuestions.size} अभ्यास हेतु",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )

                    Surface(
                        color = BrandAmberLight,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "TCS विगत वर्ष संकलन",
                            color = BrandNavyDark,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            items(filteredQuestions) { q ->
                val isBookmarked = bookmarkedSet.contains(q.id)
                val isSolutionExpanded = expandedSolutionId == q.id

                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = SurfaceVariantCard,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "${q.subject} • ${q.chapter}",
                                    fontSize = 11.sp,
                                    color = TextSecondary,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }

                            IconButton(
                                onClick = {
                                    bookmarkedSet = if (isBookmarked) bookmarkedSet - q.id else bookmarkedSet + q.id
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                    contentDescription = "Bookmark",
                                    tint = if (isBookmarked) BrandAmberPrimary else TextSecondary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = q.questionHindi,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Options preview
                        q.optionsHindi.forEachIndexed { optIdx, optText ->
                            val isCorrect = q.correctOptionIndices.contains(optIdx)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "(${('A' + optIdx)}) $optText",
                                    fontSize = 13.sp,
                                    color = if (isSolutionExpanded && isCorrect) EmeraldSuccess else TextPrimary,
                                    fontWeight = if (isSolutionExpanded && isCorrect) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Divider(color = Color(0xFFE2E8F0))
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(
                                onClick = {
                                    expandedSolutionId = if (isSolutionExpanded) null else q.id
                                },
                                modifier = Modifier.testTag("solution_toggle_${q.id}")
                            ) {
                                Icon(
                                    imageVector = if (isSolutionExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (isSolutionExpanded) "समाधान छिपाएं" else "विस्तृत व्याख्या देखें")
                            }

                            Surface(
                                color = EmeraldLight,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "+${q.marks} Marks",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldSuccess,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        if (isSolutionExpanded) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                color = SurfaceVariantCard,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("सटीक व्याख्या (Detailed Solution):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BrandNavyDark)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(q.explanationHindi, fontSize = 12.sp, color = TextPrimary, lineHeight = 18.sp)
                                    if (q.explanationEnglish.isNotBlank() && q.explanationEnglish != q.explanationHindi) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(q.explanationEnglish, fontSize = 11.sp, color = TextSecondary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

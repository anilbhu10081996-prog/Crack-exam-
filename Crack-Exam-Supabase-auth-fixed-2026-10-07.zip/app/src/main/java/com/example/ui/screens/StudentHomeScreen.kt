package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.ExamCategory
import com.example.ui.theme.*
import com.example.viewmodel.CrackExamViewModel
import com.example.viewmodel.ScreenDestination

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentHomeScreen(
    viewModel: CrackExamViewModel,
    modifier: Modifier = Modifier
) {
    val user by viewModel.currentUser.collectAsState()
    val selectedExam by viewModel.selectedExam.collectAsState()
    val testSeriesList by viewModel.testSeries.collectAsState()
    val liveTests by viewModel.tests.collectAsState()
    val results by viewModel.results.collectAsState()

    val lastResult = results.firstOrNull()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NeutralBg),
        contentPadding = PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. SELECTED EXAM BAR & SELECTOR (अपनी परीक्षा चुनें)
        item {
            Surface(
                color = SurfaceCard,
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "अपनी परीक्षा चुनें",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                                    color = BrandNavyDark
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = BrandAmberLight,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "Target 2026",
                                        color = BrandNavyDark,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "वर्तमान चयन: ${selectedExam.titleEnglish} (${selectedExam.titleHindi})",
                                fontSize = 11.sp,
                                color = TextSecondary,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Surface(
                            color = BrandNavyDark,
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.clickable { viewModel.navigateTo(ScreenDestination.ExamSelection) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("बदलें", fontSize = 11.sp, color = BrandAmberPrimary, fontWeight = FontWeight.Bold)
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = BrandAmberPrimary, modifier = Modifier.size(16.dp))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Horizontal Fast Switcher
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(ExamCategory.values()) { exam ->
                            val isSelected = selectedExam == exam
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.selectExam(exam) },
                                label = {
                                    Text(
                                        text = exam.titleEnglish,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = when (exam) {
                                            ExamCategory.RAILWAY -> Icons.Default.DirectionsRailway
                                            ExamCategory.SSC -> Icons.Default.MilitaryTech
                                            ExamCategory.BANKING -> Icons.Default.AccountBalance
                                            ExamCategory.POLICE -> Icons.Default.Shield
                                            ExamCategory.DEFENCE -> Icons.Default.Flight
                                            ExamCategory.UPSC -> Icons.Default.Public
                                            ExamCategory.TEACHING -> Icons.Default.School
                                            ExamCategory.STATE_EXAMS -> Icons.Default.LocationCity
                                        },
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp)
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = BrandNavyDark,
                                    selectedLabelColor = Color.White,
                                    selectedLeadingIconColor = BrandAmberPrimary,
                                    containerColor = SurfaceVariantCard,
                                    labelColor = TextPrimary
                                )
                            )
                        }
                    }
                }
            }
        }

        // 2. PREPARATION PROGRESS CARD
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clickable { viewModel.navigateTo(ScreenDestination.Performance) }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(EmeraldLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Insights, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(18.dp))
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("तैयारी की स्थिति (Preparation Progress)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("अंतिम मॉक के आधार पर विश्लेषण", fontSize = 10.sp, color = TextSecondary)
                            }
                        }
                        Text("विस्तृत विश्लेषण →", fontSize = 11.sp, color = BlueInfo, fontWeight = FontWeight.SemiBold)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        DashboardMetric("सटीकता (Accuracy)", "${user.accuracyPercentage}%", EmeraldSuccess)
                        DashboardMetric("कुल टेस्ट (Tests)", "${user.totalTestsAttempted}", BlueInfo)
                        DashboardMetric("ऑल इंडिया रैंक", "#${user.overallRank}", BrandAmberPrimary)
                        DashboardMetric("स्टडी स्ट्रीक", "${user.streakDays} दिन", PurpleAccent)
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { user.accuracyPercentage / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = EmeraldSuccess,
                        trackColor = SurfaceVariantCard
                    )
                }
            }
        }

        // 3. TODAY'S TEST HIGHLIGHT
        item {
            val todayTest = liveTests.firstOrNull { it.examCategory == selectedExam } ?: liveTests.firstOrNull()
            if (todayTest != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(RoseError)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("3. आज का टेस्ट (Today's Test)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BrandNavyDark)
                            }
                            Surface(color = RoseLight, shape = RoundedCornerShape(4.dp)) {
                                Text("LIVE TODAY", color = RoseError, fontSize = 9.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(todayTest.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextPrimary)
                        Text("${todayTest.durationMinutes} मिनट • ${todayTest.totalQuestions} प्रश्न • कुल अंक: ${todayTest.totalMarks.toInt()}", fontSize = 11.sp, color = TextSecondary)

                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { viewModel.startLiveTest(todayTest) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("today_test_start_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = BrandAmberPrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("टेस्ट शुरू करें (Start Today's Test)", color = BrandAmberPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // 4. CONTINUE LEARNING
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clickable { viewModel.navigateTo(ScreenDestination.Notes) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.HistoryEdu, contentDescription = null, tint = BlueInfo, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("4. जहां छोड़ा वहीं से पढ़ें (Continue Learning)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BrandNavyDark)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("न्यूटन के गति नियम और संवेग संरक्षण • भौतिक विज्ञान", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("6 मिनट का त्वरित रिवीजन बाकी है", fontSize = 10.sp, color = TextSecondary)
                    }
                    Button(
                        onClick = { viewModel.navigateTo(ScreenDestination.Notes) },
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceVariantCard, contentColor = BrandNavyDark),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("जारी रखें", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 5-14. COMPACT STUDENT ECOSYSTEM MODULE CARDS (Grid Order: Live Test, Test Series, Question Bank, Study Notes, Books & NCERT, AI Study, Results, Performance, Rank/Leaderboard, Subscription)
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Text(
                    text = "स्टडी एवं टेस्ट मॉड्युल्स (Crack Exam Modules)",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = BrandNavyDark
                )
                Spacer(modifier = Modifier.height(10.dp))

                val modules = listOf(
                    DashboardModule("5. Live Test", Icons.Default.LiveTv, BrandAmberPrimary) {
                        val test = liveTests.firstOrNull { it.examCategory == selectedExam } ?: liveTests.first()
                        viewModel.startLiveTest(test)
                    },
                    DashboardModule("6. Test Series", Icons.Default.Assignment, BlueInfo) {
                        viewModel.navigateTo(ScreenDestination.TestSeriesList)
                    },
                    DashboardModule("7. Question Bank", Icons.Default.Quiz, PurpleAccent) {
                        viewModel.navigateTo(ScreenDestination.QuestionBank)
                    },
                    DashboardModule("8. Study Notes", Icons.Default.MenuBook, EmeraldSuccess) {
                        viewModel.navigateTo(ScreenDestination.Notes)
                    },
                    DashboardModule("9. Books & NCERT", Icons.Default.AutoStories, Color(0xFFF97316)) {
                        viewModel.navigateTo(ScreenDestination.Books)
                    },
                    DashboardModule("10. AI Study", Icons.Default.AutoAwesome, Color(0xFF6366F1)) {
                        viewModel.navigateTo(ScreenDestination.AiStudy)
                    },
                    DashboardModule("11. Results", Icons.Default.FactCheck, Color(0xFF0284C7)) {
                        if (lastResult != null) {
                            viewModel.navigateTo(ScreenDestination.TestResultScreen(lastResult))
                        } else {
                            viewModel.navigateTo(ScreenDestination.Performance)
                        }
                    },
                    DashboardModule("12. Performance", Icons.Default.Insights, EmeraldSuccess) {
                        viewModel.navigateTo(ScreenDestination.Performance)
                    },
                    DashboardModule("13. Rank / Board", Icons.Default.EmojiEvents, BrandAmberDark) {
                        viewModel.navigateTo(ScreenDestination.Leaderboard)
                    },
                    DashboardModule("14. Subscription", Icons.Default.WorkspacePremium, Color(0xFFE11D48)) {
                        viewModel.navigateTo(ScreenDestination.Subscription)
                    }
                )

                // 2 columns compact grid
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    modules.chunked(2).forEach { rowItems ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowItems.forEach { mod ->
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { mod.onClick() },
                                    color = SurfaceCard,
                                    shadowElevation = 1.dp
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(34.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(mod.color.copy(alpha = 0.15f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = mod.icon,
                                                contentDescription = mod.title,
                                                tint = mod.color,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = mod.title,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = TextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

data class DashboardModule(
    val title: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color,
    val onClick: () -> Unit
)

@Composable
fun DashboardMetric(label: String, value: String, accentColor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, fontWeight = FontWeight.Black, fontSize = 15.sp, color = accentColor)
        Text(text = label, fontSize = 9.sp, color = TextSecondary, textAlign = TextAlign.Center)
    }
}

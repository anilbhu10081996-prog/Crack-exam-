package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.CrackExamViewModel
import com.example.viewmodel.ScreenDestination

@Composable
fun SubscriptionScreen(
    viewModel: CrackExamViewModel,
    modifier: Modifier = Modifier
) {
    val plans by viewModel.membershipPlans.collectAsState()
    var purchaseSuccessMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NeutralBg)
    ) {
        // Toolbar
        Surface(
            color = BrandNavyDark,
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.Home) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "सदस्यता व पास (Crack Exam Membership)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }
                Text(
                    text = "एक पास - 500+ मॉक टेस्ट, AI स्टडी और कोचिंग कंटेंट तक पूर्ण पहुंच",
                    fontSize = 11.sp,
                    color = Color(0xFFCBD5E1),
                    modifier = Modifier.padding(start = 44.dp)
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(plans) { plan ->
                val isPro = plan.id == "PLAN-PRO-PASS"
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = if (isPro) 4.dp else 1.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(
                            if (isPro) Modifier.border(2.dp, BrandAmberPrimary, RoundedCornerShape(16.dp))
                            else Modifier
                        )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(plan.name, fontWeight = FontWeight.Black, fontSize = 15.sp, color = BrandNavyDark)
                            if (plan.isPopular) {
                                Surface(
                                    color = BrandAmberPrimary,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "MOST POPULAR",
                                        color = Color.Black,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = if (plan.priceInr == 0) "निःशुल्क (FREE)" else "₹${plan.priceInr}",
                                fontWeight = FontWeight.Black,
                                fontSize = 24.sp,
                                color = BrandNavyDark
                            )
                            if (plan.originalPriceInr > 0) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "₹${plan.originalPriceInr}",
                                    fontSize = 14.sp,
                                    color = TextMuted,
                                    textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("/ ${plan.validityMonths} माह वैधता", fontSize = 11.sp, color = TextSecondary)
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Divider(color = Color(0xFFE2E8F0))
                        Spacer(modifier = Modifier.height(12.dp))

                        // Features list
                        plan.features.forEach { feat ->
                            Row(
                                modifier = Modifier.padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(feat, fontSize = 12.sp, color = TextPrimary)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                purchaseSuccessMessage = "${plan.name} सफलतापूर्वक एक्टिवेट हो गया!"
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isPro) BrandAmberPrimary else BrandNavyDark,
                                contentColor = if (isPro) Color.Black else Color.White
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("subscribe_btn_${plan.id}")
                        ) {
                            Text(
                                text = if (plan.priceInr == 0) "वर्तमान में एक्टिव" else "अभी खरीदें (Activate Now)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }

    purchaseSuccessMessage?.let { msg ->
        AlertDialog(
            onDismissRequest = { purchaseSuccessMessage = null },
            icon = { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(36.dp)) },
            title = { Text("बधाई हो!", fontWeight = FontWeight.Bold) },
            text = { Text(msg, fontSize = 13.sp) },
            confirmButton = {
                Button(
                    onClick = { purchaseSuccessMessage = null },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark)
                ) {
                    Text("ठीक है (OK)", color = BrandAmberPrimary)
                }
            }
        )
    }
}

package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = BrandAmberPrimary,
    onPrimary = Color.Black,
    primaryContainer = BrandAmberDark,
    onPrimaryContainer = Color.White,
    secondary = BlueInfo,
    onSecondary = Color.White,
    tertiary = EmeraldSuccess,
    background = BrandNavyDark,
    surface = BrandNavy,
    surfaceVariant = BrandNavyLight,
    onBackground = Color.White,
    onSurface = Color.White,
    onSurfaceVariant = Color(0xFFCBD5E1)
)

private val LightColorScheme = lightColorScheme(
    primary = BrandNavyDark,
    onPrimary = Color.White,
    primaryContainer = BrandNavy,
    onPrimaryContainer = Color.White,
    secondary = BrandAmberPrimary,
    onSecondary = Color.Black,
    secondaryContainer = BrandAmberLight,
    onSecondaryContainer = BrandNavyDark,
    tertiary = EmeraldSuccess,
    onTertiary = Color.White,
    background = NeutralBg,
    surface = SurfaceCard,
    surfaceVariant = SurfaceVariantCard,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onSurfaceVariant = TextSecondary,
    error = RoseError,
    onError = Color.White
)

@Composable
fun CrackExamTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep consistent Crack Exam branding
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ExamCategory
import com.example.ui.theme.*
import com.example.viewmodel.CrackExamViewModel
import com.example.viewmodel.ScreenDestination

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TestSeriesListScreen(
    viewModel: CrackExamViewModel,
    modifier: Modifier = Modifier
) {
    val selectedExam by viewModel.selectedExam.collectAsState()
    val testSeriesList by viewModel.testSeries.collectAsState()
    val allTests by viewModel.tests.collectAsState()
    var selectedCategoryFilter by remember { mutableStateOf(selectedExam) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NeutralBg)
    ) {
        // Top Toolbar
        Surface(
            color = SurfaceCard,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.Home) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "टेस्ट सीरीज (Test Series Portal)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = BrandNavyDark
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Exam Sub-tab Chips
                ScrollableTabRow(
                    selectedTabIndex = ExamCategory.values().indexOf(selectedCategoryFilter),
                    edgePadding = 0.dp,
                    containerColor = Color.Transparent,
                    divider = {}
                ) {
                    ExamCategory.values().forEach { category ->
                        val isSelected = selectedCategoryFilter == category
                        Tab(
                            selected = isSelected,
                            onClick = { selectedCategoryFilter = category },
                            text = {
                                Text(
                                    text = category.titleEnglish,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) BrandAmberPrimary else TextSecondary
                                )
                            }
                        )
                    }
                }
            }
        }

        // List of Series & Mocks
        val filteredList = testSeriesList.filter { it.examCategory == selectedCategoryFilter }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${selectedCategoryFilter.titleEnglish} के उपलब्ध टेस्ट (${filteredList.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = BrandNavyDark
                    )
                    Surface(
                        color = EmeraldLight,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "TCS 2026 Pattern",
                            color = EmeraldSuccess,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            if (filteredList.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.AssignmentLate, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("इस श्रेणी में नए मॉक टेस्ट जल्द ही लाइव होंगे", fontWeight = FontWeight.Bold)
                            Text("कृपया अन्य परीक्षा टैब का चयन करें", fontSize = 12.sp, color = TextSecondary)
                        }
                    }
                }
            } else {
                items(filteredList) { series ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        shape = RoundedCornerShape(14.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        color = if (series.isFree) EmeraldLight else BrandAmberLight,
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = if (series.isFree) "FREE MOCK" else series.tag,
                                            color = if (series.isFree) EmeraldSuccess else BrandNavyDark,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "कठिनाई स्तर: ${series.difficulty}",
                                        fontSize = 11.sp,
                                        color = TextSecondary
                                    )
                                }

                                Text(
                                    text = "${series.completedTests}/${series.totalTests} पूर्ण",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BlueInfo
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = series.title,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = BrandNavyDark
                            )

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "औसत स्कोर: ${series.avgScore} • सटीकता दर: ${series.avgAccuracy}%",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )

                            Spacer(modifier = Modifier.height(10.dp))
                            LinearProgressIndicator(
                                progress = { series.completedTests.toFloat() / series.totalTests.toFloat() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = EmeraldSuccess,
                                trackColor = SurfaceVariantCard
                            )

                            Spacer(modifier = Modifier.height(14.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = {
                                        val test = allTests.firstOrNull { it.examCategory == series.examCategory } ?: allTests.first()
                                        viewModel.startLiveTest(test)
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("start_test_from_series_${series.id}"),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = BrandNavyDark,
                                        contentColor = BrandAmberPrimary
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("टेस्ट शुरू करें (Start)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = { viewModel.navigateTo(ScreenDestination.Performance) },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp)
                                ) {
                                    Icon(Icons.Default.Insights, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("एनालिटिक्स", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

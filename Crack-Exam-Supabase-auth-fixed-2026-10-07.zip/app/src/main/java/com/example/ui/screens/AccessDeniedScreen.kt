package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.CrackExamViewModel
import com.example.viewmodel.ScreenDestination

@Composable
fun AccessDeniedScreen(
    requiredPermission: String,
    attemptedScreen: String,
    viewModel: CrackExamViewModel,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NeutralBg)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(RoseLight),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Access Denied",
                tint = RoseError,
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "पहुंच अस्वीकृत (Access Denied)",
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = BrandNavyDark
        )

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "आप '$attemptedScreen' खोलने का प्रयास कर रहे हैं जिसके लिए अनुमति '$requiredPermission' आवश्यक है।",
            fontSize = 13.sp,
            color = TextSecondary,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "सामान्य विद्यार्थी खाते को इस प्रशासनिक मॉड्यूल का उपयोग करने की अनुमति नहीं है।",
            fontSize = 12.sp,
            color = TextMuted,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { viewModel.navigateTo(ScreenDestination.Home) },
            colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().height(46.dp)
        ) {
            Text("होम स्क्रीन पर लौटें (Back to Home)", color = BrandAmberPrimary, fontWeight = FontWeight.Bold)
        }
    }
}

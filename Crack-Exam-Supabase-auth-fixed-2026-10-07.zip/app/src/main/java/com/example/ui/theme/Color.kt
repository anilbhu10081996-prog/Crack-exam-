package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Crack Exam Brand Palette
val BrandNavyDark = Color(0xFF0F172A)
val BrandNavy = Color(0xFF1E293B)
val BrandNavyLight = Color(0xFF334155)

val BrandAmberPrimary = Color(0xFFF59E0B)
val BrandAmberLight = Color(0xFFFDE68A)
val BrandAmberDark = Color(0xFFD97706)

val EmeraldSuccess = Color(0xFF10B981)
val EmeraldLight = Color(0xFFD1FAE5)

val RoseError = Color(0xFFEF4444)
val RoseLight = Color(0xFFFEE2E2)

val BlueInfo = Color(0xFF3B82F6)
val BlueLight = Color(0xFFDBEAFE)

val PurpleAccent = Color(0xFF8B5CF6)
val PurpleLight = Color(0xFFEDE9FE)

val NeutralBg = Color(0xFFF8FAFC)
val SurfaceCard = Color(0xFFFFFFFF)
val SurfaceVariantCard = Color(0xFFF1F5F9)

val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF64748B)
val TextMuted = Color(0xFF94A3B8)

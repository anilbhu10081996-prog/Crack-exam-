package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TestResult
import com.example.ui.theme.*
import com.example.viewmodel.CrackExamViewModel
import com.example.viewmodel.ScreenDestination

@Composable
fun TestResultScreen(
    result: TestResult,
    viewModel: CrackExamViewModel,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NeutralBg)
    ) {
        // Top Toolbar
        Surface(
            color = BrandNavyDark,
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.Home) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "टेस्ट परिणाम (Scorecard)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }

                Surface(
                    color = EmeraldSuccess,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "Verified",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Score Card
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = result.testTitle,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = BrandNavyDark
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .clip(CircleShape)
                            .background(BrandAmberLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = String.format("%.1f", result.scoredMarks),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black,
                                color = BrandNavyDark
                            )
                            Text(
                                text = "/ ${result.totalMarks.toInt()}",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = if (result.accuracyPercentage >= 80) "उत्कृष्ट प्रदर्शन! आप कट-ऑफ से काफी ऊपर हैं 🎯" else "समीक्षा आवश्यक: अपनी गलतियों का विश्लेषण करें",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = if (result.accuracyPercentage >= 80) EmeraldSuccess else BrandAmberDark
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = Color(0xFFE2E8F0))
                    Spacer(modifier = Modifier.height(16.dp))

                    // All India Rank & Percentile Matrix
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        ResultMetric("All India Rank", "#${result.rank}", "/ ${result.totalParticipants}", BrandNavyDark)
                        ResultMetric("पर्सेंटाइल (Percentile)", "${String.format("%.1f", result.percentile)}%", "Top 1%", BlueInfo)
                        ResultMetric("सटीकता (Accuracy)", "${String.format("%.1f", result.accuracyPercentage)}%", "High Target", EmeraldSuccess)
                    }
                }
            }

            // Question Breakdown (Correct, Wrong, Skipped)
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "प्रश्नों का विवरण (Question Breakdown)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = BrandNavyDark
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        BreakdownBox("सही (Correct)", "${result.correctCount}", EmeraldLight, EmeraldSuccess)
                        BreakdownBox("गलत (Wrong)", "${result.wrongCount}", RoseLight, RoseError)
                        BreakdownBox("छोड़े (Skipped)", "${result.skippedCount}", SurfaceVariantCard, TextSecondary)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    val timeTakenMin = result.timeTakenSeconds / 60
                    val timeTakenSec = result.timeTakenSeconds % 60
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("कुल समय व्यतीत:", fontSize = 12.sp, color = TextSecondary)
                        Text(
                            "$timeTakenMin मिनट $timeTakenSec सेकंड",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = BrandNavyDark
                        )
                    }
                }
            }

            // AI Study Assistant Recommendation
            Card(
                colors = CardDefaults.cardColors(containerColor = BrandNavyDark),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = BrandAmberPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "AI कमज़ोरी सुधार सुझाव (Diagnostic Advice)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "आपने जीएस (General Science) और संविधान में 2 प्रश्न गलत किए हैं। AI Study Assistant से तुरंत इन विषयों के शॉर्ट नोट्स और फॉर्मूला जनरेट करके रिवाइज करें।",
                        fontSize = 12.sp,
                        color = Color(0xFFCBD5E1),
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { viewModel.navigateTo(ScreenDestination.AiStudy) },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandAmberPrimary, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("कमजोर विषयों को AI से सुधारें (Fix with AI)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            // Navigation Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.Leaderboard) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Leaderboard, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("लीडरबोर्ड", fontSize = 12.sp)
                }

                Button(
                    onClick = { viewModel.navigateTo(ScreenDestination.Home) },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("result_home_btn"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("होम पर जाएं", color = BrandAmberPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun ResultMetric(label: String, value: String, sub: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Black, fontSize = 16.sp, color = color)
        Text(label, fontSize = 10.sp, color = TextSecondary)
        Text(sub, fontSize = 9.sp, color = TextMuted)
    }
}

@Composable
fun BreakdownBox(label: String, count: String, bgColor: Color, textColor: Color) {
    Surface(
        color = bgColor,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.width(96.dp)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(count, fontWeight = FontWeight.Black, fontSize = 18.sp, color = textColor)
            Text(label, fontSize = 10.sp, color = textColor, fontWeight = FontWeight.SemiBold)
        }
    }
}

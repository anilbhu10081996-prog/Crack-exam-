package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.UserRole
import com.example.ui.theme.*

@Composable
fun CrackExamHeader(
    title: String = "CRACK EXAM",
    subtitle: String? = null,
    currentRole: UserRole,
    onRoleClick: () -> Unit,
    onNotificationClick: () -> Unit,
    onProfileClick: () -> Unit
) {
    Surface(
        color = BrandNavyDark,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Brand Logo & Title
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(BrandAmberPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = "Crack Exam Logo",
                            tint = Color.Black,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "CRACK EXAM",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp
                                ),
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = BrandAmberPrimary.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "2026",
                                    color = BrandAmberPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text(
                            text = subtitle ?: "परीक्षा की तैयारी, एक ही जगह",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }

                // Action controls: Role badge & Notification & Profile
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Role Switcher Badge
                    Surface(
                        color = when (currentRole) {
                            UserRole.STUDENT -> Color(0xFF1E293B)
                            UserRole.SUPER_ADMIN, UserRole.EXAM_ADMIN -> Color(0xFFDC2626).copy(alpha = 0.25f)
                            else -> Color(0xFF2563EB).copy(alpha = 0.25f)
                        },
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .clickable { onRoleClick() }
                            .testTag("role_badge_btn")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when (currentRole) {
                                            UserRole.STUDENT -> EmeraldSuccess
                                            UserRole.SUPER_ADMIN, UserRole.EXAM_ADMIN -> RoseError
                                            else -> BlueInfo
                                        }
                                    )
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = when (currentRole) {
                                    UserRole.STUDENT -> "Aspirant"
                                    UserRole.TEACHER -> "Teacher"
                                    UserRole.TEST_CREATOR -> "Creator"
                                    UserRole.CONTENT_ADMIN -> "Content"
                                    UserRole.MODERATOR -> "Moderator"
                                    UserRole.FINANCE_ADMIN -> "Finance"
                                    UserRole.SUPPORT_ADMIN -> "Support"
                                    UserRole.EDUCATION_ADMIN -> "EduAdmin"
                                    UserRole.EXAM_ADMIN -> "ExamAdmin"
                                    UserRole.SUPER_ADMIN -> "SuperAdmin"
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Icon(
                                imageVector = Icons.Default.SwapHoriz,
                                contentDescription = "Switch Role",
                                tint = Color.LightGray,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick = onNotificationClick,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("notification_btn")
                    ) {
                        BadgedBox(
                            badge = {
                                Badge(containerColor = RoseError) {
                                    Text("3", fontSize = 9.sp)
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Notifications,
                                contentDescription = "Notifications",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick = onProfileClick,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(BrandNavyLight)
                            .testTag("profile_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Profile",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Mobile Bottom Navigation:
 * Exactly the 5 base sections: Home, Tests, Practice, AI Study, Profile
 */
@Composable
fun CrackExamBottomBar(
    currentTab: String,
    onTabSelected: (String) -> Unit
) {
    NavigationBar(
        containerColor = BrandNavyDark,
        contentColor = Color.White,
        tonalElevation = 8.dp,
        windowInsets = WindowInsets.navigationBars
    ) {
        val items = listOf(
            Triple("Home", Icons.Default.Home, Icons.Outlined.Home),
            Triple("Tests", Icons.Default.Assignment, Icons.Outlined.Assignment),
            Triple("Practice", Icons.Default.Quiz, Icons.Outlined.Quiz),
            Triple("AI Study", Icons.Default.AutoAwesome, Icons.Outlined.AutoAwesome),
            Triple("Profile", Icons.Default.Person, Icons.Outlined.Person)
        )

        items.forEach { (label, filledIcon, outlinedIcon) ->
            val isSelected = currentTab == label
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(label) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) filledIcon else outlinedIcon,
                        contentDescription = label,
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.Black,
                    unselectedIconColor = Color(0xFF94A3B8),
                    selectedTextColor = BrandAmberPrimary,
                    unselectedTextColor = Color(0xFF94A3B8),
                    indicatorColor = BrandAmberPrimary
                ),
                modifier = Modifier.testTag("nav_item_${label.lowercase().replace(" ", "_")}")
            )
        }
    }
}

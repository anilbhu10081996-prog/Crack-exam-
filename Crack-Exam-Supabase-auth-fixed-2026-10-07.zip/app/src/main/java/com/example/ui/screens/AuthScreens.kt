package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ExamCategory
import com.example.model.UiState
import com.example.ui.theme.*
import com.example.viewmodel.CrackExamViewModel
import com.example.viewmodel.ScreenDestination

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    viewModel: CrackExamViewModel,
    modifier: Modifier = Modifier
) {
    var identifier by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    val authState by viewModel.authActionState.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NeutralBg)
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // App Logo & Header
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(BrandNavyDark),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Bolt,
                contentDescription = "Crack Exam",
                tint = BrandAmberPrimary,
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = "CRACK EXAM",
            fontSize = 24.sp,
            fontWeight = FontWeight.Black,
            color = BrandNavyDark,
            letterSpacing = 1.sp
        )
        Text(
            text = "परीक्षा की तैयारी, एक ही जगह",
            fontSize = 13.sp,
            color = TextSecondary,
            fontWeight = FontWeight.Medium
        )

        Spacer(modifier = Modifier.height(28.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "लॉगिन करें (Student Sign In)",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrandNavyDark
                )
                Text(
                    text = "अपने पंजीकृत मोबाइल नंबर अथवा ईमेल से लॉगिन करें",
                    fontSize = 12.sp,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(18.dp))

                OutlinedTextField(
                    value = identifier,
                    onValueChange = { identifier = it },
                    label = { Text("मोबाइल नंबर / ईमेल") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = BrandNavyDark) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_identifier_input"),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("पासवर्ड") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = BrandNavyDark) },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = "Toggle password"
                            )
                        }
                    },
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_password_input"),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.ForgotPassword) },
                        modifier = Modifier.testTag("forgot_password_btn")
                    ) {
                        Text(
                            text = "पासवर्ड भूल गए? (Forgot?)",
                            fontSize = 12.sp,
                            color = BlueInfo,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                if (authState is UiState.Error) {
                    Surface(
                        color = RoseLight,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = (authState as UiState.Error).message,
                            color = RoseError,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                Button(
                    onClick = { viewModel.login(identifier, password) },
                    enabled = authState !is UiState.Loading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("login_submit_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    if (authState is UiState.Loading) {
                        CircularProgressIndicator(color = BrandAmberPrimary, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    } else {
                        Text("लॉगिन करें (Sign In)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = BrandAmberPrimary)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text("नया खाता बनाना चाहते हैं?", fontSize = 13.sp, color = TextSecondary)
            TextButton(
                onClick = { viewModel.navigateTo(ScreenDestination.Register) },
                modifier = Modifier.testTag("go_to_register_btn")
            ) {
                Text("नया पंजीकरण (Register)", fontWeight = FontWeight.Bold, color = BrandAmberDark)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterScreen(
    viewModel: CrackExamViewModel,
    modifier: Modifier = Modifier
) {
    var fullName by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(ExamCategory.RAILWAY) }
    var state by remember { mutableStateOf("Uttar Pradesh") }
    var language by remember { mutableStateOf("Hindi + English") }

    val authState by viewModel.authActionState.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NeutralBg)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            IconButton(onClick = { viewModel.navigateTo(ScreenDestination.Login) }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(6.dp))
            Column {
                Text("नया विद्यार्थी पंजीकरण", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = BrandNavyDark)
                Text("Create New Crack Exam Account", fontSize = 11.sp, color = TextSecondary)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("पूरा नाम (Full Name) *") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = mobile,
                    onValueChange = { mobile = it },
                    label = { Text("मोबाइल नंबर (10 अंक) *") },
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("ईमेल आईडी (Email) *") },
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("पासवर्ड *") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = confirmPassword,
                    onValueChange = { confirmPassword = it },
                    label = { Text("पासवर्ड पुनः दर्ज करें *") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Text("लक्ष्य परीक्षा (Target Exam Preference):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                ScrollableTabRow(
                    selectedTabIndex = ExamCategory.values().indexOf(selectedCategory),
                    edgePadding = 0.dp,
                    containerColor = Color.Transparent,
                    divider = {}
                ) {
                    ExamCategory.values().take(5).forEach { cat ->
                        Tab(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            text = { Text(cat.titleEnglish, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = state,
                    onValueChange = { state = it },
                    label = { Text("राज्य (State)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                if (authState is UiState.Error) {
                    Surface(
                        color = RoseLight,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = (authState as UiState.Error).message,
                            color = RoseError,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Button(
                    onClick = {
                        if (password != confirmPassword) {
                            // password mismatch handled
                        } else {
                            viewModel.register(fullName, mobile, email, password, selectedCategory, state, language)
                        }
                    },
                    enabled = authState !is UiState.Loading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("register_submit_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    if (authState is UiState.Loading) {
                        CircularProgressIndicator(color = BrandAmberPrimary, modifier = Modifier.size(20.dp))
                    } else {
                        Text("रजिस्टर करें (Register Now)", fontWeight = FontWeight.Bold, color = BrandAmberPrimary)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("पहले से पंजीकृत हैं?", fontSize = 13.sp, color = TextSecondary)
            TextButton(onClick = { viewModel.navigateTo(ScreenDestination.Login) }) {
                Text("लॉगिन करें (Sign In)", fontWeight = FontWeight.Bold, color = BlueInfo)
            }
        }
    }
}

@Composable
fun ForgotPasswordScreen(
    viewModel: CrackExamViewModel,
    modifier: Modifier = Modifier
) {
    var email by remember { mutableStateOf("") }
    val authState by viewModel.authActionState.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NeutralBg)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("पासवर्ड रीसेट (Forgot Password)", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = BrandNavyDark)
                Spacer(modifier = Modifier.height(6.dp))
                Text("अपना पंजीकृत ईमेल दर्ज करें, हम पासवर्ड रीसेट लिंक भेजेंगे।", fontSize = 12.sp, color = TextSecondary)

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("पंजीकृत ईमेल आईडी") },
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { viewModel.sendForgotPasswordLink(email) },
                    modifier = Modifier.fillMaxWidth().height(46.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("रीसेट लिंक भेजें (Send Link)", color = BrandAmberPrimary, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(10.dp))

                TextButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.Login) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("वापस लॉगिन पर जाएं", color = TextSecondary)
                }
            }
        }
    }
}

@Composable
fun ResetPasswordScreen(
    email: String,
    viewModel: CrackExamViewModel,
    modifier: Modifier = Modifier
) {
    var newPass by remember { mutableStateOf("") }
    var confirmPass by remember { mutableStateOf("") }
    val authState by viewModel.authActionState.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NeutralBg)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("नया पासवर्ड सेट करें", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = BrandNavyDark)
                Text("खाता: $email", fontSize = 12.sp, color = TextSecondary)

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = newPass,
                    onValueChange = { newPass = it },
                    label = { Text("नया पासवर्ड") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = confirmPass,
                    onValueChange = { confirmPass = it },
                    label = { Text("नया पासवर्ड पुनः दर्ज करें") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                if (authState is UiState.Error) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text((authState as UiState.Error).message, color = RoseError, fontSize = 11.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { viewModel.resetPassword(newPass, confirmPass) },
                    modifier = Modifier.fillMaxWidth().height(46.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("पासवर्ड अपडेट करें (Save)", color = BrandAmberPrimary, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun EmailVerificationScreen(
    email: String,
    viewModel: CrackExamViewModel,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NeutralBg)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier.size(72.dp).clip(CircleShape).background(EmeraldLight),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.MarkEmailRead, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(40.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text("ईमेल सत्यापन (Verify Email)", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = BrandNavyDark)
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            "हमने $email पर एक सत्यापन लिंक भेजा है। कृपया खाता सक्रिय करने हेतु सत्यापित करें।",
            fontSize = 13.sp,
            color = TextSecondary,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { viewModel.verifyEmail(email) },
            colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().height(46.dp).testTag("verify_email_btn")
        ) {
            Text("ईमेल सत्यापित हो गया (Continue)", color = BrandAmberPrimary, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(12.dp))

        TextButton(onClick = { viewModel.verifyEmail(email) }) {
            Text("सत्यापन लिंक दोबारा भेजें (Resend)", color = BlueInfo)
        }
    }
}

@Composable
fun ExamSelectionScreen(
    viewModel: CrackExamViewModel,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf(ExamCategory.RAILWAY) }
    var selectedLevel by remember { mutableStateOf("Intermediate") }
    var selectedLang by remember { mutableStateOf("Hindi + English") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NeutralBg)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text("अपनी परीक्षा का चयन करें", fontWeight = FontWeight.Black, fontSize = 20.sp, color = BrandNavyDark)
        Text("Customize Your 2026 Competitive Exam Target", fontSize = 12.sp, color = TextSecondary)

        Spacer(modifier = Modifier.height(18.dp))

        Text("1. प्राथमिक परीक्षा (Primary Exam):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(8.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ExamCategory.values().forEach { cat ->
                val isSelected = selectedCategory == cat
                Surface(
                    color = if (isSelected) BrandNavyDark else SurfaceCard,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedCategory = cat }
                        .padding(vertical = 2.dp),
                    shadowElevation = if (isSelected) 3.dp else 1.dp
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${cat.titleEnglish} — ${cat.titleHindi}",
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White else TextPrimary
                        )
                        if (isSelected) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BrandAmberPrimary)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))
        Text("2. आपकी वर्तमान तैयारी स्तर (Preparation Level):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Beginner", "Intermediate", "Advanced").forEach { level ->
                val isSelected = selectedLevel == level
                Surface(
                    color = if (isSelected) BrandAmberPrimary else SurfaceCard,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).clickable { selectedLevel = level }
                ) {
                    Text(
                        text = level,
                        modifier = Modifier.padding(vertical = 10.dp),
                        textAlign = TextAlign.Center,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) Color.Black else TextPrimary,
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                viewModel.completeExamCustomization(
                    selectedCategory,
                    "${selectedCategory.titleEnglish} 2026 Target",
                    selectedLevel,
                    selectedLang
                )
            },
            colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_exam_customization_btn")
        ) {
            Text("तैयारी शुरू करें (Enter Dashboard)", color = BrandAmberPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

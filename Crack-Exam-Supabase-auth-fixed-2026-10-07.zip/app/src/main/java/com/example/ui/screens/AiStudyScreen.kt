package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*
import com.example.viewmodel.CrackExamViewModel
import com.example.viewmodel.ScreenDestination

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiStudyScreen(
    viewModel: CrackExamViewModel,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val isAiLoading by viewModel.isAiLoading.collectAsState()
    val aiError by viewModel.aiErrorMessage.collectAsState()

    // Subscribed state streams
    val currentQa by viewModel.currentQaResult.collectAsState()
    val currentDoubt by viewModel.currentDoubtResult.collectAsState()
    val currentNoteDraft by viewModel.currentNoteDraft.collectAsState()
    val currentQuizSession by viewModel.currentQuizSession.collectAsState()
    val currentTest by viewModel.currentGeneratedTest.collectAsState()
    val currentRevision by viewModel.currentRevisionPackage.collectAsState()
    val currentPlan by viewModel.currentStudyPlan.collectAsState()
    val historyList by viewModel.aiHistory.collectAsState()
    val reviewQueue by viewModel.aiReviewSubmissions.collectAsState()

    // Filter student's private history
    val studentHistory = remember(historyList, currentUser.id) {
        historyList.filter { it.studentId == currentUser.id }
    }

    // Role check for reviewing content
    val canReviewContent = remember(currentUser.role) {
        RolePermissions.hasPermission(currentUser.role, Permission.QUESTION_APPROVE)
    }

    val availableTabs = remember(canReviewContent) {
        val base = mutableListOf(
            "Q&A",
            "Doubt Solver",
            "AI Notes",
            "AI Quiz",
            "Test Generator",
            "Revision",
            "Study Planner",
            "AI History"
        )
        if (canReviewContent) {
            base.add("Review Queue")
        }
        base
    }

    var selectedTab by remember { mutableStateOf("Q&A") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NeutralBg)
    ) {
        // App Bar
        Surface(
            color = BrandNavyDark,
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.Home) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "CRACK AI STUDY",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = BrandAmberPrimary,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "2.0 ENGINE",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    color = BrandNavyDark,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "परीक्षा की तैयारी, एक ही जगह • Powered by AI Intelligence",
                            fontSize = 11.sp,
                            color = Color(0xFFCBD5E1)
                        )
                    }
                }
            }
        }

        // Feature Navigation Tab Bar
        ScrollableTabRow(
            selectedTabIndex = availableTabs.indexOf(selectedTab).coerceAtLeast(0),
            containerColor = BrandNavy,
            contentColor = Color.White,
            edgePadding = 12.dp,
            divider = {}
        ) {
            availableTabs.forEach { tab ->
                val isSelected = selectedTab == tab
                Tab(
                    selected = isSelected,
                    onClick = { selectedTab = tab },
                    text = {
                        Text(
                            text = tab,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) BrandAmberPrimary else Color(0xFFCBD5E1)
                        )
                    }
                )
            }
        }

        // Error Banner
        AnimatedVisibility(visible = aiError != null) {
            if (aiError != null) {
                Surface(
                    color = RoseError.copy(alpha = 0.15f),
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = RoseError)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = aiError ?: "", fontSize = 12.sp, color = RoseError, fontWeight = FontWeight.SemiBold)
                        }
                        IconButton(onClick = { viewModel.clearAiError() }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = RoseError, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        // Active Content Area
        Box(modifier = Modifier.fillMaxSize()) {
            when (selectedTab) {
                "Q&A" -> AiQuestionAnswerTab(viewModel, currentQa, isAiLoading)
                "Doubt Solver" -> AiDoubtSolverTab(viewModel, currentDoubt, isAiLoading)
                "AI Notes" -> AiNotesTab(viewModel, currentNoteDraft, isAiLoading)
                "AI Quiz" -> AiQuizTab(viewModel, currentQuizSession, isAiLoading)
                "Test Generator" -> AiTestGeneratorTab(viewModel, currentTest, isAiLoading)
                "Revision" -> AiRevisionTab(viewModel, currentRevision, isAiLoading)
                "Study Planner" -> AiStudyPlannerTab(viewModel, currentPlan, isAiLoading)
                "AI History" -> AiHistoryTab(viewModel, studentHistory)
                "Review Queue" -> AiReviewQueueTab(viewModel, reviewQueue)
            }
        }
    }
}

// =================================================================
// 1. AI QUESTION ANSWER TAB
// =================================================================
@Composable
private fun AiQuestionAnswerTab(
    viewModel: CrackExamViewModel,
    currentResult: AiQuestionAnswer?,
    isLoading: Boolean
) {
    var queryText by remember { mutableStateOf("भारतीय संविधान क्या है?") }
    var selectedLang by remember { mutableStateOf("Hindi + English") }

    val presetQueries = listOf(
        "भारतीय संविधान क्या है?",
        "रेलवे गति, समय और दूरी फॉर्मूला ट्रिक्स",
        "मौलिक अधिकार और अनुच्छेद 32",
        "न्यूटन के गति नियम और संवेग संरक्षण"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("AI Question Answer (प्रश्नोत्तर सहायक)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BrandNavyDark)
                    Text("परीक्षा-उन्मुख सटीक उत्तर, मुख्य बिंदु, उदाहरण एवं तथ्य प्राप्त करें", fontSize = 11.sp, color = TextSecondary)
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = queryText,
                        onValueChange = { queryText = it },
                        modifier = Modifier.fillMaxWidth().testTag("ai_qa_input"),
                        placeholder = { Text("उदा. भारतीय संविधान क्या है? / Solve time-work concept") },
                        shape = RoundedCornerShape(10.dp),
                        trailingIcon = {
                            if (isLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            } else {
                                IconButton(
                                    onClick = { viewModel.askAiQuestion(queryText, selectedLang) },
                                    modifier = Modifier.testTag("ai_qa_submit")
                                ) {
                                    Icon(Icons.Default.Send, contentDescription = "Send", tint = BrandAmberPrimary)
                                }
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("भाषा (Language):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Hindi", "English", "Hinglish").forEach { lang ->
                                FilterChip(
                                    selected = selectedLang.contains(lang, ignoreCase = true),
                                    onClick = { selectedLang = lang },
                                    label = { Text(lang, fontSize = 10.sp) }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("त्वरित सुझाव (Quick Prompts):", fontSize = 11.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        presetQueries.forEach { prompt ->
                            Surface(
                                color = SurfaceVariantCard,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth().clickable {
                                    queryText = prompt
                                    viewModel.askAiQuestion(prompt, selectedLang)
                                }
                            ) {
                                Text(
                                    text = "⚡ $prompt",
                                    fontSize = 11.sp,
                                    color = BrandNavyDark,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        if (isLoading) {
            item { LoadingCard("AI उत्तर तैयार कर रहा है...", "व्याख्या, मुख्य बिंदु एवं परीक्षा तथ्य संकलित हो रहे हैं") }
        } else if (currentResult != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(currentResult.question, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = BrandNavyDark)
                            }
                            Surface(color = BrandAmberLight, shape = RoundedCornerShape(4.dp)) {
                                Text("Private Q&A", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = BrandNavyDark, modifier = Modifier.padding(4.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))

                        Text("विस्तृत व्याख्या (Explanation):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BrandNavyDark)
                        Text(currentResult.explanation, fontSize = 12.sp, lineHeight = 18.sp, color = TextPrimary)

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("महत्वपूर्ण बिंदु (Important Points):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BrandAmberPrimary)
                        currentResult.importantPoints.forEach { pt ->
                            Text("• $pt", fontSize = 11.sp, color = TextPrimary, lineHeight = 16.sp)
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("उदाहरण (Examples):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BrandNavyLight)
                        currentResult.examples.forEach { ex ->
                            Text("✔ $ex", fontSize = 11.sp, color = TextPrimary, lineHeight = 16.sp)
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("परीक्षा-केंद्रित तथ्य (Exam-Focused Facts):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = EmeraldSuccess)
                        currentResult.examFacts.forEach { fact ->
                            Text(fact, fontSize = 11.sp, color = TextPrimary, lineHeight = 16.sp)
                        }
                    }
                }
            }
        }
    }
}

// =================================================================
// 2. AI DOUBT SOLVER TAB
// =================================================================
@Composable
private fun AiDoubtSolverTab(
    viewModel: CrackExamViewModel,
    doubtResult: AiDoubtItem?,
    isLoading: Boolean
) {
    var doubtText by remember { mutableStateOf("दो ट्रेनें 54 और 72 km/h से विपरीत दिशा में आ रही हैं, लंबाई 120m और 160m है...") }
    var selectedSubject by remember { mutableStateOf("Mathematics") }
    var topicName by remember { mutableStateOf("Speed, Time & Distance") }
    var hasImageAttachment by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("AI Doubt Solver (डाउट समाधान)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BrandNavyDark)
                    Text("टेक्स्ट या प्रश्न चित्र संलग्न करें • स्टेप-बाय-स्टेप हल व ट्रिक्स", fontSize = 11.sp, color = TextSecondary)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = selectedSubject,
                            onValueChange = { selectedSubject = it },
                            label = { Text("Subject", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        )
                        OutlinedTextField(
                            value = topicName,
                            onValueChange = { topicName = it },
                            label = { Text("Topic", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = doubtText,
                        onValueChange = { doubtText = it },
                        modifier = Modifier.fillMaxWidth().testTag("ai_doubt_input"),
                        placeholder = { Text("अपना प्रश्न या डाउट विस्तार से लिखें...") },
                        minLines = 3,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { hasImageAttachment = !hasImageAttachment },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.AttachFile, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (hasImageAttachment) "चित्र संलग्न है ✓" else "प्रश्न चित्र जोड़ें (Attach Image)", fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                viewModel.solveAiDoubt(
                                    question = doubtText,
                                    subject = selectedSubject,
                                    topic = topicName,
                                    imageUri = if (hasImageAttachment) "simulated://doubt_diagram.jpg" else null
                                )
                            },
                            enabled = !isLoading,
                            colors = ButtonDefaults.buttonColors(containerColor = BrandAmberPrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("ai_solve_doubt_btn")
                        ) {
                            Text("डाउट हल करें", color = BrandNavyDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        if (isLoading) {
            item { LoadingCard("डाउट का विश्लेषण किया जा रहा है...", "चरणबद्ध हल और शॉर्टकट ट्रिक संकलित हो रही है") }
        } else if (doubtResult != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${doubtResult.subject} • ${doubtResult.topic}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BrandNavyDark)
                            Surface(color = EmeraldLight, shape = RoundedCornerShape(4.dp)) {
                                Text("Solved ✓", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess, modifier = Modifier.padding(4.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))

                        Text("चरण-दर-चरण समाधान (Step-by-Step Explanation):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BrandNavyDark)
                        doubtResult.stepByStepExplanation.forEach { step ->
                            Text(step, fontSize = 12.sp, color = TextPrimary, lineHeight = 18.sp, modifier = Modifier.padding(vertical = 2.dp))
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(color = SurfaceVariantCard, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(doubtResult.finalAnswer, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = EmeraldSuccess)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(color = BrandAmberLight, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(doubtResult.shortcutTrick, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = BrandNavyDark)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(doubtResult.importantExamPoint, fontSize = 11.sp, color = TextSecondary)
                    }
                }
            }
        }
    }
}

// =================================================================
// 3. AI NOTES TAB (Draft Flow & Review Submission)
// =================================================================
@Composable
private fun AiNotesTab(
    viewModel: CrackExamViewModel,
    noteDraft: AiNoteDraft?,
    isLoading: Boolean
) {
    var topicInput by remember { mutableStateOf("मौलिक कर्तव्य (Fundamental Duties)") }
    var subjectInput by remember { mutableStateOf("Indian Polity") }
    var selectedCategory by remember { mutableStateOf(ExamCategory.RAILWAY) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("AI Notes Generator (परीक्षा नोट्स निर्माण)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BrandNavyDark)
                    Text("Flow: Topic → AI Notes Generate → Preview → Save Draft → Review Workflow", fontSize = 11.sp, color = TextSecondary)
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = topicInput,
                        onValueChange = { topicInput = it },
                        label = { Text("Topic Name", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth().testTag("ai_notes_topic_input"),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = subjectInput,
                        onValueChange = { subjectInput = it },
                        label = { Text("Subject", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { viewModel.generateAiNotes(topicInput, subjectInput, selectedCategory) },
                        enabled = !isLoading,
                        colors = ButtonDefaults.buttonColors(containerColor = BrandAmberPrimary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().testTag("ai_generate_notes_btn")
                    ) {
                        Text("AI नोट्स तैयार करें (Generate Notes)", color = BrandNavyDark, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (isLoading) {
            item { LoadingCard("AI नोट्स तैयार कर रहा है...", "शॉर्ट सारांश, मुख्य बिंदु, महत्वपूर्ण तथ्य एवं एग्जाम ट्रिक्स संकलित हो रहे हैं") }
        } else if (noteDraft != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(noteDraft.topic, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BrandNavyDark)
                            Surface(
                                color = if (noteDraft.status == ReviewStatus.REVIEW) Color(0xFFFEF3C7) else BrandNavyLight,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = if (noteDraft.status == ReviewStatus.REVIEW) "UNDER REVIEW" else "PRIVATE DRAFT",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (noteDraft.status == ReviewStatus.REVIEW) BrandNavyDark else Color.White,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                        }
                        Text("${noteDraft.subject} • ${noteDraft.examCategory.name}", fontSize = 11.sp, color = TextSecondary)
                        Spacer(modifier = Modifier.height(10.dp))

                        Text("संक्षिप्त सारांश (Short Summary):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BrandNavyDark)
                        Text(noteDraft.shortSummary, fontSize = 12.sp, lineHeight = 18.sp, color = TextPrimary)

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("विस्तृत व्याख्या (Detailed Explanation):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BrandNavyDark)
                        Text(noteDraft.detailedExplanation, fontSize = 12.sp, lineHeight = 18.sp, color = TextPrimary)

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("महत्वपूर्ण तथ्य (Important Facts):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = EmeraldSuccess)
                        noteDraft.importantFacts.forEach { Text("• $it", fontSize = 11.sp, color = TextPrimary) }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("रिवीजन बिंदु (Revision Points):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BrandAmberPrimary)
                        noteDraft.revisionPoints.forEach { Text("✔ $it", fontSize = 11.sp, color = TextPrimary) }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("एग्जाम ट्रिक्स (Exam Tricks):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BrandNavyLight)
                        noteDraft.examTricks.forEach { Text("⚡ $it", fontSize = 11.sp, color = TextPrimary) }

                        Spacer(modifier = Modifier.height(14.dp))
                        if (noteDraft.status == ReviewStatus.DRAFT) {
                            Button(
                                onClick = { viewModel.submitNoteForPublicReview(noteDraft.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("प्रकाशन समीक्षा के लिए भेजें (Submit for Review)", color = Color.White, fontSize = 12.sp)
                            }
                        } else {
                            Surface(
                                color = EmeraldLight,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "नोट्स एडमिन समीक्षा हेतु सबमिट कर दिए गए हैं। स्वीकृत होने पर पब्लिक लाइब्रेरी में दिखेंगे।",
                                    fontSize = 11.sp,
                                    color = EmeraldSuccess,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// =================================================================
// 4. AI QUIZ TAB (Interactive Session & Score)
// =================================================================
@Composable
private fun AiQuizTab(
    viewModel: CrackExamViewModel,
    quizSession: AiQuizSession?,
    isLoading: Boolean
) {
    var quizTopic by remember { mutableStateOf("भारतीय संविधान एवं संसद") }
    var questionCount by remember { mutableStateOf(5) }
    var quizType by remember { mutableStateOf("MCQ") }
    var currentQIndex by remember { mutableStateOf(0) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (quizSession == null || quizSession.isSubmitted) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("AI Quiz Generator (क्विज़ अभ्यास)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BrandNavyDark)
                        Text("टॉपिक चुनें, प्रश्नों की संख्या तय करें और तुरंत टेस्ट दें", fontSize = 11.sp, color = TextSecondary)
                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = quizTopic,
                            onValueChange = { quizTopic = it },
                            label = { Text("Topic", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth().testTag("ai_quiz_topic_input"),
                            shape = RoundedCornerShape(8.dp)
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("प्रश्नों की संख्या (Number of Questions):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(5, 10, 20).forEach { cnt ->
                                FilterChip(
                                    selected = questionCount == cnt,
                                    onClick = { questionCount = cnt },
                                    label = { Text("$cnt प्रश्न") }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text("प्रकार (Question Type):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("MCQ", "TRUE_FALSE").forEach { type ->
                                FilterChip(
                                    selected = quizType == type,
                                    onClick = { quizType = type },
                                    label = { Text(if (type == "MCQ") "बहुविकल्पीय (MCQ)" else "सत्य/असत्य (True/False)") }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = {
                                viewModel.startAiQuiz(
                                    AiQuizConfig(
                                        topic = quizTopic,
                                        subject = "General Awareness",
                                        questionCount = questionCount,
                                        questionType = quizType
                                    )
                                )
                                currentQIndex = 0
                            },
                            enabled = !isLoading,
                            colors = ButtonDefaults.buttonColors(containerColor = BrandAmberPrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().testTag("start_ai_quiz_btn")
                        ) {
                            Text("क्विज़ शुरू करें (Start AI Quiz)", color = BrandNavyDark, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (isLoading) {
            item { LoadingCard("AI क्विज़ तैयार कर रहा है...", "उच्च गुणवत्ता वाले प्रश्न और सटीक विकल्प संकलित हो रहे हैं") }
        } else if (quizSession != null && !quizSession.isSubmitted) {
            val qList = quizSession.questions
            val safeIndex = currentQIndex.coerceIn(0, qList.size - 1)
            val currentQ = qList[safeIndex]
            val selectedOption = quizSession.userAnswers[safeIndex]

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("प्रश्न ${safeIndex + 1} / ${qList.size}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BrandAmberPrimary)
                            Surface(color = BrandNavyDark, shape = RoundedCornerShape(4.dp)) {
                                Text(quizSession.config.topic, fontSize = 10.sp, color = Color.White, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))

                        Text(currentQ.question, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, lineHeight = 20.sp, color = BrandNavyDark)
                        Spacer(modifier = Modifier.height(14.dp))

                        currentQ.options.forEachIndexed { optIdx, optText ->
                            val isSelected = selectedOption == optIdx
                            Surface(
                                color = if (isSelected) BrandAmberLight else SurfaceVariantCard,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .border(
                                        width = if (isSelected) 1.5.dp else 0.dp,
                                        color = if (isSelected) BrandAmberPrimary else Color.Transparent,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable { viewModel.answerQuizQuestion(safeIndex, optIdx) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = { viewModel.answerQuizQuestion(safeIndex, optIdx) },
                                        colors = RadioButtonDefaults.colors(selectedColor = BrandAmberPrimary)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(optText, fontSize = 13.sp, color = BrandNavyDark)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            OutlinedButton(
                                onClick = { if (currentQIndex > 0) currentQIndex-- },
                                enabled = currentQIndex > 0,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Previous")
                            }

                            if (currentQIndex < qList.size - 1) {
                                Button(
                                    onClick = { currentQIndex++ },
                                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Next")
                                }
                            } else {
                                Button(
                                    onClick = { viewModel.submitQuizSession() },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("submit_ai_quiz_btn")
                                ) {
                                    Text("Submit Quiz")
                                }
                            }
                        }
                    }
                }
            }
        } else if (quizSession != null && quizSession.isSubmitted) {
            // Quiz Result Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = BrandAmberPrimary, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("क्विज़ परिणाम (Quiz Scorecard)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = BrandNavyDark)
                        Text(quizSession.config.topic, fontSize = 12.sp, color = TextSecondary)
                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            MetricColumn("प्राप्तांक", "${quizSession.score}", BrandAmberPrimary)
                            MetricColumn("सटीकता", "${quizSession.accuracyPercentage.toInt()}%", EmeraldSuccess)
                            MetricColumn("सही", "${quizSession.correctCount}", EmeraldSuccess)
                            MetricColumn("गलत", "${quizSession.wrongCount}", RoseError)
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Text("प्रश्नों की समीक्षा एवं व्याख्या:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BrandNavyDark, modifier = Modifier.align(Alignment.Start))
                        Spacer(modifier = Modifier.height(8.dp))

                        quizSession.questions.forEachIndexed { idx, q ->
                            val userAns = quizSession.userAnswers[idx]
                            val isCorrect = userAns == q.correctOptionIndex
                            Surface(
                                color = if (isCorrect) EmeraldLight else RoseError.copy(alpha = 0.1f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text("Q${idx + 1}. ${q.question}", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = BrandNavyDark)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("सही उत्तर: ${q.options.getOrNull(q.correctOptionIndex) ?: ""}", fontSize = 11.sp, color = EmeraldSuccess, fontWeight = FontWeight.Bold)
                                    Text(q.explanation, fontSize = 11.sp, color = TextSecondary)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// =================================================================
// 5. AI TEST GENERATOR TAB
// =================================================================
@Composable
private fun AiTestGeneratorTab(
    viewModel: CrackExamViewModel,
    generatedTest: AiGeneratedTest?,
    isLoading: Boolean
) {
    var selectedCategory by remember { mutableStateOf(ExamCategory.RAILWAY) }
    var subject by remember { mutableStateOf("General Awareness") }
    var chapter by remember { mutableStateOf("Indian Polity") }
    var topic by remember { mutableStateOf("संसद एवं राष्ट्रपति की शक्तियां") }
    var difficulty by remember { mutableStateOf("Moderate") }
    var questionCount by remember { mutableStateOf(10) }
    var language by remember { mutableStateOf("Bilingual") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("AI Test Generator (कस्टम टेस्ट निर्माता)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BrandNavyDark)
                    Text("कस्टम पैरामीटर चुनें • Generated test रहेगा DRAFT / PRIVATE state में", fontSize = 11.sp, color = TextSecondary)
                    Spacer(modifier = Modifier.height(10.dp))

                    Text("परीक्षा श्रेणी (Exam Category):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(listOf(ExamCategory.RAILWAY, ExamCategory.SSC, ExamCategory.BANKING, ExamCategory.POLICE, ExamCategory.DEFENCE)) { cat ->
                            FilterChip(
                                selected = selectedCategory == cat,
                                onClick = { selectedCategory = cat },
                                label = { Text(cat.name, fontSize = 10.sp) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = topic,
                        onValueChange = { topic = it },
                        label = { Text("Topic Name", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth().testTag("ai_test_topic_input"),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = subject,
                            onValueChange = { subject = it },
                            label = { Text("Subject", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        )
                        OutlinedTextField(
                            value = chapter,
                            onValueChange = { chapter = it },
                            label = { Text("Chapter", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("कठिनाई (Difficulty):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Easy", "Moderate", "Hard").forEach { diff ->
                                FilterChip(
                                    selected = difficulty == diff,
                                    onClick = { difficulty = diff },
                                    label = { Text(diff, fontSize = 10.sp) }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("प्रश्नों की संख्या:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(10, 20, 30).forEach { cnt ->
                                FilterChip(
                                    selected = questionCount == cnt,
                                    onClick = { questionCount = cnt },
                                    label = { Text("$cnt") }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = {
                            viewModel.generateAiTest(
                                examCategory = selectedCategory,
                                subject = subject,
                                chapter = chapter,
                                topic = topic,
                                difficulty = difficulty,
                                count = questionCount,
                                language = language
                            )
                        },
                        enabled = !isLoading,
                        colors = ButtonDefaults.buttonColors(containerColor = BrandAmberPrimary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().testTag("ai_generate_test_btn")
                    ) {
                        Text("AI टेस्ट जनरेट करें (Generate Test)", color = BrandNavyDark, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (isLoading) {
            item { LoadingCard("AI टेस्ट संकलित कर रहा है...", "पैटर्न-आधारित प्रश्न, ऋणात्मक अंकन और द्विभाषी विकल्प तैयार हो रहे हैं") }
        } else if (generatedTest != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(generatedTest.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = BrandNavyDark)
                            Surface(color = BrandAmberLight, shape = RoundedCornerShape(4.dp)) {
                                Text(
                                    text = if (generatedTest.status == ReviewStatus.REVIEW) "IN REVIEW" else "PRIVATE DRAFT",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BrandNavyDark,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text("${generatedTest.examCategory.name} • ${generatedTest.subject} • ${generatedTest.durationMinutes} mins", fontSize = 11.sp, color = TextSecondary)
                        Spacer(modifier = Modifier.height(10.dp))

                        Text("शामिल प्रश्न (${generatedTest.questions.size} Questions):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BrandNavyDark)
                        Spacer(modifier = Modifier.height(6.dp))

                        generatedTest.questions.take(3).forEachIndexed { idx, q ->
                            Surface(color = SurfaceVariantCard, shape = RoundedCornerShape(6.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("Q${idx + 1}. ${q.questionHindi}", fontWeight = FontWeight.SemiBold, fontSize = 11.sp, color = BrandNavyDark)
                                    Text("व्याख्या: ${q.explanationHindi}", fontSize = 10.sp, color = TextSecondary)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = {
                                    // Start live test privately
                                    val examTest = ExamTest(
                                        id = generatedTest.id,
                                        examCategory = generatedTest.examCategory,
                                        testSeriesId = "TS-AI-PRIVATE",
                                        title = generatedTest.title,
                                        description = "Private AI generated practice session",
                                        durationMinutes = generatedTest.durationMinutes,
                                        totalQuestions = generatedTest.questions.size,
                                        totalMarks = generatedTest.totalMarks,
                                        negativeMarkRatio = 0.33,
                                        languages = listOf("Hindi", "English"),
                                        sections = listOf(generatedTest.subject),
                                        questions = generatedTest.questions
                                    )
                                    viewModel.startLiveTest(examTest)
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("अटेम्प्ट करें (Start Test)", fontSize = 11.sp)
                            }

                            if (generatedTest.status == ReviewStatus.DRAFT) {
                                Button(
                                    onClick = { viewModel.submitAiTestForPublicReview(generatedTest.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("समीक्षा हेतु भेजें", fontSize = 11.sp, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// =================================================================
// 6. REVISION ASSISTANT TAB
// =================================================================
@Composable
private fun AiRevisionTab(
    viewModel: CrackExamViewModel,
    revisionPkg: AiRevisionPackage?,
    isLoading: Boolean
) {
    var revTopic by remember { mutableStateOf("मौलिक अधिकार (Fundamental Rights)") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Revision Assistant (त्वरित पुनरावलोकन)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BrandNavyDark)
                    Text("क्विक रिवीजन, महत्वपूर्ण तथ्य, बारम्बार पूछे जाने वाले सिद्धांत एवं सामान्य गलतियां", fontSize = 11.sp, color = TextSecondary)
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = revTopic,
                        onValueChange = { revTopic = it },
                        modifier = Modifier.fillMaxWidth().testTag("ai_rev_topic_input"),
                        placeholder = { Text("उदा. मौलिक अधिकार / कार्य, ऊर्जा और शक्ति") },
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { viewModel.generateAiRevision(revTopic, "General Awareness") },
                        enabled = !isLoading,
                        colors = ButtonDefaults.buttonColors(containerColor = BrandAmberPrimary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().testTag("ai_generate_rev_btn")
                    ) {
                        Text("रिवीजन मॉड्यूल तैयार करें", color = BrandNavyDark, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (isLoading) {
            item { LoadingCard("रिवीजन संकलित हो रहा है...", "मुख्य बुलेट्स, अपवाद और अभ्यास प्रश्न तैयार हो रहे हैं") }
        } else if (revisionPkg != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(revisionPkg.topic, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BrandNavyDark)
                        Spacer(modifier = Modifier.height(10.dp))

                        Text("त्वरित रिवीजन (Quick Revision):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BrandAmberPrimary)
                        revisionPkg.quickRevision.forEach { Text(it, fontSize = 12.sp, color = TextPrimary) }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("महत्वपूर्ण तथ्य (Important Facts):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = EmeraldSuccess)
                        revisionPkg.importantFacts.forEach { Text(it, fontSize = 11.sp, color = TextPrimary) }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("अक्सर पूछे जाने वाले सिद्धांत (Frequently Tested):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BrandNavyLight)
                        revisionPkg.frequentlyTestedConcepts.forEach { Text("• $it", fontSize = 11.sp, color = TextPrimary) }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("बचने योग्य गलतियां (Mistakes to Avoid):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = RoseError)
                        revisionPkg.mistakesToAvoid.forEach { Text(it, fontSize = 11.sp, color = RoseError) }
                    }
                }
            }
        }
    }
}

// =================================================================
// 7. STUDY PLANNER TAB
// =================================================================
@Composable
private fun AiStudyPlannerTab(
    viewModel: CrackExamViewModel,
    studyPlan: AiStudyPlan?,
    isLoading: Boolean
) {
    var targetDate by remember { mutableStateOf("2026-06-30") }
    var dailyHours by remember { mutableStateOf(4) }
    var level by remember { mutableStateOf("Intermediate") }
    var selectedCategory by remember { mutableStateOf(ExamCategory.RAILWAY) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("AI Study Planner (स्मार्ट अध्ययन योजना)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BrandNavyDark)
                    Text("दैनिक लक्ष्य, समय आवंटन, रिवीजन व अभ्यास की व्यक्तिगत समय सारिणी", fontSize = 11.sp, color = TextSecondary)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = targetDate,
                            onValueChange = { targetDate = it },
                            label = { Text("Target Exam Date", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        )
                        OutlinedTextField(
                            value = "$dailyHours घंटे/दिन",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Daily Hours", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("दैनिक अध्ययन घंटे चुनें:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(2, 4, 6, 8).forEach { hrs ->
                            FilterChip(
                                selected = dailyHours == hrs,
                                onClick = { dailyHours = hrs },
                                label = { Text("$hrs hrs") }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            viewModel.generateAiStudyPlan(
                                exam = selectedCategory,
                                targetDate = targetDate,
                                dailyHours = dailyHours,
                                subjects = listOf("Mathematics", "General Science", "Reasoning", "Current Affairs"),
                                level = level
                            )
                        },
                        enabled = !isLoading,
                        colors = ButtonDefaults.buttonColors(containerColor = BrandAmberPrimary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().testTag("ai_generate_plan_btn")
                    ) {
                        Text("स्टडी प्लान तैयार करें (Generate Plan)", color = BrandNavyDark, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (isLoading) {
            item { LoadingCard("स्टडी प्लान तैयार हो रहा है...", "दैनिक स्लॉट, विषय संतुलन और अभ्यास लक्ष्य संकलित हो रहे हैं") }
        } else if (studyPlan != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("${studyPlan.targetExam.name} 7-Day Action Plan", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BrandNavyDark)
                        Text("Target: ${studyPlan.targetDate} • ${studyPlan.dailyHours} घंटे प्रतिदिन", fontSize = 11.sp, color = TextSecondary)
                        Spacer(modifier = Modifier.height(12.dp))

                        studyPlan.scheduleDays.forEach { day ->
                            Surface(
                                color = if (day.isCompleted) EmeraldLight else SurfaceVariantCard,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable { viewModel.toggleStudyPlanDay(studyPlan.id, day.dayNumber) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = day.isCompleted,
                                        onCheckedChange = { viewModel.toggleStudyPlanDay(studyPlan.id, day.dayNumber) },
                                        colors = CheckboxDefaults.colors(checkedColor = EmeraldSuccess)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(day.dayTitle, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BrandNavyDark)
                                        Text("${day.subject} • ${day.topic}", fontSize = 11.sp, color = TextPrimary)
                                        Text("रिवीजन: ${day.revisionTask} • लक्ष्य: ${day.practiceTargetQuestions} प्रश्न", fontSize = 10.sp, color = TextSecondary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// =================================================================
// 8. AI HISTORY TAB (Student Private Activity)
// =================================================================
@Composable
private fun AiHistoryTab(
    viewModel: CrackExamViewModel,
    historyList: List<AiHistoryItem>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("मेरी AI गतिविधि (AI History)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BrandNavyDark)
                        Surface(color = BrandAmberLight, shape = RoundedCornerShape(4.dp)) {
                            Text("निजी एवं सुरक्षित (Private)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BrandNavyDark, modifier = Modifier.padding(4.dp))
                        }
                    }
                    Text("आपके सभी प्रश्न, डाउट्स, नोट्स, क्विज़ और बनाए गए टेस्ट", fontSize = 11.sp, color = TextSecondary)
                }
            }
        }

        if (historyList.isEmpty()) {
            item {
                Surface(
                    color = SurfaceCard,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().padding(top = 20.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.History, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(40.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("कोई AI गतिविधि उपलब्ध नहीं है", fontWeight = FontWeight.Bold, color = TextSecondary)
                        Text("Q&A, Doubt Solver या AI Quiz का उपयोग करें", fontSize = 12.sp, color = TextSecondary)
                    }
                }
            }
        } else {
            items(historyList) { item ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(10.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = SurfaceVariantCard,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = item.activityType.label,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = BrandNavyDark,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(item.timestamp, fontSize = 10.sp, color = TextSecondary)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(item.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BrandNavyDark)
                            Text(item.subtitle, fontSize = 11.sp, color = TextSecondary, maxLines = 1)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { viewModel.toggleBookmarkHistory(item.id) }, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    if (item.isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                    contentDescription = "Bookmark",
                                    tint = if (item.isBookmarked) BrandAmberPrimary else TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            IconButton(onClick = { viewModel.deleteHistoryItem(item.id) }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = RoseError, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

// =================================================================
// 9. AI REVIEW QUEUE TAB (Authorized Roles Only)
// =================================================================
@Composable
private fun AiReviewQueueTab(
    viewModel: CrackExamViewModel,
    reviewQueue: List<AiReviewSubmission>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("AI सामग्री समीक्षा कतार (Review Queue)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BrandNavyDark)
                        Surface(color = RoseError.copy(alpha = 0.2f), shape = RoundedCornerShape(4.dp)) {
                            Text("AUTHORIZED ONLY", fontSize = 9.sp, fontWeight = FontWeight.Black, color = RoseError, modifier = Modifier.padding(4.dp))
                        }
                    }
                    Text("विद्यार्थियों द्वारा सबमिट किए गए AI नोट्स व टेस्ट्स का प्रकाशन अनुमोदन", fontSize = 11.sp, color = TextSecondary)
                }
            }
        }

        if (reviewQueue.isEmpty()) {
            item {
                Surface(color = SurfaceCard, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("समीक्षा हेतु कोई लंबित सामग्री नहीं है", fontWeight = FontWeight.Bold, color = TextSecondary)
                    }
                }
            }
        } else {
            items(reviewQueue) { sub ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(sub.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BrandNavyDark)
                            Surface(
                                color = if (sub.status == ReviewStatus.PUBLISHED) EmeraldLight else Color(0xFFFEF3C7),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = sub.status.name,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (sub.status == ReviewStatus.PUBLISHED) EmeraldSuccess else BrandNavyDark,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text("प्रकार: ${sub.contentType} • लेखक: ${sub.authorStudentName} (${sub.examCategory.name})", fontSize = 11.sp, color = TextSecondary)
                        Spacer(modifier = Modifier.height(10.dp))

                        if (sub.status != ReviewStatus.PUBLISHED) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { viewModel.approveAndPublishAiSubmission(sub.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("स्वीकृत कर प्रकाशित करें", fontSize = 11.sp)
                                }
                                OutlinedButton(
                                    onClick = { viewModel.rejectAiSubmission(sub.id, "Needs syllabus correction") },
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("अस्वीकार करें", fontSize = 11.sp, color = RoseError)
                                }
                            }
                        } else {
                            Text("यह सामग्री पब्लिक लाइब्रेरी में सफलतापूर्वक प्रकाशित हो चुकी है।", fontSize = 11.sp, color = EmeraldSuccess, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LoadingCard(title: String, subtitle: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            CircularProgressIndicator(color = BrandAmberPrimary, modifier = Modifier.size(36.dp), strokeWidth = 3.dp)
            Spacer(modifier = Modifier.height(12.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = BrandNavyDark)
            Text(subtitle, fontSize = 11.sp, color = TextSecondary)
        }
    }
}

@Composable
private fun MetricColumn(title: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = color)
        Text(title, fontSize = 11.sp, color = TextSecondary)
    }
}

package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*
import com.example.viewmodel.CrackExamViewModel
import com.example.viewmodel.ScreenDestination

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CoachingDashboardScreen(
    viewModel: CrackExamViewModel,
    modifier: Modifier = Modifier
) {
    val profile by viewModel.coachingProfile.collectAsState()
    val teachers by viewModel.teachers.collectAsState()
    val students by viewModel.coachingStudents.collectAsState()
    val batches by viewModel.coachingBatches.collectAsState()
    val timetable by viewModel.timetable.collectAsState()
    val attendanceRecords by viewModel.attendanceHistory.collectAsState()
    val notices by viewModel.notices.collectAsState()

    var activeTab by remember { mutableStateOf("Profile") }
    // Tabs: Profile, Teachers, Students, Batches, Courses, Attendance, Timetable, Notices

    var showEditProfileModal by remember { mutableStateOf(false) }
    var showAddTeacherModal by remember { mutableStateOf(false) }
    var showStudentAdmissionModal by remember { mutableStateOf(false) }
    var showCreateBatchModal by remember { mutableStateOf(false) }
    var showTakeAttendanceModal by remember { mutableStateOf(false) }
    var showAddTimetableModal by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NeutralBg)
    ) {
        // Coaching Management Header
        Surface(
            color = BrandNavyDark,
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { viewModel.navigateTo(ScreenDestination.Home) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "कोचिंग प्रबंधन (Coaching Management)",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                            Text(
                                text = profile.coachingName,
                                fontSize = 11.sp,
                                color = BrandAmberPrimary
                            )
                        }
                    }

                    Surface(
                        color = BrandAmberLight,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "STAFF ACCESS",
                            color = BrandNavyDark,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Navigation Tabs
                val tabsList = listOf("Profile", "Teachers", "Students", "Batches", "Courses", "Attendance", "Timetable", "Notices")
                ScrollableTabRow(
                    selectedTabIndex = tabsList.indexOf(activeTab),
                    edgePadding = 0.dp,
                    containerColor = Color.Transparent,
                    divider = {}
                ) {
                    tabsList.forEach { tab ->
                        val isSelected = activeTab == tab
                        Tab(
                            selected = isSelected,
                            onClick = { activeTab = tab },
                            text = {
                                Text(
                                    text = when (tab) {
                                        "Profile" -> "प्रोफाइल"
                                        "Teachers" -> "फैकल्टी (${teachers.size})"
                                        "Students" -> "विद्यार्थी (${students.size})"
                                        "Batches" -> "बैच (${batches.size})"
                                        "Courses" -> "कोर्स"
                                        "Attendance" -> "उपस्थिति"
                                        "Timetable" -> "टाइम-टेबल"
                                        else -> "सूचना"
                                    },
                                    color = if (isSelected) BrandAmberPrimary else Color(0xFFCBD5E1),
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 12.sp
                                )
                            }
                        )
                    }
                }
            }
        }

        // Tab Body Content
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (activeTab) {
                "Profile" -> {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            shape = RoundedCornerShape(14.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(profile.coachingName, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = BrandNavyDark)
                                    IconButton(onClick = { showEditProfileModal = true }) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit Profile", tint = BrandAmberDark)
                                    }
                                }
                                Text(profile.tagline, fontSize = 12.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
                                Spacer(modifier = Modifier.height(10.dp))
                                Divider(color = Color(0xFFE2E8F0))
                                Spacer(modifier = Modifier.height(10.dp))

                                DetailRow("पता (Address)", profile.address)
                                DetailRow("संपर्क (Phone)", profile.contactPhone)
                                DetailRow("ईमेल (Email)", profile.contactEmail)
                                DetailRow("वेबसाइट (Website)", profile.website)

                                Spacer(modifier = Modifier.height(8.dp))
                                Text(profile.description, fontSize = 12.sp, color = TextPrimary, lineHeight = 18.sp)
                            }
                        }
                    }
                }

                "Teachers" -> {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("फैकल्टी व शिक्षक सूची (${teachers.size})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Button(
                                onClick = { showAddTeacherModal = true },
                                colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = BrandAmberPrimary)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("नया शिक्षक जोड़ें", fontSize = 11.sp, color = BrandAmberPrimary)
                            }
                        }
                    }

                    items(teachers) { tch ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            shape = RoundedCornerShape(12.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(tch.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextPrimary)
                                    Surface(color = EmeraldLight, shape = RoundedCornerShape(4.dp)) {
                                        Text(tch.status, color = EmeraldSuccess, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("विषय: ${tch.assignedSubjects.joinToString(", ")}", fontSize = 12.sp, color = TextSecondary)
                                Text("मोबाइल: ${tch.mobile} • योग्यता: ${tch.qualification}", fontSize = 11.sp, color = TextSecondary)
                            }
                        }
                    }
                }

                "Students" -> {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("पंजीकृत छात्र सूची (${students.size})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Button(
                                onClick = { showStudentAdmissionModal = true },
                                colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp), tint = BrandAmberPrimary)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("नया प्रवेश", fontSize = 11.sp, color = BrandAmberPrimary)
                            }
                        }
                    }

                    items(students) { stu ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            shape = RoundedCornerShape(12.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(stu.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                                    Text("आईडी: ${stu.studentId} • बैच: ${stu.batchName}", fontSize = 11.sp, color = TextSecondary)
                                    Text("अभिभावक: ${stu.parentName} (${stu.parentPhone})", fontSize = 10.sp, color = TextMuted)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Surface(color = if (stu.attendancePercent >= 90) EmeraldLight else BrandAmberLight, shape = RoundedCornerShape(4.dp)) {
                                        Text("${stu.attendancePercent}% हाजिरी", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("रैंक #${stu.performanceRank}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = BlueInfo)
                                }
                            }
                        }
                    }
                }

                "Batches" -> {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("सक्रिय कोचिंग बैच (${batches.size})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Button(
                                onClick = { showCreateBatchModal = true },
                                colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = BrandAmberPrimary)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("नया बैच जोड़ें", fontSize = 11.sp, color = BrandAmberPrimary)
                            }
                        }
                    }

                    items(batches) { b ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            shape = RoundedCornerShape(12.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(b.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextPrimary)
                                    Surface(color = EmeraldLight, shape = RoundedCornerShape(4.dp)) {
                                        Text(b.status, color = EmeraldSuccess, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("फैकल्टी: ${b.facultyName} • ${b.subject}", fontSize = 12.sp, color = TextSecondary)
                                Text("समय: ${b.timing} | कक्ष: ${b.room}", fontSize = 11.sp, color = TextSecondary)
                            }
                        }
                    }
                }

                "Courses" -> {
                    item {
                        Text("कोर्स संरचना (Course → Subject → Chapter → Topic)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("1. Railway Comprehensive Selection Course 2026", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("• Subject: General Science → Physics → Newton's Laws (5 Topics)", fontSize = 11.sp, color = TextSecondary)
                                Text("• Subject: Mathematics → Arithmetic → Trains & Distance (8 Topics)", fontSize = 11.sp, color = TextSecondary)
                                Text("• Subject: Reasoning → Series & Analogy (10 Topics)", fontSize = 11.sp, color = TextSecondary)
                            }
                        }
                    }
                }

                "Attendance" -> {
                    item {
                        Button(
                            onClick = { showTakeAttendanceModal = true },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().height(44.dp)
                        ) {
                            Icon(Icons.Default.FactCheck, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("आज की हाजिरी दर्ज करें (Take Daily Attendance)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }

                    items(attendanceRecords) { att ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(att.batchName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("तारीख: ${att.date}", fontSize = 11.sp, color = TextSecondary)
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Surface(color = EmeraldLight, shape = RoundedCornerShape(4.dp)) {
                                        Text("उपस्थित: ${att.totalPresent}", color = EmeraldSuccess, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
                                    }
                                    Surface(color = RoseLight, shape = RoundedCornerShape(4.dp)) {
                                        Text("अनुपस्थित: ${att.totalAbsent}", color = RoseError, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                "Timetable" -> {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("साप्ताहिक टाइम-टेबल (Weekly Schedule)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Button(
                                onClick = { showAddTimetableModal = true },
                                colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = BrandAmberPrimary)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("कक्षा जोड़ें", fontSize = 11.sp, color = BrandAmberPrimary)
                            }
                        }
                    }

                    items(timetable) { tt ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("${tt.dayOfWeek}: ${tt.subject}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                                    Text("${tt.batchName} • फैकल्टी: ${tt.teacherName}", fontSize = 11.sp, color = TextSecondary)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(tt.timeSlot, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlueInfo)
                                    Text(tt.room, fontSize = 10.sp, color = TextMuted)
                                }
                            }
                        }
                    }
                }

                "Notices" -> {
                    items(notices) { notice ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Surface(color = BrandAmberLight, shape = RoundedCornerShape(4.dp)) {
                                        Text(notice.category, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BrandNavyDark, modifier = Modifier.padding(4.dp))
                                    }
                                    Text(notice.timestamp, fontSize = 10.sp, color = TextSecondary)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(notice.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(notice.description, fontSize = 12.sp, color = TextSecondary, lineHeight = 16.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal: Edit Profile
    if (showEditProfileModal) {
        var name by remember { mutableStateOf(profile.coachingName) }
        var phone by remember { mutableStateOf(profile.contactPhone) }
        var addr by remember { mutableStateOf(profile.address) }

        AlertDialog(
            onDismissRequest = { showEditProfileModal = false },
            title = { Text("कोचिंग प्रोफाइल संपादित करें", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("कोचिंग का नाम") })
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("संपर्क फोन") })
                    OutlinedTextField(value = addr, onValueChange = { addr = it }, label = { Text("पता (Address)") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateCoachingProfile(profile.copy(coachingName = name, contactPhone = phone, address = addr))
                        showEditProfileModal = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark)
                ) { Text("सुरक्षित करें", color = BrandAmberPrimary) }
            },
            dismissButton = { TextButton(onClick = { showEditProfileModal = false }) { Text("रद्द करें") } }
        )
    }

    // Modal: Add Teacher
    if (showAddTeacherModal) {
        var tchName by remember { mutableStateOf("") }
        var tchPhone by remember { mutableStateOf("") }
        var tchSubject by remember { mutableStateOf("Mathematics") }

        AlertDialog(
            onDismissRequest = { showAddTeacherModal = false },
            title = { Text("नया शिक्षक जोड़ें", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = tchName, onValueChange = { tchName = it }, label = { Text("शिक्षक का नाम") })
                    OutlinedTextField(value = tchPhone, onValueChange = { tchPhone = it }, label = { Text("मोबाइल नंबर") })
                    OutlinedTextField(value = tchSubject, onValueChange = { tchSubject = it }, label = { Text("विषय (Subjects)") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (tchName.isNotBlank()) {
                            viewModel.addTeacher(
                                TeacherRecord(
                                    id = "TCH-${System.currentTimeMillis()}",
                                    name = tchName,
                                    mobile = tchPhone.ifBlank { "+91 98000 00000" },
                                    email = "${tchName.lowercase().replace(" ", "")}@crackexam.in",
                                    assignedSubjects = listOf(tchSubject),
                                    assignedBatches = listOf("BATCH-01"),
                                    qualification = "M.Sc / Expert"
                                )
                            )
                            showAddTeacherModal = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark)
                ) { Text("जोड़ें", color = BrandAmberPrimary) }
            },
            dismissButton = { TextButton(onClick = { showAddTeacherModal = false }) { Text("रद्द करें") } }
        )
    }

    // Modal: Add Timetable
    if (showAddTimetableModal) {
        var day by remember { mutableStateOf("Wednesday") }
        var slot by remember { mutableStateOf("09:00 AM - 11:30 AM") }
        var sub by remember { mutableStateOf("Reasoning Ability") }

        AlertDialog(
            onDismissRequest = { showAddTimetableModal = false },
            title = { Text("कक्षा टाइम-टेबल जोड़ें", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = day, onValueChange = { day = it }, label = { Text("वार (Day of Week)") })
                    OutlinedTextField(value = sub, onValueChange = { sub = it }, label = { Text("विषय (Subject)") })
                    OutlinedTextField(value = slot, onValueChange = { slot = it }, label = { Text("समय स्लॉट (Time Slot)") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addTimetableEntry(
                            TimetableEntry(
                                id = "TT-${System.currentTimeMillis()}",
                                batchId = "BATCH-01",
                                batchName = "RRB NTPC 2026 Alpha Batch",
                                subject = sub,
                                teacherName = "Er. Rajesh Verma",
                                room = "Room 101",
                                dayOfWeek = day,
                                timeSlot = slot
                            )
                        )
                        showAddTimetableModal = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark)
                ) { Text("शेड्यूल करें", color = BrandAmberPrimary) }
            },
            dismissButton = { TextButton(onClick = { showAddTimetableModal = false }) { Text("रद्द करें") } }
        )
    }

    // Modal: Create Batch
    if (showCreateBatchModal) {
        var batchName by remember { mutableStateOf("") }
        var faculty by remember { mutableStateOf("") }
        var timing by remember { mutableStateOf("08:00 AM - 10:30 AM") }

        AlertDialog(
            onDismissRequest = { showCreateBatchModal = false },
            title = { Text("नया कोचिंग बैच बनाएं", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = batchName, onValueChange = { batchName = it }, label = { Text("बैच का नाम") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = faculty, onValueChange = { faculty = it }, label = { Text("फैकल्टी का नाम") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = timing, onValueChange = { timing = it }, label = { Text("समय") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (batchName.isNotBlank()) {
                            viewModel.addCoachingBatch(
                                CoachingBatch(
                                    id = "BATCH-${System.currentTimeMillis()}",
                                    name = batchName,
                                    examTarget = ExamCategory.RAILWAY,
                                    facultyName = faculty.ifBlank { "Senior Faculty" },
                                    subject = "All Core Subjects",
                                    timing = timing,
                                    totalStudents = 1,
                                    room = "Room 105"
                                )
                            )
                            showCreateBatchModal = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark)
                ) { Text("बैच सेव करें", color = BrandAmberPrimary) }
            },
            dismissButton = { TextButton(onClick = { showCreateBatchModal = false }) { Text("रद्द करें") } }
        )
    }

    // Modal: Take Attendance
    if (showTakeAttendanceModal) {
        var presentCount by remember { mutableStateOf("115") }
        var absentCount by remember { mutableStateOf("5") }

        AlertDialog(
            onDismissRequest = { showTakeAttendanceModal = false },
            title = { Text("दैनिक उपस्थिति दर्ज करें", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("बैच: RRB NTPC 2026 Alpha Batch", fontSize = 12.sp, color = TextSecondary)
                    OutlinedTextField(value = presentCount, onValueChange = { presentCount = it }, label = { Text("उपस्थित छात्र") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = absentCount, onValueChange = { absentCount = it }, label = { Text("अनुपस्थित छात्र") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val p = presentCount.toIntOrNull() ?: 0
                        val a = absentCount.toIntOrNull() ?: 0
                        viewModel.recordDailyAttendance("BATCH-01", p, a, 0)
                        showTakeAttendanceModal = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                ) { Text("हाजिरी सुरक्षित करें", color = Color.White) }
            },
            dismissButton = { TextButton(onClick = { showTakeAttendanceModal = false }) { Text("रद्द करें") } }
        )
    }

    // Modal: Student Admission
    if (showStudentAdmissionModal) {
        var stuName by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showStudentAdmissionModal = false },
            title = { Text("नया छात्र प्रवेश (Student Admission)", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = stuName, onValueChange = { stuName = it }, label = { Text("छात्र का पूरा नाम") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("मोबाइल नंबर") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (stuName.isNotBlank()) {
                            viewModel.addCoachingStudent(
                                StudentRecord(
                                    studentId = "STU-${(100..999).random()}",
                                    name = stuName,
                                    phone = phone.ifBlank { "+91 98000 00000" },
                                    email = "${stuName.lowercase().replace(" ", "")}@example.com",
                                    batchId = "BATCH-01",
                                    batchName = "RRB NTPC Alpha",
                                    attendancePercent = 100,
                                    performanceRank = (50..120).random(),
                                    admissionDate = "Today"
                                )
                            )
                            showStudentAdmissionModal = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark)
                ) { Text("प्रवेश पूरा करें", color = BrandAmberPrimary) }
            },
            dismissButton = { TextButton(onClick = { showStudentAdmissionModal = false }) { Text("रद्द करें") } }
        )
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 11.sp, color = TextSecondary)
        Text(value, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
    }
}

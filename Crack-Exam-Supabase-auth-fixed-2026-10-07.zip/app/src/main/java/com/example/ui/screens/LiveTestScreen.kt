package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ExamTest
import com.example.model.Question
import com.example.ui.theme.*
import com.example.viewmodel.CrackExamViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveTestScreen(
    test: ExamTest,
    viewModel: CrackExamViewModel,
    modifier: Modifier = Modifier
) {
    val activeAnswers by viewModel.activeTestAnswers.collectAsState()
    val markedForReview by viewModel.markedForReview.collectAsState()
    val currentIndex by viewModel.currentQuestionIndex.collectAsState()
    val userLang by viewModel.preferredLanguage.collectAsState()

    var showPaletteModal by remember { mutableStateOf(false) }
    var showSubmitConfirmation by remember { mutableStateOf(false) }
    var remainingSeconds by remember { mutableStateOf(test.durationMinutes * 60) }

    // Live countdown timer
    LaunchedEffect(Unit) {
        while (remainingSeconds > 0) {
            delay(1000)
            remainingSeconds--
        }
        // Auto-submit when timer expires
        viewModel.submitCurrentTest(test, test.durationMinutes * 60)
    }

    val questions = test.questions
    val currentQ = questions.getOrNull(currentIndex) ?: questions.first()
    val minutesLeft = remainingSeconds / 60
    val secondsLeft = remainingSeconds % 60
    val timerColor = if (minutesLeft < 5) RoseError else BrandAmberPrimary

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NeutralBg)
    ) {
        // Test Header: Title, Timer, Language toggle & Palette trigger
        Surface(
            color = BrandNavyDark,
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = test.title,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color.White,
                            maxLines = 1
                        )
                        Text(
                            text = "नेगेटिव मार्किंग: 1/${(1.0 / test.negativeMarkRatio).toInt()} | कुल अंक: ${test.totalMarks.toInt()}",
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }

                    // Remaining Timer Badge
                    Surface(
                        color = timerColor.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.border(1.dp, timerColor, RoundedCornerShape(8.dp))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                Icons.Default.Timer,
                                contentDescription = null,
                                tint = timerColor,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = String.format("%02d:%02d", minutesLeft, secondsLeft),
                                color = timerColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = { showPaletteModal = true },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(BrandNavyLight)
                            .testTag("question_palette_btn")
                    ) {
                        Icon(Icons.Default.GridView, contentDescription = "Palette", tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Section Chips / Tabs
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    itemsIndexed(test.sections) { index, sectionName ->
                        val isSectionActive = currentQ.subject.equals(sectionName, ignoreCase = true) || index == 0
                        Surface(
                            color = if (isSectionActive) BrandAmberPrimary else BrandNavy,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.clickable { /* Select Section */ }
                        ) {
                            Text(
                                text = sectionName,
                                fontSize = 11.sp,
                                fontWeight = if (isSectionActive) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSectionActive) Color.Black else Color.LightGray,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        // Active Question Card with Bilingual Display & Options
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Question Status Indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "प्रश्न ${currentIndex + 1} / ${questions.size}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = BrandNavyDark
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = EmeraldLight,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "+${currentQ.marks} अंक",
                            color = EmeraldSuccess,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        color = RoseLight,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "-${currentQ.negativeMarks} अंक",
                            color = RoseError,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Question Statement (Hindi and English bilingual presentation)
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = currentQ.questionHindi,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        color = TextPrimary,
                        lineHeight = 22.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = currentQ.questionEnglish,
                        fontSize = 13.sp,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Options Selector
            val selectedIndices = activeAnswers[currentQ.id] ?: emptyList()
            val optionLabels = listOf("A", "B", "C", "D")

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                currentQ.optionsHindi.forEachIndexed { optIndex, optTextHindi ->
                    val optTextEnglish = currentQ.optionsEnglish.getOrNull(optIndex) ?: ""
                    val isSelected = selectedIndices.contains(optIndex)

                    Surface(
                        color = if (isSelected) BrandNavyDark else SurfaceCard,
                        shape = RoundedCornerShape(12.dp),
                        shadowElevation = if (isSelected) 3.dp else 1.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.selectAnswer(currentQ.id, optIndex)
                            }
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) BrandAmberPrimary else Color(0xFFE2E8F0),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .testTag("option_${currentQ.id}_$optIndex")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) BrandAmberPrimary else SurfaceVariantCard),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = optionLabels.getOrElse(optIndex) { "${optIndex + 1}" },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (isSelected) Color.Black else TextPrimary
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = optTextHindi,
                                    fontSize = 14.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else TextPrimary
                                )
                                if (optTextEnglish.isNotBlank() && optTextEnglish != optTextHindi) {
                                    Text(
                                        text = optTextEnglish,
                                        fontSize = 12.sp,
                                        color = if (isSelected) Color(0xFFCBD5E1) else TextSecondary
                                    )
                                }
                            }

                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = BrandAmberPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Test Action Controls (Next, Previous, Mark for Review, Clear Response, Save & Next)
        Surface(
            color = SurfaceCard,
            shadowElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val isMarked = markedForReview.contains(currentQ.id)

                    OutlinedButton(
                        onClick = { viewModel.toggleMarkForReview(currentQ.id) },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = if (isMarked) PurpleAccent else TextSecondary
                        ),
                        modifier = Modifier.testTag("mark_for_review_btn")
                    ) {
                        Icon(
                            imageVector = if (isMarked) Icons.Default.BookmarkAdded else Icons.Default.BookmarkBorder,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isMarked) "समीक्षा हेतु चिन्हित" else "Mark for Review", fontSize = 11.sp)
                    }

                    TextButton(
                        onClick = { viewModel.clearAnswer(currentQ.id) },
                        modifier = Modifier.testTag("clear_response_btn")
                    ) {
                        Text("Clear", color = RoseError, fontSize = 12.sp)
                    }

                    Button(
                        onClick = { showSubmitConfirmation = true },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("submit_test_btn")
                    ) {
                        Text("Submit Test", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    OutlinedButton(
                        onClick = {
                            if (currentIndex > 0) viewModel.setQuestionIndex(currentIndex - 1)
                        },
                        enabled = currentIndex > 0,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("prev_question_btn")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("पिछला (Previous)", fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Button(
                        onClick = {
                            if (currentIndex < questions.size - 1) {
                                viewModel.setQuestionIndex(currentIndex + 1)
                            } else {
                                showSubmitConfirmation = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_and_next_btn")
                    ) {
                        Text(if (currentIndex < questions.size - 1) "Save & Next" else "Submit", fontSize = 12.sp, color = BrandAmberPrimary, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp), tint = BrandAmberPrimary)
                    }
                }
            }
        }
    }

    // Question Palette Modal Sheet
    if (showPaletteModal) {
        AlertDialog(
            onDismissRequest = { showPaletteModal = false },
            title = {
                Text(
                    "प्रश्न पैलेट (Question Palette)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column {
                    // Palette Legend
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LegendItem("हल किया (${activeAnswers.size})", EmeraldSuccess)
                        LegendItem("समीक्षा (${markedForReview.size})", PurpleAccent)
                        LegendItem("छोड़ा (${questions.size - activeAnswers.size})", TextMuted)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(5),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.height(240.dp)
                    ) {
                        items(questions.size) { idx ->
                            val qItem = questions[idx]
                            val isAns = activeAnswers.containsKey(qItem.id)
                            val isRev = markedForReview.contains(qItem.id)
                            val isCurr = idx == currentIndex

                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        when {
                                            isCurr -> BrandAmberPrimary
                                            isRev -> PurpleAccent
                                            isAns -> EmeraldSuccess
                                            else -> SurfaceVariantCard
                                        }
                                    )
                                    .clickable {
                                        viewModel.setQuestionIndex(idx)
                                        showPaletteModal = false
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${idx + 1}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (isCurr) Color.Black else if (isAns || isRev) Color.White else TextPrimary
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showPaletteModal = false },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark)
                ) {
                    Text("बंद करें (Close)", color = BrandAmberPrimary)
                }
            }
        )
    }

    // Submit Confirmation Dialog
    if (showSubmitConfirmation) {
        AlertDialog(
            onDismissRequest = { showSubmitConfirmation = false },
            icon = { Icon(Icons.Default.HelpOutline, contentDescription = null, tint = BrandAmberPrimary) },
            title = { Text("क्या आप टेस्ट सबमिट करना चाहते हैं?", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("प्रतियोगी परीक्षा सबमिशन सारांश:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("• कुल प्रश्न: ${questions.size}")
                    Text("• आपने हल किए: ${activeAnswers.size} प्रश्न")
                    Text("• समीक्षा हेतु चिन्हित: ${markedForReview.size} प्रश्न")
                    Text("• शेष समय: $minutesLeft मिनट $secondsLeft सेकंड")
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "सबमिट करने के बाद आपका All India Rank, Percentile एवं विस्तृत समाधान तुरंत प्रदर्शित होगा।",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSubmitConfirmation = false
                        val timeSpent = (test.durationMinutes * 60) - remainingSeconds
                        viewModel.submitCurrentTest(test, timeSpent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                    modifier = Modifier.testTag("confirm_final_submit_btn")
                ) {
                    Text("हां, सबमिट करें (Submit)", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showSubmitConfirmation = false }) {
                    Text("वापस टेस्ट पर जाएं")
                }
            }
        )
    }
}

@Composable
fun LegendItem(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(color))
        Spacer(modifier = Modifier.width(4.dp))
        Text(label, fontSize = 11.sp, color = TextPrimary)
    }
}

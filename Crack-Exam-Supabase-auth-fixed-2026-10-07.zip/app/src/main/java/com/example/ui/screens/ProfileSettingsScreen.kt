package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ExamCategory
import com.example.model.UserRole
import com.example.ui.theme.*
import com.example.viewmodel.CrackExamViewModel
import com.example.viewmodel.ScreenDestination

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileSettingsScreen(
    viewModel: CrackExamViewModel,
    modifier: Modifier = Modifier
) {
    val user by viewModel.currentUser.collectAsState()
    val selectedExam by viewModel.selectedExam.collectAsState()
    var showRoleModal by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NeutralBg)
    ) {
        // Toolbar
        Surface(
            color = BrandNavyDark,
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.Home) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "प्रोफाइल एवं सेटिंग्स (Profile & Roles)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Profile Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(BrandNavyDark),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = user.fullName.take(2).uppercase(),
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = BrandAmberPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(user.fullName, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = BrandNavyDark)
                        Text(user.email, fontSize = 12.sp, color = TextSecondary)
                        Text(user.mobile, fontSize = 12.sp, color = TextSecondary)

                        Spacer(modifier = Modifier.height(12.dp))

                        Surface(
                            color = when (user.role) {
                                UserRole.STUDENT -> EmeraldLight
                                UserRole.SUPER_ADMIN, UserRole.EXAM_ADMIN -> RoseLight
                                else -> BlueLight
                            },
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.clickable { showRoleModal = true }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "भूमिका: ${user.role.displayName}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (user.role) {
                                        UserRole.STUDENT -> EmeraldSuccess
                                        UserRole.SUPER_ADMIN, UserRole.EXAM_ADMIN -> RoseError
                                        else -> BlueInfo
                                    }
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }

            // Role Switcher Section (Role-based testing)
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("रोल स्विचर (Role Access System)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Surface(color = BrandAmberLight, shape = RoundedCornerShape(4.dp)) {
                                Text("RBAC Active", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            "विभिन्न अनुमतियों (Student vs Teacher vs Test Creator vs Super Admin) का परीक्षण करने हेतु भूमिका बदलें:",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        UserRole.values().forEach { role ->
                            val isSelected = user.role == role
                            Surface(
                                color = if (isSelected) BrandNavyDark else SurfaceVariantCard,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        viewModel.switchRole(role)
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = role.displayName,
                                        fontSize = 13.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) Color.White else TextPrimary
                                    )
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = BrandAmberPrimary)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Target Exam Configuration
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("लक्ष्य परीक्षा (Target Exam Preference)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(10.dp))

                        ExamCategory.values().forEach { exam ->
                            val isSelected = selectedExam == exam
                            Surface(
                                color = if (isSelected) BrandAmberLight else SurfaceVariantCard,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable { viewModel.selectExam(exam) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${exam.titleEnglish} (${exam.titleHindi})",
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = BrandNavyDark
                                    )
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = BrandNavyDark)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // App Administration Shortcuts (Role Protected)
            item {
                if (user.role.level >= UserRole.TEACHER.level) {
                    Button(
                        onClick = { viewModel.navigateTo(ScreenDestination.CoachingDashboard) },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().height(46.dp)
                    ) {
                        Icon(Icons.Default.School, contentDescription = null, tint = BrandAmberPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("कोचिंग प्रबंधन डैशबोर्ड (Coaching Center)", color = BrandAmberPrimary, fontWeight = FontWeight.Bold)
                    }
                }
            }

            item {
                if (user.role.level >= UserRole.TEST_CREATOR.level) {
                    Button(
                        onClick = { viewModel.navigateTo(ScreenDestination.TestBuilder) },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandNavyDark),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().height(46.dp)
                    ) {
                        Icon(Icons.Default.Build, contentDescription = null, tint = BrandAmberPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("एडवांस्ड टेस्ट बिल्डर (Test Builder)", color = BrandAmberPrimary, fontWeight = FontWeight.Bold)
                    }
                }
            }

            item {
                if (user.role.level >= UserRole.FINANCE_ADMIN.level) {
                    Button(
                        onClick = { viewModel.navigateTo(ScreenDestination.AdminDashboard) },
                        colors = ButtonDefaults.buttonColors(containerColor = RoseError),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().height(46.dp)
                    ) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("एडमिन कंट्रोल सेंटर (Admin Control Center)", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showRoleModal) {
        AlertDialog(
            onDismissRequest = { showRoleModal = false },
            title = { Text("भूमिका बदलें (Switch Role)", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    UserRole.values().forEach { role ->
                        TextButton(
                            onClick = {
                                viewModel.switchRole(role)
                                showRoleModal = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(role.displayName, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showRoleModal = false }) { Text("बंद करें") }
            }
        )
    }
}

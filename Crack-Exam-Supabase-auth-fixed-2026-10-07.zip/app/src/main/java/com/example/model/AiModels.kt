package com.example.model

enum class AiActivityType(val label: String, val iconName: String) {
    QUESTION_ANSWER("AI Question Answer", "QuestionAnswer"),
    DOUBT_SOLVER("AI Doubt Solver", "HelpOutline"),
    NOTES("AI Notes", "MenuBook"),
    QUIZ("AI Quiz", "Quiz"),
    TEST_GENERATOR("AI Test Generator", "Assignment"),
    REVISION("Revision Assistant", "Psychology"),
    STUDY_PLANNER("Study Planner", "DateRange")
}

data class AiQuestionAnswer(
    val id: String,
    val studentId: String,
    val question: String,
    val language: String,
    val explanation: String,
    val importantPoints: List<String>,
    val examples: List<String>,
    val examFacts: List<String>,
    val timestamp: String,
    val isBookmarked: Boolean = false
)

data class AiDoubtItem(
    val id: String,
    val studentId: String,
    val textQuestion: String,
    val imageUri: String? = null,
    val subject: String,
    val topic: String,
    val stepByStepExplanation: List<String>,
    val finalAnswer: String,
    val shortcutTrick: String,
    val importantExamPoint: String,
    val timestamp: String,
    val isBookmarked: Boolean = false
)

data class AiNoteDraft(
    val id: String,
    val studentId: String,
    val topic: String,
    val subject: String,
    val examCategory: ExamCategory,
    val shortSummary: String,
    val detailedExplanation: String,
    val importantFacts: List<String>,
    val keyPoints: List<String>,
    val revisionPoints: List<String>,
    val examTricks: List<String>,
    val status: ReviewStatus = ReviewStatus.DRAFT,
    val isPublic: Boolean = false,
    val createdAt: String,
    val isBookmarked: Boolean = false
)

data class AiQuizConfig(
    val topic: String,
    val subject: String,
    val questionCount: Int = 5,
    val questionType: String = "MCQ", // "MCQ" or "TRUE_FALSE"
    val hasTimer: Boolean = false,
    val timerSeconds: Int = 300
)

data class AiQuizQuestion(
    val id: String,
    val question: String,
    val options: List<String>,
    val correctOptionIndex: Int,
    val explanation: String,
    val isTrueFalse: Boolean = false
)

data class AiQuizSession(
    val id: String,
    val studentId: String,
    val config: AiQuizConfig,
    val questions: List<AiQuizQuestion>,
    val userAnswers: Map<Int, Int> = emptyMap(),
    val isSubmitted: Boolean = false,
    val score: Double = 0.0,
    val correctCount: Int = 0,
    val wrongCount: Int = 0,
    val accuracyPercentage: Double = 0.0,
    val timeTakenSeconds: Int = 0,
    val completedAt: String = ""
)

data class AiGeneratedTest(
    val id: String,
    val studentId: String,
    val title: String,
    val examCategory: ExamCategory,
    val subject: String,
    val chapter: String,
    val topic: String,
    val difficulty: String,
    val questionCount: Int,
    val language: String,
    val questions: List<Question>,
    val totalMarks: Double,
    val durationMinutes: Int,
    val status: ReviewStatus = ReviewStatus.DRAFT,
    val isPublic: Boolean = false,
    val createdAt: String
)

data class AiRevisionPackage(
    val id: String,
    val studentId: String,
    val topic: String,
    val subject: String,
    val quickRevision: List<String>,
    val importantFacts: List<String>,
    val frequentlyTestedConcepts: List<String>,
    val mistakesToAvoid: List<String>,
    val practiceQuestions: List<Question>,
    val timestamp: String,
    val isBookmarked: Boolean = false
)

data class StudyPlanDay(
    val dayNumber: Int,
    val dayTitle: String,
    val subject: String,
    val topic: String,
    val durationMinutes: Int,
    val revisionTask: String,
    val practiceTargetQuestions: Int,
    val isCompleted: Boolean = false
)

data class AiStudyPlan(
    val id: String,
    val studentId: String,
    val targetExam: ExamCategory,
    val targetDate: String,
    val dailyHours: Int,
    val subjects: List<String>,
    val preparationLevel: String,
    val scheduleDays: List<StudyPlanDay>,
    val createdAt: String
)

data class AiHistoryItem(
    val id: String,
    val studentId: String,
    val activityType: AiActivityType,
    val title: String,
    val subtitle: String,
    val timestamp: String,
    val referenceId: String,
    val isBookmarked: Boolean = false
)

data class AiReviewSubmission(
    val id: String,
    val contentId: String,
    val contentType: String, // "NOTE", "TEST", "QUESTION"
    val title: String,
    val authorStudentName: String,
    val authorStudentId: String,
    val examCategory: ExamCategory,
    val subject: String,
    val status: ReviewStatus = ReviewStatus.REVIEW,
    val reviewerFeedback: String = "",
    val submittedAt: String
)

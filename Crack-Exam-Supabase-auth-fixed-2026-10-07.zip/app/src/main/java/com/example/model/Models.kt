package com.example.model

enum class UserRole(val displayName: String, val level: Int) {
    STUDENT("Student / Aspirant", 1),
    TEACHER("Faculty / Teacher", 2),
    TEST_CREATOR("Test Creator", 3),
    CONTENT_ADMIN("Content Admin", 4),
    MODERATOR("Moderator", 5),
    FINANCE_ADMIN("Finance Admin", 6),
    SUPPORT_ADMIN("Support Admin", 7),
    EDUCATION_ADMIN("Education Admin", 8),
    EXAM_ADMIN("Exam Admin", 9),
    SUPER_ADMIN("Super Admin", 10)
}

enum class Permission(val code: String, val description: String) {
    // Test permissions
    TEST_VIEW("test.view", "View test list & test series"),
    TEST_ATTEMPT("test.attempt", "Attempt live test & practice mocks"),
    TEST_CREATE("test.create", "Create new tests in test builder"),
    TEST_EDIT("test.edit", "Edit existing tests"),
    TEST_DELETE("test.delete", "Delete tests safely"),
    TEST_PUBLISH("test.publish", "Publish tests for students"),
    TEST_SCHEDULE("test.schedule", "Schedule test release timings"),
    TEST_ARCHIVE("test.archive", "Archive past tests"),
    TEST_MOVE("test.move", "Move test between folders"),
    TEST_COPY("test.copy", "Duplicate or copy test"),

    // Question bank permissions
    QUESTION_VIEW("question.view", "View questions & solutions"),
    QUESTION_CREATE("question.create", "Create questions manually or bulk"),
    QUESTION_EDIT("question.edit", "Edit question fields"),
    QUESTION_DELETE("question.delete", "Delete questions"),
    QUESTION_APPROVE("question.approve", "Review and approve draft/AI questions"),
    QUESTION_PUBLISH("question.publish", "Publish approved questions to bank"),

    // Student permissions
    STUDENT_VIEW("student.view", "View student records"),
    STUDENT_EDIT("student.edit", "Edit student details"),
    STUDENT_WARN("student.warn", "Send advisory/warning to student"),
    STUDENT_SUSPEND("student.suspend", "Temporarily suspend student account"),
    STUDENT_BLOCK("student.block", "Block student from platform"),

    // Teacher / Staff permissions
    TEACHER_VIEW("teacher.view", "View teacher list and profiles"),
    TEACHER_CREATE("teacher.create", "Add new faculty member"),
    TEACHER_EDIT("teacher.edit", "Edit teacher assignment"),
    TEACHER_DELETE("teacher.delete", "Remove teacher account"),

    // Course management permissions
    COURSE_VIEW("course.view", "View course structures"),
    COURSE_CREATE("course.create", "Create courses, subjects, chapters, topics"),
    COURSE_EDIT("course.edit", "Edit academic contents"),
    COURSE_DELETE("course.delete", "Delete course hierarchy"),

    // Batch permissions
    BATCH_VIEW("batch.view", "View coaching batches"),
    BATCH_CREATE("batch.create", "Create new coaching batches"),
    BATCH_EDIT("batch.edit", "Assign students and teachers to batch"),
    BATCH_DELETE("batch.delete", "Delete batches"),
    BATCH_MANAGE("batch.manage", "Manage batches, faculty & schedules"),

    // Attendance & Timetable
    ATTENDANCE_RECORD("coaching.attendance_record", "Record daily attendance"),
    TIMETABLE_MANAGE("coaching.timetable_manage", "Create/Edit timetable"),

    // Membership & Payments
    MEMBERSHIP_VIEW("membership.view", "View subscription plans"),
    MEMBERSHIP_EDIT("membership.edit", "Configure subscription pricing"),
    PAYMENT_VIEW("payment.view", "View revenue and transactions"),
    PAYMENT_EDIT("payment.edit", "Issue refunds and fee adjustments"),

    // Administrative access
    ADMIN_DASHBOARD("admin.dashboard", "Access centralized admin control center"),
    AUDIT_VIEW("audit.view", "View system audit trail")
}

object RolePermissions {
    val map: Map<UserRole, Set<Permission>> = mapOf(
        UserRole.STUDENT to setOf(
            Permission.TEST_VIEW,
            Permission.TEST_ATTEMPT,
            Permission.QUESTION_VIEW,
            Permission.MEMBERSHIP_VIEW
        ),
        UserRole.TEACHER to setOf(
            Permission.TEST_VIEW,
            Permission.TEST_ATTEMPT,
            Permission.QUESTION_VIEW,
            Permission.QUESTION_CREATE,
            Permission.QUESTION_EDIT,
            Permission.STUDENT_VIEW,
            Permission.BATCH_VIEW,
            Permission.ATTENDANCE_RECORD,
            Permission.TIMETABLE_MANAGE
        ),
        UserRole.TEST_CREATOR to setOf(
            Permission.TEST_VIEW,
            Permission.TEST_ATTEMPT,
            Permission.TEST_CREATE,
            Permission.TEST_EDIT,
            Permission.TEST_SCHEDULE,
            Permission.TEST_COPY,
            Permission.TEST_MOVE,
            Permission.QUESTION_VIEW,
            Permission.QUESTION_CREATE,
            Permission.QUESTION_EDIT,
            Permission.QUESTION_APPROVE
        ),
        UserRole.CONTENT_ADMIN to setOf(
            Permission.TEST_VIEW,
            Permission.QUESTION_VIEW,
            Permission.QUESTION_CREATE,
            Permission.QUESTION_EDIT,
            Permission.QUESTION_APPROVE,
            Permission.QUESTION_PUBLISH,
            Permission.COURSE_VIEW,
            Permission.COURSE_CREATE,
            Permission.COURSE_EDIT,
            Permission.COURSE_DELETE
        ),
        UserRole.MODERATOR to setOf(
            Permission.TEST_VIEW,
            Permission.QUESTION_VIEW,
            Permission.QUESTION_APPROVE,
            Permission.STUDENT_VIEW,
            Permission.STUDENT_WARN,
            Permission.AUDIT_VIEW
        ),
        UserRole.FINANCE_ADMIN to setOf(
            Permission.MEMBERSHIP_VIEW,
            Permission.MEMBERSHIP_EDIT,
            Permission.PAYMENT_VIEW,
            Permission.PAYMENT_EDIT,
            Permission.ADMIN_DASHBOARD,
            Permission.AUDIT_VIEW
        ),
        UserRole.SUPPORT_ADMIN to setOf(
            Permission.STUDENT_VIEW,
            Permission.STUDENT_EDIT,
            Permission.STUDENT_WARN,
            Permission.STUDENT_SUSPEND,
            Permission.BATCH_VIEW,
            Permission.ADMIN_DASHBOARD
        ),
        UserRole.EDUCATION_ADMIN to setOf(
            Permission.COURSE_VIEW,
            Permission.COURSE_CREATE,
            Permission.COURSE_EDIT,
            Permission.COURSE_DELETE,
            Permission.BATCH_VIEW,
            Permission.BATCH_CREATE,
            Permission.BATCH_EDIT,
            Permission.TEACHER_VIEW,
            Permission.TEACHER_CREATE,
            Permission.TEACHER_EDIT,
            Permission.STUDENT_VIEW,
            Permission.STUDENT_EDIT,
            Permission.ATTENDANCE_RECORD,
            Permission.TIMETABLE_MANAGE,
            Permission.ADMIN_DASHBOARD,
            Permission.AUDIT_VIEW
        ),
        UserRole.EXAM_ADMIN to setOf(
            Permission.TEST_VIEW,
            Permission.TEST_ATTEMPT,
            Permission.TEST_CREATE,
            Permission.TEST_EDIT,
            Permission.TEST_DELETE,
            Permission.TEST_PUBLISH,
            Permission.TEST_SCHEDULE,
            Permission.TEST_ARCHIVE,
            Permission.TEST_MOVE,
            Permission.TEST_COPY,
            Permission.QUESTION_VIEW,
            Permission.QUESTION_CREATE,
            Permission.QUESTION_EDIT,
            Permission.QUESTION_DELETE,
            Permission.QUESTION_APPROVE,
            Permission.QUESTION_PUBLISH,
            Permission.STUDENT_VIEW,
            Permission.STUDENT_EDIT,
            Permission.STUDENT_WARN,
            Permission.BATCH_VIEW,
            Permission.BATCH_MANAGE,
            Permission.ATTENDANCE_RECORD,
            Permission.TIMETABLE_MANAGE,
            Permission.ADMIN_DASHBOARD,
            Permission.AUDIT_VIEW
        ),
        UserRole.SUPER_ADMIN to Permission.values().toSet()
    )

    fun hasPermission(role: UserRole, permission: Permission): Boolean {
        return map[role]?.contains(permission) == true
    }
}

enum class ExamCategory(val id: String, val titleHindi: String, val titleEnglish: String, val iconName: String) {
    RAILWAY("railway", "रेलवे (RRB)", "Railway", "Train"),
    SSC("ssc", "एसएससी (SSC)", "SSC", "Badge"),
    BANKING("banking", "बैंकिंग (IBPS/SBI)", "Banking", "AccountBalance"),
    POLICE("police", "पुलिस (State Police)", "Police", "Shield"),
    DEFENCE("defence", "रक्षा (NDA/CDS/AFCAT)", "Defence", "MilitaryTech"),
    UPSC("upsc", "यूपीएससी (UPSC/Civil)", "UPSC", "Public"),
    TEACHING("teaching", "शिक्षक भर्ती (TET/CTET)", "Teaching", "School"),
    STATE_EXAMS("state", "राज्य स्तरीय परीक्षाएं", "State Exams", "LocationCity")
}

data class UserProfile(
    val id: String,
    val fullName: String,
    val mobile: String,
    val email: String,
    val role: UserRole = UserRole.STUDENT,
    val targetExam: ExamCategory = ExamCategory.RAILWAY,
    val targetSubExam: String = "RRB NTPC CBT-2",
    val state: String = "Uttar Pradesh",
    val preferredLanguage: String = "Hindi + English",
    val preparationLevel: String = "Intermediate",
    val avatar: String = "",
    val about: String = "Dedicated competitive exam aspirant targeting 2026 selection.",
    val isVerified: Boolean = true,
    val isBlocked: Boolean = false,
    val approvalStatus: String = "Approved",
    val isProSubscriber: Boolean = false,
    val enrolledBatches: List<String> = listOf("B-RRB-2026-ALPHA"),
    val accuracyPercentage: Int = 84,
    val totalTestsAttempted: Int = 38,
    val overallRank: Int = 142,
    val streakDays: Int = 18,
    val createdAt: String = "2026-01-10T10:00:00Z",
    val updatedAt: String = "2026-10-06T12:00:00Z"
)

// Coaching Profile Model
data class CoachingProfile(
    val id: String = "CP-01",
    val coachingName: String = "Crack Exam Academy",
    val tagline: String = "परीक्षा की तैयारी, एक ही जगह",
    val address: String = "Plot 42, Knowledge Park, Prayagraj, UP - 211002",
    val contactPhone: String = "+91 98765 00111",
    val contactEmail: String = "support@crackexam.in",
    val website: String = "https://crackexam.in",
    val brandingColorHex: String = "#1E293B",
    val description: String = "India's premier hybrid tech coaching institute for Railway, SSC, Banking, and State Defence examinations."
)

// Teacher / Staff Model
data class TeacherRecord(
    val id: String,
    val name: String,
    val mobile: String,
    val email: String,
    val assignedSubjects: List<String>,
    val assignedBatches: List<String>,
    val qualification: String,
    val status: String = "Active", // "Active", "Inactive"
    val createdAt: String = "2026-01-01"
)

// Academic Course Structure
data class ExamCourse(
    val id: String,
    val examCategory: ExamCategory,
    val title: String,
    val description: String,
    val status: String = "Active",
    val createdAt: String = "2026-01-01"
)

data class ExamSubject(
    val id: String,
    val courseId: String,
    val name: String,
    val description: String,
    val orderIndex: Int
)

data class ExamChapter(
    val id: String,
    val subjectId: String,
    val title: String,
    val orderIndex: Int
)

data class ExamTopic(
    val id: String,
    val chapterId: String,
    val title: String,
    val orderIndex: Int
)

// Timetable Entry
data class TimetableEntry(
    val id: String,
    val batchId: String,
    val batchName: String,
    val subject: String,
    val teacherName: String,
    val room: String,
    val dayOfWeek: String, // "Monday", "Tuesday", etc.
    val timeSlot: String // "08:00 AM - 10:00 AM"
)

// Test Folders
data class TestFolder(
    val id: String,
    val name: String,
    val category: String, // "Exam", "TestSeries", "Question", "Course"
    val itemCount: Int = 0,
    val createdAt: String = "2026-02-01"
)

// Test Lifecycle Status
enum class TestLifecycleStatus {
    DRAFT,
    REVIEW,
    APPROVED,
    PUBLISHED,
    SCHEDULED,
    ACTIVE,
    COMPLETED,
    ARCHIVED
}

data class TestSeries(
    val id: String,
    val examCategory: ExamCategory,
    val title: String,
    val subExam: String,
    val totalTests: Int,
    val completedTests: Int,
    val difficulty: String,
    val avgScore: Double,
    val avgAccuracy: Double,
    val isFree: Boolean = false,
    val tag: String = "Popular",
    val status: String = "Published",
    val createdAt: String = "2026-02-01"
)

enum class QuestionType {
    SINGLE_CORRECT,
    MULTIPLE_CORRECT,
    TRUE_FALSE,
    NUMERICAL
}

data class Question(
    val id: String,
    val questionHindi: String,
    val questionEnglish: String,
    val optionsHindi: List<String>,
    val optionsEnglish: List<String>,
    val correctOptionIndices: List<Int>,
    val numericalAnswer: Double? = null,
    val explanationHindi: String,
    val explanationEnglish: String,
    val subject: String,
    val chapter: String,
    val topic: String,
    val difficulty: String,
    val marks: Double = 2.0,
    val negativeMarks: Double = 0.66,
    val type: QuestionType = QuestionType.SINGLE_CORRECT,
    val isAiGenerated: Boolean = false,
    val reviewStatus: ReviewStatus = ReviewStatus.PUBLISHED,
    val createdAt: String = "2026-01-15"
)

enum class ReviewStatus {
    GENERATED,
    DRAFT,
    REVIEW,
    APPROVED,
    PUBLISHED
}

data class ExamTest(
    val id: String,
    val examCategory: ExamCategory,
    val testSeriesId: String,
    val folderId: String = "DEFAULT_FOLDER",
    val title: String,
    val description: String,
    val durationMinutes: Int,
    val totalQuestions: Int,
    val totalMarks: Double,
    val negativeMarkRatio: Double,
    val languages: List<String>,
    val sections: List<String>,
    val questions: List<Question>,
    val status: ReviewStatus = ReviewStatus.PUBLISHED,
    val lifecycleStatus: TestLifecycleStatus = TestLifecycleStatus.PUBLISHED,
    val isScheduled: Boolean = false,
    val startDate: String = "2026-10-01",
    val endDate: String = "2026-12-31",
    val createdBy: String = "Super Admin",
    val createdAt: String = "2026-01-20"
)

data class TestAnswer(
    val questionId: String,
    val selectedOptionIndices: List<Int>,
    val numericalValue: Double? = null,
    val isMarkedForReview: Boolean = false,
    val timeSpentSeconds: Int = 0
)

data class TestResult(
    val id: String,
    val testId: String,
    val testTitle: String,
    val examCategory: ExamCategory,
    val totalMarks: Double,
    val scoredMarks: Double,
    val totalQuestions: Int,
    val correctCount: Int,
    val wrongCount: Int,
    val skippedCount: Int,
    val accuracyPercentage: Double,
    val timeTakenSeconds: Int,
    val rank: Int,
    val totalParticipants: Int,
    val percentile: Double,
    val dateAttempted: String
)

data class StudyNote(
    val id: String,
    val examCategory: ExamCategory,
    val subject: String,
    val chapter: String,
    val topic: String,
    val title: String,
    val summary: String,
    val content: String,
    val readMinutes: Int,
    val isBookmarked: Boolean = false,
    val isProOnly: Boolean = false,
    val createdAt: String = "2026-02-10"
)

data class BookItem(
    val id: String,
    val title: String,
    val author: String,
    val category: String,
    val examCategory: ExamCategory,
    val pages: Int,
    val chaptersCount: Int,
    val rating: Double,
    val isFree: Boolean,
    val status: String = "Available"
)

data class LeaderboardEntry(
    val rank: Int,
    val studentName: String,
    val targetExam: String,
    val score: Double,
    val accuracy: Double,
    val testsAttempted: Int,
    val state: String,
    val isCurrentUser: Boolean = false
)

data class CoachingBatch(
    val id: String,
    val name: String,
    val examTarget: ExamCategory,
    val facultyName: String,
    val subject: String,
    val timing: String,
    val totalStudents: Int,
    val room: String,
    val status: String = "Active",
    val createdAt: String = "2026-01-05"
)

data class StudentRecord(
    val studentId: String,
    val name: String,
    val phone: String,
    val email: String,
    val batchId: String,
    val batchName: String,
    val attendancePercent: Int,
    val performanceRank: Int,
    val parentName: String = "Shri R. K. Sharma",
    val parentPhone: String = "+91 94150 00000",
    val admissionDate: String,
    val status: String = "Active" // "Active", "Suspended", "Blocked"
)

data class AttendanceRecord(
    val id: String,
    val date: String,
    val batchId: String,
    val batchName: String,
    val totalPresent: Int,
    val totalAbsent: Int,
    val totalLeave: Int
)

data class NoticeItem(
    val id: String,
    val title: String,
    val description: String,
    val category: String, // "Test", "Result", "Class", "Notice", "Subscription", "Important Announcement"
    val targetAudience: String = "All Students", // "All Students", "Teachers", "Specific Batch"
    val timestamp: String,
    val isImportant: Boolean = false
)

data class AuditLogItem(
    val id: String,
    val actor: String,
    val role: String,
    val action: String,
    val resource: String,
    val resourceId: String = "",
    val timestamp: String,
    val status: String = "Success"
)

data class MembershipPlan(
    val id: String,
    val name: String,
    val priceInr: Int,
    val originalPriceInr: Int,
    val validityMonths: Int,
    val isPopular: Boolean,
    val features: List<String>,
    val status: String = "Active"
)

sealed class UiState<out T> {
    object Idle : UiState<Nothing>()
    object Loading : UiState<Nothing>()
    data class Success<out T>(val data: T) : UiState<T>()
    data class Error(val message: String) : UiState<Nothing>()
}

package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.CrackExamBottomBar
import com.example.ui.components.CrackExamHeader
import com.example.ui.screens.*
import com.example.ui.theme.CrackExamTheme
import com.example.viewmodel.CrackExamViewModel
import com.example.viewmodel.ScreenDestination

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CrackExamTheme {
                CrackExamApp()
            }
        }
    }
}

@Composable
fun CrackExamApp(
    viewModel: CrackExamViewModel = viewModel()
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val isAuthenticated by viewModel.isAuthenticated.collectAsState()

    // Determine bottom nav active tab across the 5 canonical destinations: Home, Tests, Practice, AI Study, Profile
    val currentTab = when (currentScreen) {
        is ScreenDestination.Home -> "Home"
        is ScreenDestination.Tests, is ScreenDestination.TestSeriesList -> "Tests"
        is ScreenDestination.Practice, is ScreenDestination.QuestionBank, is ScreenDestination.Notes, is ScreenDestination.Books -> "Practice"
        is ScreenDestination.AiStudy -> "AI Study"
        is ScreenDestination.Profile, is ScreenDestination.ProfileSettings -> "Profile"
        else -> "Home"
    }

    // Determine whether Top Bar and Bottom Bar should be shown
    val isAuthScreen = currentScreen is ScreenDestination.Login ||
            currentScreen is ScreenDestination.Register ||
            currentScreen is ScreenDestination.ForgotPassword ||
            currentScreen is ScreenDestination.ResetPassword ||
            currentScreen is ScreenDestination.EmailVerification ||
            currentScreen is ScreenDestination.ExamSelection

    val isExamRunning = currentScreen is ScreenDestination.LiveTestScreen

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            if (!isAuthScreen && !isExamRunning) {
                CrackExamHeader(
                    title = "CRACK EXAM",
                    subtitle = "परीक्षा की तैयारी, एक ही जगह",
                    currentRole = currentUser.role,
                    onRoleClick = { viewModel.navigateTo(ScreenDestination.Profile) },
                    onNotificationClick = { viewModel.navigateTo(ScreenDestination.Profile) },
                    onProfileClick = { viewModel.navigateTo(ScreenDestination.Profile) }
                )
            }
        },
        bottomBar = {
            if (!isAuthScreen && !isExamRunning) {
                CrackExamBottomBar(
                    currentTab = currentTab,
                    onTabSelected = { tab ->
                        when (tab) {
                            "Home" -> viewModel.navigateTo(ScreenDestination.Home)
                            "Tests" -> viewModel.navigateTo(ScreenDestination.TestSeriesList)
                            "Practice" -> viewModel.navigateTo(ScreenDestination.QuestionBank)
                            "AI Study" -> viewModel.navigateTo(ScreenDestination.AiStudy)
                            "Profile" -> viewModel.navigateTo(ScreenDestination.ProfileSettings)
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            when (val screen = currentScreen) {
                // Auth & Onboarding Flow
                is ScreenDestination.Login -> LoginScreen(viewModel)
                is ScreenDestination.Register -> RegisterScreen(viewModel)
                is ScreenDestination.ForgotPassword -> ForgotPasswordScreen(viewModel)
                is ScreenDestination.ResetPassword -> ResetPasswordScreen(screen.emailToken, viewModel)
                is ScreenDestination.EmailVerification -> EmailVerificationScreen(screen.email, viewModel)
                is ScreenDestination.ExamSelection -> ExamSelectionScreen(viewModel)

                // Base App Destinations
                is ScreenDestination.Home -> StudentHomeScreen(viewModel)
                is ScreenDestination.Tests, is ScreenDestination.TestSeriesList -> TestSeriesListScreen(viewModel)
                is ScreenDestination.Practice, is ScreenDestination.QuestionBank -> QuestionBankScreen(viewModel)
                is ScreenDestination.AiStudy -> AiStudyScreen(viewModel)
                is ScreenDestination.Profile, is ScreenDestination.ProfileSettings -> ProfileSettingsScreen(viewModel)

                // Sub-modules & Functional Screens
                is ScreenDestination.LiveTestScreen -> LiveTestScreen(test = screen.test, viewModel = viewModel)
                is ScreenDestination.TestResultScreen -> TestResultScreen(result = screen.result, viewModel = viewModel)
                is ScreenDestination.Notes -> NotesScreen(viewModel)
                is ScreenDestination.Books -> BooksScreen(viewModel)
                is ScreenDestination.Performance -> PerformanceScreen(viewModel)
                is ScreenDestination.Leaderboard -> LeaderboardScreen(viewModel)
                is ScreenDestination.Subscription -> SubscriptionScreen(viewModel)

                // Protected Admin & Workbenches
                is ScreenDestination.CoachingDashboard -> CoachingDashboardScreen(viewModel)
                is ScreenDestination.AdminDashboard -> AdminDashboardScreen(viewModel)
                is ScreenDestination.TestBuilder -> TestBuilderScreen(viewModel)

                // Access Denied Screen for security protection
                is ScreenDestination.AccessDenied -> AccessDeniedScreen(
                    requiredPermission = screen.requiredPermission,
                    attemptedScreen = screen.attemptedScreen,
                    viewModel = viewModel
                )
            }
        }
    }
}

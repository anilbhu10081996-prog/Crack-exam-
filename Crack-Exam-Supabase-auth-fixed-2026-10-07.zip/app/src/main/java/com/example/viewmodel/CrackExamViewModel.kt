package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CrackExamRepository
import com.example.data.SupabaseAuthService
import com.example.data.ai.*
import com.example.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed class ScreenDestination {
    // Auth & Onboarding Flow
    object Login : ScreenDestination()
    object Register : ScreenDestination()
    object ForgotPassword : ScreenDestination()
    data class ResetPassword(val emailToken: String = "") : ScreenDestination()
    data class EmailVerification(val email: String) : ScreenDestination()
    object ExamSelection : ScreenDestination()

    // Main Tabs & App Flow
    object Home : ScreenDestination()
    object Tests : ScreenDestination() // TestSeriesList
    object Practice : ScreenDestination() // QuestionBank
    object AiStudy : ScreenDestination()
    object Profile : ScreenDestination() // ProfileSettings

    // Sub-screens & Features
    object TestSeriesList : ScreenDestination()
    data class LiveTestScreen(val test: ExamTest) : ScreenDestination()
    data class TestResultScreen(val result: TestResult) : ScreenDestination()
    object QuestionBank : ScreenDestination()
    object Notes : ScreenDestination()
    object Books : ScreenDestination()
    object Performance : ScreenDestination()
    object Leaderboard : ScreenDestination()
    object Subscription : ScreenDestination()

    // Protected Admin / Staff Workbenches
    object CoachingDashboard : ScreenDestination()
    object AdminDashboard : ScreenDestination()
    object TestBuilder : ScreenDestination()
    object ProfileSettings : ScreenDestination()

    // Access Denied Fallback
    data class AccessDenied(val requiredPermission: String, val attemptedScreen: String) : ScreenDestination()
}

class CrackExamViewModel(
    application: Application
) : AndroidViewModel(application) {

    val repository: CrackExamRepository = CrackExamRepository()
    private val supabaseAuth = SupabaseAuthService(application)

    // Session State: true if student is authenticated
    private val _isAuthenticated = MutableStateFlow(false)
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()

    // Current navigation destination
    private val _currentScreen = MutableStateFlow<ScreenDestination>(ScreenDestination.Login)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    // Auth States for Login, Register, Forgot Password
    private val _authActionState = MutableStateFlow<UiState<String>>(UiState.Idle)
    val authActionState: StateFlow<UiState<String>> = _authActionState.asStateFlow()

    init {
        if (supabaseAuth.hasSession()) {
            _isAuthenticated.value = true
            _currentScreen.value = ScreenDestination.Home
        }
    }

    // Repository states
    val currentUser = repository.currentUser
    val selectedExam = repository.selectedExam
    val testSeries = repository.testSeries
    val tests = repository.tests
    val questionBank = repository.questionBank
    val notes = repository.notes
    val books = repository.books
    val results = repository.results
    val leaderboards = repository.leaderboards
    val coachingBatches = repository.coachingBatches
    val coachingStudents = repository.coachingStudents
    val attendanceHistory = repository.attendanceHistory
    val notices = repository.notices
    val auditLogs = repository.auditLogs
    val membershipPlans = repository.membershipPlans
    val coachingProfile = repository.coachingProfile
    val teachers = repository.teachers
    val timetable = repository.timetable
    val testFolders = repository.testFolders

    // AI Study Service & Streams
    val aiStudyService: AiStudyService = AiStudyServiceImpl()

    val aiQuestionAnswers = repository.aiQuestionAnswers
    val aiDoubts = repository.aiDoubts
    val aiNotesDrafts = repository.aiNotesDrafts
    val aiQuizSessions = repository.aiQuizSessions
    val aiGeneratedTests = repository.aiGeneratedTests
    val aiRevisionPackages = repository.aiRevisionPackages
    val aiStudyPlans = repository.aiStudyPlans
    val aiHistory = repository.aiHistory
    val aiReviewSubmissions = repository.aiReviewSubmissions

    // Active AI Interaction States
    private val _currentQaResult = MutableStateFlow<AiQuestionAnswer?>(null)
    val currentQaResult: StateFlow<AiQuestionAnswer?> = _currentQaResult.asStateFlow()

    private val _currentDoubtResult = MutableStateFlow<AiDoubtItem?>(null)
    val currentDoubtResult: StateFlow<AiDoubtItem?> = _currentDoubtResult.asStateFlow()

    private val _currentNoteDraft = MutableStateFlow<AiNoteDraft?>(null)
    val currentNoteDraft: StateFlow<AiNoteDraft?> = _currentNoteDraft.asStateFlow()

    private val _currentQuizSession = MutableStateFlow<AiQuizSession?>(null)
    val currentQuizSession: StateFlow<AiQuizSession?> = _currentQuizSession.asStateFlow()

    private val _currentGeneratedTest = MutableStateFlow<AiGeneratedTest?>(null)
    val currentGeneratedTest: StateFlow<AiGeneratedTest?> = _currentGeneratedTest.asStateFlow()

    private val _currentRevisionPackage = MutableStateFlow<AiRevisionPackage?>(null)
    val currentRevisionPackage: StateFlow<AiRevisionPackage?> = _currentRevisionPackage.asStateFlow()

    private val _currentStudyPlan = MutableStateFlow<AiStudyPlan?>(null)
    val currentStudyPlan: StateFlow<AiStudyPlan?> = _currentStudyPlan.asStateFlow()

    private val _aiErrorMessage = MutableStateFlow<String?>(null)
    val aiErrorMessage: StateFlow<String?> = _aiErrorMessage.asStateFlow()

    // Search query & filters
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _preferredLanguage = MutableStateFlow("Hindi + English")
    val preferredLanguage: StateFlow<String> = _preferredLanguage.asStateFlow()

    // Test Taking State
    private val _activeTestAnswers = MutableStateFlow<Map<String, List<Int>>>(emptyMap())
    val activeTestAnswers: StateFlow<Map<String, List<Int>>> = _activeTestAnswers.asStateFlow()

    private val _markedForReview = MutableStateFlow<Set<String>>(emptySet())
    val markedForReview: StateFlow<Set<String>> = _markedForReview.asStateFlow()

    private val _currentQuestionIndex = MutableStateFlow(0)
    val currentQuestionIndex: StateFlow<Int> = _currentQuestionIndex.asStateFlow()

    // AI Study Query & Output
    private val _aiStudyPrompt = MutableStateFlow("")
    val aiStudyPrompt: StateFlow<String> = _aiStudyPrompt.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    data class AiGeneratedStudyMaterial(
        val topic: String,
        val explanation: String,
        val shortNotes: List<String>,
        val importantFacts: List<String>,
        val practiceQuiz: List<Question>
    )

    private val _aiGeneratedMaterial = MutableStateFlow<AiGeneratedStudyMaterial?>(null)
    val aiGeneratedMaterial: StateFlow<AiGeneratedStudyMaterial?> = _aiGeneratedMaterial.asStateFlow()

    /**
     * Centralized Navigation with Backend/Role Authorization Protection
     */
    fun navigateTo(destination: ScreenDestination) {
        val user = currentUser.value

        // Check authentication requirement for non-auth destinations
        val isAuthScreen = destination is ScreenDestination.Login ||
                destination is ScreenDestination.Register ||
                destination is ScreenDestination.ForgotPassword ||
                destination is ScreenDestination.ResetPassword ||
                destination is ScreenDestination.EmailVerification

        if (!_isAuthenticated.value && !isAuthScreen) {
            _currentScreen.value = ScreenDestination.Login
            return
        }

        // Protected Route Authorization Checks
        when (destination) {
            is ScreenDestination.AdminDashboard -> {
                if (!RolePermissions.hasPermission(user.role, Permission.ADMIN_DASHBOARD)) {
                    _currentScreen.value = ScreenDestination.AccessDenied("admin.dashboard", "Admin Control Center")
                    return
                }
            }
            is ScreenDestination.TestBuilder -> {
                if (!RolePermissions.hasPermission(user.role, Permission.TEST_CREATE)) {
                    _currentScreen.value = ScreenDestination.AccessDenied("test.create", "Test Builder")
                    return
                }
            }
            is ScreenDestination.CoachingDashboard -> {
                if (!RolePermissions.hasPermission(user.role, Permission.BATCH_MANAGE) && user.role.level < UserRole.TEACHER.level) {
                    // Students can view schedule/notices, but administrative operations require role level
                    // If user is basic student, allow read-only or gate as needed
                }
            }
            else -> {}
        }

        _currentScreen.value = destination
    }

    // Authentication Actions
    fun login(identifier: String, pass: String) {
        if (identifier.isBlank() || pass.isBlank()) { _authActionState.value=UiState.Error("कृपया ईमेल और पासवर्ड दर्ज करें"); return }
        _authActionState.value=UiState.Loading
        viewModelScope.launch {
            val r=withContext(kotlinx.coroutines.Dispatchers.IO){supabaseAuth.signIn(identifier,pass)}
            r.fold({ _isAuthenticated.value=true; _authActionState.value=UiState.Success("लॉगिन सफल"); repository.addAuditLog("LOGIN_SUCCESS",identifier); _currentScreen.value=ScreenDestination.Home },{ _authActionState.value=UiState.Error(it.message ?: "लॉगिन असफल") })
        }
    }

    fun register(fullName:String,mobile:String,email:String,pass:String,examPref:ExamCategory,state:String,language:String) {
        if(fullName.isBlank()||mobile.isBlank()||email.isBlank()||pass.isBlank()){_authActionState.value=UiState.Error("कृपया सभी अनिवार्य फ़ील्ड भरें");return}
        if(!android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()){_authActionState.value=UiState.Error("कृपया मान्य ईमेल दर्ज करें");return}
        if(!mobile.matches(Regex("^[0-9]{10}$"))){_authActionState.value=UiState.Error("कृपया 10 अंकों का मान्य मोबाइल नंबर दर्ज करें");return}
        _authActionState.value=UiState.Loading
        viewModelScope.launch{
            val r=withContext(kotlinx.coroutines.Dispatchers.IO){supabaseAuth.signUp(fullName,mobile,email,pass)}
            r.fold({
                val profile=UserProfile(id=supabaseAuth.userId()?:"",fullName=fullName,mobile=mobile,email=email,role=UserRole.STUDENT,targetExam=examPref,targetSubExam="${examPref.titleEnglish} 2026",state=state.ifBlank{"Uttar Pradesh"},preferredLanguage=language.ifBlank{"Hindi + English"},preparationLevel="Beginner",isVerified=false,approvalStatus="Approved")
                repository.updateUserProfile(profile);_authActionState.value=UiState.Success("पंजीकरण सफल। ईमेल सत्यापन पूरा करें।");repository.addAuditLog("REGISTER_SUCCESS",email);_currentScreen.value=ScreenDestination.EmailVerification(email)
            },{_authActionState.value=UiState.Error(it.message ?: "पंजीकरण असफल")})
        }
    }

    fun verifyEmail(email: String) {
        _authActionState.value = UiState.Loading
        viewModelScope.launch {
            kotlinx.coroutines.delay(600)
            repository.verifyUserEmail()
            _authActionState.value = UiState.Success("ईमेल सफलतापूर्वक सत्यापित हुआ")
            _currentScreen.value = ScreenDestination.ExamSelection
        }
    }

    fun completeExamCustomization(
        category: ExamCategory,
        subExam: String,
        prepLevel: String,
        language: String
    ) {
        val updated = currentUser.value.copy(
            targetExam = category,
            targetSubExam = subExam,
            preparationLevel = prepLevel,
            preferredLanguage = language
        )
        repository.updateUserProfile(updated)
        repository.setSelectedExam(category)
        _isAuthenticated.value = true
        _currentScreen.value = ScreenDestination.Home
    }

    fun sendForgotPasswordLink(email: String) {
        if (email.isBlank()) {
            _authActionState.value = UiState.Error("कृपया अपना पंजीकृत ईमेल दर्ज करें")
            return
        }
        _authActionState.value = UiState.Loading
        viewModelScope.launch {
            kotlinx.coroutines.delay(800)
            _authActionState.value = UiState.Success("पासवर्ड रीसेट लिंक आपके ईमेल पर भेजा गया है")
            _currentScreen.value = ScreenDestination.ResetPassword(email)
        }
    }

    fun resetPassword(newPass: String, confirmPass: String) {
        if (newPass.length < 6) {
            _authActionState.value = UiState.Error("पासवर्ड कम से कम 6 अक्षरों का होना चाहिए")
            return
        }
        if (newPass != confirmPass) {
            _authActionState.value = UiState.Error("दोनों पासवर्ड मेल नहीं खाते")
            return
        }
        _authActionState.value = UiState.Loading
        viewModelScope.launch {
            kotlinx.coroutines.delay(800)
            _authActionState.value = UiState.Success("पासवर्ड सफलतापूर्वक बदल दिया गया है")
            _currentScreen.value = ScreenDestination.Login
        }
    }

    fun logout() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) { supabaseAuth.signOut() }
        _isAuthenticated.value = false
        repository.addAuditLog("LOGOUT", currentUser.value.email)
        _currentScreen.value = ScreenDestination.Login
    }

    fun clearAuthMessage() {
        _authActionState.value = UiState.Idle
    }

    fun selectExam(exam: ExamCategory) {
        repository.setSelectedExam(exam)
    }

    fun switchRole(role: UserRole) {
        repository.switchRole(role)
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setLanguage(lang: String) {
        _preferredLanguage.value = lang
    }

    // Live Test Interactions
    fun startLiveTest(test: ExamTest) {
        _activeTestAnswers.value = emptyMap()
        _markedForReview.value = emptySet()
        _currentQuestionIndex.value = 0
        _currentScreen.value = ScreenDestination.LiveTestScreen(test)
    }

    fun selectAnswer(questionId: String, optionIndex: Int, isMultiple: Boolean = false) {
        val current = _activeTestAnswers.value.toMutableMap()
        if (isMultiple) {
            val list = current[questionId]?.toMutableList() ?: mutableListOf()
            if (list.contains(optionIndex)) list.remove(optionIndex) else list.add(optionIndex)
            current[questionId] = list
        } else {
            current[questionId] = listOf(optionIndex)
        }
        _activeTestAnswers.value = current
    }

    fun clearAnswer(questionId: String) {
        val current = _activeTestAnswers.value.toMutableMap()
        current.remove(questionId)
        _activeTestAnswers.value = current
    }

    fun toggleMarkForReview(questionId: String) {
        val set = _markedForReview.value.toMutableSet()
        if (set.contains(questionId)) set.remove(questionId) else set.add(questionId)
        _markedForReview.value = set
    }

    fun setQuestionIndex(index: Int) {
        _currentQuestionIndex.value = index
    }

    fun submitCurrentTest(test: ExamTest, timeSpentSeconds: Int) {
        val result = repository.submitTestAttempt(test, _activeTestAnswers.value, timeSpentSeconds)
        _currentScreen.value = ScreenDestination.TestResultScreen(result)
    }

    fun clearAiError() {
        _aiErrorMessage.value = null
    }

    // 1. AI Question Answer
    fun askAiQuestion(query: String, language: String = "Hindi + English") {
        if (query.isBlank()) {
            _aiErrorMessage.value = "कृपया अपना प्रश्न लिखें (Please enter a question)"
            return
        }
        _aiStudyPrompt.value = query
        _isAiLoading.value = true
        _aiErrorMessage.value = null

        viewModelScope.launch {
            val result = aiStudyService.generateQuestionAnswer(currentUser.value.id, query, language)
            result.onSuccess { qa ->
                _currentQaResult.value = qa
                repository.saveAiQuestionAnswer(qa)
                _isAiLoading.value = false
            }.onFailure { err ->
                _aiErrorMessage.value = err.message ?: "AI प्रतिक्रिया प्राप्त करने में त्रुटि"
                _isAiLoading.value = false
            }
        }
    }

    // 2. AI Doubt Solver
    fun solveAiDoubt(question: String, subject: String, topic: String, imageUri: String? = null) {
        if (question.isBlank() && imageUri.isNullOrBlank()) {
            _aiErrorMessage.value = "कृपया अपना डाउट दर्ज करें (Please enter doubt details)"
            return
        }
        _isAiLoading.value = true
        _aiErrorMessage.value = null

        viewModelScope.launch {
            val result = aiStudyService.solveDoubt(currentUser.value.id, question, subject, topic, imageUri)
            result.onSuccess { doubt ->
                _currentDoubtResult.value = doubt
                repository.saveAiDoubt(doubt)
                _isAiLoading.value = false
            }.onFailure { err ->
                _aiErrorMessage.value = err.message ?: "डाउट हल करने में त्रुटि"
                _isAiLoading.value = false
            }
        }
    }

    // 3. AI Notes Generator
    fun generateAiNotes(topic: String, subject: String, examCategory: ExamCategory) {
        if (topic.isBlank()) {
            _aiErrorMessage.value = "कृपया नोट्स हेतु टॉपिक लिखें"
            return
        }
        _isAiLoading.value = true
        _aiErrorMessage.value = null

        viewModelScope.launch {
            val result = aiStudyService.generateNotesDraft(currentUser.value.id, topic, subject, examCategory)
            result.onSuccess { noteDraft ->
                _currentNoteDraft.value = noteDraft
                repository.saveAiNoteDraft(noteDraft)
                _isAiLoading.value = false
            }.onFailure { err ->
                _aiErrorMessage.value = err.message ?: "नोट्स जनरेट करने में त्रुटि"
                _isAiLoading.value = false
            }
        }
    }

    fun submitNoteForPublicReview(noteId: String) {
        repository.submitAiNoteForReview(noteId)
        if (_currentNoteDraft.value?.id == noteId) {
            _currentNoteDraft.value = _currentNoteDraft.value?.copy(status = ReviewStatus.REVIEW)
        }
    }

    // 4. AI Quiz
    fun startAiQuiz(config: AiQuizConfig) {
        _isAiLoading.value = true
        _aiErrorMessage.value = null

        viewModelScope.launch {
            val result = aiStudyService.generateQuiz(currentUser.value.id, config)
            result.onSuccess { qList ->
                val session = AiQuizSession(
                    id = "QZ-SESS-${System.currentTimeMillis()}",
                    studentId = currentUser.value.id,
                    config = config,
                    questions = qList
                )
                _currentQuizSession.value = session
                _isAiLoading.value = false
            }.onFailure { err ->
                _aiErrorMessage.value = err.message ?: "क्विज़ तैयार करने में त्रुटि"
                _isAiLoading.value = false
            }
        }
    }

    fun answerQuizQuestion(questionIndex: Int, optionIndex: Int) {
        val session = _currentQuizSession.value ?: return
        val currentAnswers = session.userAnswers.toMutableMap()
        currentAnswers[questionIndex] = optionIndex
        _currentQuizSession.value = session.copy(userAnswers = currentAnswers)
    }

    fun submitQuizSession(timeTakenSeconds: Int = 120) {
        val session = _currentQuizSession.value ?: return
        var correct = 0
        var wrong = 0
        session.questions.forEachIndexed { idx, q ->
            val ans = session.userAnswers[idx]
            if (ans != null) {
                if (ans == q.correctOptionIndex) correct++ else wrong++
            }
        }
        val accuracy = if (correct + wrong > 0) (correct.toDouble() / (correct + wrong)) * 100 else 0.0
        val score = correct * 2.0 - (wrong * 0.5)

        val completed = session.copy(
            isSubmitted = true,
            score = maxOf(0.0, score),
            correctCount = correct,
            wrongCount = wrong,
            accuracyPercentage = accuracy,
            timeTakenSeconds = timeTakenSeconds,
            completedAt = "Just now"
        )
        _currentQuizSession.value = completed
        repository.saveAiQuizSession(completed)
    }

    // 5. AI Test Generator
    fun generateAiTest(
        examCategory: ExamCategory,
        subject: String,
        chapter: String,
        topic: String,
        difficulty: String,
        count: Int,
        language: String
    ) {
        _isAiLoading.value = true
        _aiErrorMessage.value = null

        viewModelScope.launch {
            val result = aiStudyService.generateTest(
                studentId = currentUser.value.id,
                examCategory = examCategory,
                subject = subject,
                chapter = chapter,
                topic = topic,
                difficulty = difficulty,
                count = count,
                language = language
            )
            result.onSuccess { test ->
                _currentGeneratedTest.value = test
                repository.saveAiGeneratedTest(test)
                _isAiLoading.value = false
            }.onFailure { err ->
                _aiErrorMessage.value = err.message ?: "टेस्ट जनरेट करने में त्रुटि"
                _isAiLoading.value = false
            }
        }
    }

    fun submitAiTestForPublicReview(testId: String) {
        repository.submitAiTestForReview(testId)
        if (_currentGeneratedTest.value?.id == testId) {
            _currentGeneratedTest.value = _currentGeneratedTest.value?.copy(status = ReviewStatus.REVIEW)
        }
    }

    // 6. Revision Assistant
    fun generateAiRevision(topic: String, subject: String) {
        if (topic.isBlank()) {
            _aiErrorMessage.value = "कृपया रिवीजन के लिए विषय चुनें"
            return
        }
        _isAiLoading.value = true
        _aiErrorMessage.value = null

        viewModelScope.launch {
            val result = aiStudyService.generateRevisionPackage(currentUser.value.id, topic, subject)
            result.onSuccess { pkg ->
                _currentRevisionPackage.value = pkg
                repository.saveAiRevisionPackage(pkg)
                _isAiLoading.value = false
            }.onFailure { err ->
                _aiErrorMessage.value = err.message ?: "रिवीजन संकलित करने में त्रुटि"
                _isAiLoading.value = false
            }
        }
    }

    // 7. Study Planner
    fun generateAiStudyPlan(
        exam: ExamCategory,
        targetDate: String,
        dailyHours: Int,
        subjects: List<String>,
        level: String
    ) {
        _isAiLoading.value = true
        _aiErrorMessage.value = null

        viewModelScope.launch {
            val result = aiStudyService.generateStudyPlan(currentUser.value.id, exam, targetDate, dailyHours, subjects, level)
            result.onSuccess { plan ->
                _currentStudyPlan.value = plan
                repository.saveAiStudyPlan(plan)
                _isAiLoading.value = false
            }.onFailure { err ->
                _aiErrorMessage.value = err.message ?: "स्टडी प्लान तैयार करने में त्रुटि"
                _isAiLoading.value = false
            }
        }
    }

    fun toggleStudyPlanDay(planId: String, dayNumber: Int) {
        repository.toggleStudyPlanDay(planId, dayNumber)
        val cur = _currentStudyPlan.value
        if (cur?.id == planId) {
            val updated = cur.scheduleDays.map { if (it.dayNumber == dayNumber) it.copy(isCompleted = !it.isCompleted) else it }
            _currentStudyPlan.value = cur.copy(scheduleDays = updated)
        }
    }

    fun deleteHistoryItem(id: String) {
        repository.deleteAiHistoryItem(id)
    }

    fun toggleBookmarkHistory(id: String) {
        repository.toggleBookmarkHistory(id)
    }

    fun approveAndPublishAiSubmission(submissionId: String) {
        repository.approveAndPublishAiSubmission(submissionId)
    }

    fun rejectAiSubmission(submissionId: String, feedback: String) {
        repository.rejectAiSubmission(submissionId, feedback)
    }

    // Backward-compatible query wrapper
    fun generateAiStudyContent(query: String) {
        askAiQuestion(query)
    }

    // Admin & Coaching Actions
    fun approveAiQuestionToQuestionBank(question: Question) {
        val approved = question.copy(reviewStatus = ReviewStatus.PUBLISHED)
        repository.addQuestion(approved)
        repository.addAuditLog("APPROVED_AI_QUESTION", question.questionHindi.take(30))
    }

    fun createNewTest(test: ExamTest) {
        repository.addTest(test)
    }

    fun deleteTest(testId: String) {
        repository.deleteTest(testId)
    }

    fun addCoachingBatch(batch: CoachingBatch) {
        repository.addBatch(batch)
    }

    fun addCoachingStudent(student: StudentRecord) {
        repository.addStudent(student)
    }

    fun addTeacher(teacher: TeacherRecord) {
        repository.addTeacher(teacher)
    }

    fun updateCoachingProfile(profile: CoachingProfile) {
        repository.updateCoachingProfile(profile)
    }

    fun addTimetableEntry(entry: TimetableEntry) {
        repository.addTimetableEntry(entry)
    }

    fun addTestFolder(folder: TestFolder) {
        repository.addFolder(folder)
    }

    fun deleteTestFolder(folderId: String) {
        repository.deleteFolder(folderId)
    }

    fun duplicateTest(testId: String) {
        repository.duplicateTest(testId)
    }

    fun updateTestLifecycle(testId: String, newStatus: TestLifecycleStatus) {
        repository.updateTestLifecycle(testId, newStatus)
    }

    fun addQuestionToBank(question: Question) {
        repository.addQuestion(question)
    }

    fun recordDailyAttendance(batchId: String, present: Int, absent: Int, leave: Int) {
        repository.recordAttendance(batchId, present, absent, leave)
    }
}

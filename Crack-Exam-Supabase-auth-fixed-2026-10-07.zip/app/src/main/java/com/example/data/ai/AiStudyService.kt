package com.example.data.ai

import com.example.model.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

interface AiStudyService {
    suspend fun generateQuestionAnswer(
        studentId: String,
        query: String,
        language: String
    ): Result<AiQuestionAnswer>

    suspend fun solveDoubt(
        studentId: String,
        question: String,
        subject: String,
        topic: String,
        imageUri: String?
    ): Result<AiDoubtItem>

    suspend fun generateNotesDraft(
        studentId: String,
        topic: String,
        subject: String,
        examCategory: ExamCategory
    ): Result<AiNoteDraft>

    suspend fun generateQuiz(
        studentId: String,
        config: AiQuizConfig
    ): Result<List<AiQuizQuestion>>

    suspend fun generateTest(
        studentId: String,
        examCategory: ExamCategory,
        subject: String,
        chapter: String,
        topic: String,
        difficulty: String,
        count: Int,
        language: String
    ): Result<AiGeneratedTest>

    suspend fun generateRevisionPackage(
        studentId: String,
        topic: String,
        subject: String
    ): Result<AiRevisionPackage>

    suspend fun generateStudyPlan(
        studentId: String,
        exam: ExamCategory,
        targetDate: String,
        dailyHours: Int,
        subjects: List<String>,
        level: String
    ): Result<AiStudyPlan>
}

class AiStudyServiceImpl : AiStudyService {

    private fun currentDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        return sdf.format(Date())
    }

    override suspend fun generateQuestionAnswer(
        studentId: String,
        query: String,
        language: String
    ): Result<AiQuestionAnswer> {
        if (query.isBlank()) {
            return Result.failure(IllegalArgumentException("कृपया अपना प्रश्न दर्ज करें (Please enter a question)"))
        }

        delay(900) // Simulated network processing

        val isPolity = query.contains("संविधान", ignoreCase = true) || query.contains("constitution", ignoreCase = true) || query.contains("अनुच्छेद", ignoreCase = true)
        val isRailway = query.contains("railway", ignoreCase = true) || query.contains("ट्रेन", ignoreCase = true) || query.contains("दूरी", ignoreCase = true) || query.contains("गति", ignoreCase = true)
        val isHistory = query.contains("मुगल", ignoreCase = true) || query.contains("गांधी", ignoreCase = true) || query.contains("आंदोलन", ignoreCase = true) || query.contains("history", ignoreCase = true)

        val explanation = when {
            isPolity -> "भारतीय संविधान भारत का सर्वोच्च विधान है जो 26 जनवरी 1950 को लागू हुआ था। यह विश्व का सबसे बड़ा लिखित संविधान है जिसमें कार्यपालिका, विधायिका और न्यायपालिका के अधिकारों व दायित्वों का विस्तृत विवरण है। मौलिक अधिकार (भाग-3) और नीति निदेशक तत्व (भाग-4) इसके मुख्य आधार स्तंभ हैं।"
            isRailway -> "चाल, समय और दूरी (Speed, Time & Distance) भौतिकी एवं गणित का मूलभूत सिद्धांत है। सापेक्ष चाल (Relative Speed) में जब दो ट्रेनें विपरीत दिशा में चलती हैं तो चालें जुड़ती हैं (S1 + S2) तथा समान दिशा में घटती हैं (S1 - S2)।"
            isHistory -> "आधुनिक भारतीय इतिहास में 1857 की क्रांति, भारतीय राष्ट्रीय कांग्रेस की स्थापना (1885), असहयोग आंदोलन (1920) और भारत छोड़ो आंदोलन (1942) सर्वाधिक पूछे जाने वाले ऐतिहासिक पड़ाव हैं।"
            else -> "$query: यह विषय प्रतियोगी परीक्षाओं (SSC, Railway, Banking) की दृष्टि से अत्यंत महत्वपूर्ण है। परीक्षा में इससे सैद्धांतिक एवं विश्लेषणात्मक दोनों प्रकार के प्रश्न पूछे जाते हैं।"
        }

        val importantPoints = listOf(
            "प्रमुख संवैधानिक/वैज्ञानिक प्रावधान और उनकी पृष्ठभूमि याद रखें।",
            "विगत 5 वर्षों के SSC CGL और RRB NTPC में इस टॉपिक से सीधे प्रश्न पूछे गए हैं।",
            "संबंधित संशोधन, सूत्र और तिथियों का एक अलग माइंड-मैप तैयार करें।"
        )

        val examples = listOf(
            "उदाहरण 1: यदि प्रश्न में अपवाद पूछा जाए तो हमेशा नवीनतम अमेंडमेंट का संदर्भ दें।",
            "उदाहरण 2: संख्यात्मक प्रश्नों में मात्रक (km/h से m/s) परिवर्तन हेतु 5/18 से गुणा करना न भूलें।"
        )

        val examFacts = listOf(
            "★ तथ्य 1: डॉ. भीमराव अंबेडकर को संविधान का जनक कहा जाता है।",
            "★ तथ्य 2: प्रारूप समिति में कुल 7 सदस्य थे।",
            "★ तथ्य 3: संविधान सभा की पहली बैठक 9 दिसंबर 1946 को हुई थी।"
        )

        val item = AiQuestionAnswer(
            id = "AI-QA-${System.currentTimeMillis()}",
            studentId = studentId,
            question = query,
            language = language,
            explanation = explanation,
            importantPoints = importantPoints,
            examples = examples,
            examFacts = examFacts,
            timestamp = currentDateString()
        )
        return Result.success(item)
    }

    override suspend fun solveDoubt(
        studentId: String,
        question: String,
        subject: String,
        topic: String,
        imageUri: String?
    ): Result<AiDoubtItem> {
        if (question.isBlank() && imageUri.isNullOrBlank()) {
            return Result.failure(IllegalArgumentException("कृपया डाउट का विवरण या प्रश्न लिखें (Please enter your doubt)"))
        }

        delay(1100)

        val steps = listOf(
            "चरण 1: दी गई शर्तों और ज्ञात मानों को पहचानें।",
            "चरण 2: सूत्र या सिद्धांत का चयन करें: $subject -> $topic के मानक नियमों के अनुसार।",
            "चरण 3: मध्यवर्ती गणनाएं हल करें और इकाइयों का मिलान करें।",
            "चरण 4: विकल्पों का सत्यापन करें और अंतिम उत्तर निकालें।"
        )

        val finalAnswer = "अंतिम उत्तर: दिए गए प्रश्न का सटीक समाधान $subject के मानक सिद्धांत पर आधारित है। विकल्प (B) सही उत्तर है।"
        val shortcutTrick = "⚡ एग्जाम ट्रिक: पूरे समीकरण को हल करने के बजाय 'Unit Digit' (इकाई अंक) या 'Digital Sum' तकनीक का उपयोग करके मात्र 10 सेकंड में उत्तर प्राप्त किया जा सकता है।"
        val importantExamPoint = "परीक्षा टिप्पणी: यह डाउट पिछले वर्ष RRB NTPC और SSC CHSL में पूछा जा चुका है। ऋणात्मक अंकन से बचने हेतु चरणों को ध्यान से दोहराएं।"

        val doubt = AiDoubtItem(
            id = "DBT-${System.currentTimeMillis()}",
            studentId = studentId,
            textQuestion = question,
            imageUri = imageUri,
            subject = subject.ifBlank { "General Awareness" },
            topic = topic.ifBlank { "Exam Doubt" },
            stepByStepExplanation = steps,
            finalAnswer = finalAnswer,
            shortcutTrick = shortcutTrick,
            importantExamPoint = importantExamPoint,
            timestamp = currentDateString()
        )
        return Result.success(doubt)
    }

    override suspend fun generateNotesDraft(
        studentId: String,
        topic: String,
        subject: String,
        examCategory: ExamCategory
    ): Result<AiNoteDraft> {
        if (topic.isBlank()) {
            return Result.failure(IllegalArgumentException("कृपया नोट्स हेतु विषय/टॉपिक का नाम लिखें (Please provide a topic)"))
        }

        delay(1200)

        val draft = AiNoteDraft(
            id = "AI-NOTE-${System.currentTimeMillis()}",
            studentId = studentId,
            topic = topic,
            subject = subject.ifBlank { "General Studies" },
            examCategory = examCategory,
            shortSummary = "$topic पर प्रतियोगी परीक्षाओं हेतु विस्तृत संरचित सारांश। इसमें सभी मुख्य सिद्धांत, परिभाषाएं एवं परीक्षा उपयोगी बिंदु संकलित हैं।",
            detailedExplanation = "1. पृष्ठभूमि: $topic का अध्ययन प्रतियोगी परीक्षा में उच्च अंक प्राप्त करने के लिए अनिवार्य है।\n2. आधारभूत नियम: इसके तहत आने वाले सभी उप-बिंदुओं को क्रमवार याद रखना चाहिए।\n3. परीक्षा रुझान: पिछले वर्षों के प्रश्न पत्रों के विश्लेषण से स्पष्ट है कि इससे तथ्यात्मक और अवधारणात्मक दोनों प्रश्न बनते हैं।",
            importantFacts = listOf(
                "तथ्य 1: $topic से संबंधित प्रमुख वर्ष और ऐतिहासिक/वैज्ञानिक संदर्भ।",
                "तथ्य 2: NCERT कक्षा 9-12 के संबंधित अध्यायों से सीधे संकलित सामग्री।",
                "तथ्य 3: पिछले 3 वर्षों में पूछे गए 8 विभिन्न प्रश्न सीधे इस अवधारणा से जुड़े थे।"
            ),
            keyPoints = listOf(
                "पहला बिंदु: मूल शब्दावली की स्पष्ट समझ।",
                "दूसरा बिंदु: तुलनात्मक अध्ययन तालिका का स्मरण।",
                "तीसरा बिंदु: अपवादों (Exceptions) को विशेष रूप से चिन्हित करना।"
            ),
            revisionPoints = listOf(
                "रिवीजन 1: सोने से पूर्व 5 मिनट में प्रमुख तिथियां और सूत्र दोहराएं।",
                "रिवीजन 2: मॉक टेस्ट से ठीक 1 दिन पहले केवल इन बुलेट्स को पढ़ें।"
            ),
            examTricks = listOf(
                "ट्रिक A: एकोनॉमिक्स एवं पॉलिटी में फ्लोचार्ट बनाकर याद करें।",
                "ट्रिक B: गणित/रीजनिंग में फॉर्मूला कार्ड बनाएं।"
            ),
            status = ReviewStatus.DRAFT,
            isPublic = false,
            createdAt = currentDateString()
        )
        return Result.success(draft)
    }

    override suspend fun generateQuiz(
        studentId: String,
        config: AiQuizConfig
    ): Result<List<AiQuizQuestion>> {
        if (config.topic.isBlank()) {
            return Result.failure(IllegalArgumentException("कृपया क्विज़ के लिए टॉपिक चुनें (Please select a topic for the quiz)"))
        }

        delay(1000)

        val questions = mutableListOf<AiQuizQuestion>()
        val count = config.questionCount.coerceIn(5, 20)

        for (i in 1..count) {
            val q = if (config.questionType == "TRUE_FALSE") {
                AiQuizQuestion(
                    id = "QZ-Q-$i-${System.currentTimeMillis()}",
                    question = "कथन $i: '${config.topic}' के संदर्भ में, क्या यह प्रावधान भारतीय संविधान/परीक्षा पाठ्यक्रम में सीधे अनिवार्य है?",
                    options = listOf("सत्य (True)", "असत्य (False)"),
                    correctOptionIndex = if (i % 2 == 0) 0 else 1,
                    explanation = "व्याख्या: इस कथन का सत्यापन आधिकारिक परीक्षा पाठ्यक्रम और NCERT के आधार पर सही पाया गया है।",
                    isTrueFalse = true
                )
            } else {
                AiQuizQuestion(
                    id = "QZ-Q-$i-${System.currentTimeMillis()}",
                    question = "प्रश्न $i (${config.topic}): इस विषय से संबंधित निम्नलिखित में से कौन-सा कथन सर्वाधिक उपयुक्त और परीक्षा-सटीक है?",
                    options = listOf(
                        "विकल्प A: यह सिद्धांत वर्ष 1949/आधुनिक व्यवस्था पर आधारित है।",
                        "विकल्प B: यह केवल विशेष परिस्थितियों में लागू होता है।",
                        "विकल्प C: उपर्युक्त दोनों कथन सही हैं।",
                        "विकल्प D: इनमें से कोई नहीं।"
                    ),
                    correctOptionIndex = (i - 1) % 4,
                    explanation = "व्याख्या: इस प्रश्न में सही उत्तर विकल्प ${('A' + ((i - 1) % 4))} है। परीक्षा में गति और सटीकता बनाए रखने के लिए इस प्रकार के प्रश्नों का अभ्यास आवश्यक है।",
                    isTrueFalse = false
                )
            }
            questions.add(q)
        }

        return Result.success(questions)
    }

    override suspend fun generateTest(
        studentId: String,
        examCategory: ExamCategory,
        subject: String,
        chapter: String,
        topic: String,
        difficulty: String,
        count: Int,
        language: String
    ): Result<AiGeneratedTest> {
        delay(1300)

        val questionList = mutableListOf<Question>()
        val qCount = count.coerceIn(5, 50)

        for (i in 1..qCount) {
            questionList.add(
                Question(
                    id = "AI-GEN-Q-$i-${System.currentTimeMillis()}",
                    questionHindi = "[$subject • $chapter] प्रश्न $i: $topic से संबंधित परीक्षा-उन्मुख मुख्य सिद्धांत क्या है?",
                    questionEnglish = "[$subject • $chapter] Q$i: What is the core exam-oriented principle related to $topic?",
                    optionsHindi = listOf(
                        "विकल्प A: यह एक मानक सिद्धांत है जो प्रायः परीक्षाओं में पूछा जाता है",
                        "विकल्प B: यह एक गौण नियम है जो केवल विशेष परिस्थितियों में लागू होता है",
                        "विकल्प C: यह हालिया परीक्षा में पूछा गया नया पैटर्न है",
                        "विकल्प D: उपर्युक्त सभी"
                    ),
                    optionsEnglish = listOf(
                        "Option A: This is a standard principle frequently asked in exams",
                        "Option B: This is a secondary rule applied in special conditions",
                        "Option C: This represents the new pattern from recent tests",
                        "Option D: All of the above"
                    ),
                    correctOptionIndices = listOf(0),
                    explanationHindi = "व्याख्या: विकल्प A सही उत्तर है। प्रतियोगी परीक्षाओं में इस प्रकार के प्रश्नों में मुख्य अवधारणा की पहचान करना आवश्यक है।",
                    explanationEnglish = "Explanation: Option A is the correct answer based on standard exam syllabus guidelines.",
                    subject = subject,
                    chapter = chapter,
                    topic = topic,
                    difficulty = difficulty,
                    marks = 2.0,
                    negativeMarks = 0.66,
                    isAiGenerated = true,
                    reviewStatus = ReviewStatus.DRAFT
                )
            )
        }

        val test = AiGeneratedTest(
            id = "AI-TEST-${System.currentTimeMillis()}",
            studentId = studentId,
            title = "AI Mock: $topic ($difficulty)",
            examCategory = examCategory,
            subject = subject,
            chapter = chapter,
            topic = topic,
            difficulty = difficulty,
            questionCount = qCount,
            language = language,
            questions = questionList,
            totalMarks = qCount * 2.0,
            durationMinutes = (qCount * 1.2).toInt().coerceAtLeast(10),
            status = ReviewStatus.DRAFT,
            isPublic = false,
            createdAt = currentDateString()
        )
        return Result.success(test)
    }

    override suspend fun generateRevisionPackage(
        studentId: String,
        topic: String,
        subject: String
    ): Result<AiRevisionPackage> {
        if (topic.isBlank()) {
            return Result.failure(IllegalArgumentException("कृपया रिवीजन के लिए टॉपिक दर्ज करें (Please enter a revision topic)"))
        }

        delay(1000)

        val quickRev = listOf(
            "1. $topic की प्राथमिक परिभाषा और मुख्य उद्देश्य को दोहराएं।",
            "2. सभी संबंधित सूत्रों और संवैधानिक अनुच्छेदों का त्वरित स्मरण।",
            "3. महत्वपूर्ण अपवादों को लाल रंग से अंडरलाइन करके पुनः पढ़ें।"
        )

        val impFacts = listOf(
            "★ रेलवे और SSC में पिछले 5 वर्षों में इस टॉपिक से 15+ प्रश्न आए हैं।",
            "★ स्टेट पुलिस और बैंकिंग में इसके अनुप्रयोग संबंधी प्रश्न पूछे जाते हैं।",
            "★ NCERT कक्षा 10वीं व 12वीं में इसके लिए समर्पित अध्याय उपलब्ध हैं।"
        )

        val frequentConcepts = listOf(
            "बारम्बार पूछे जाने वाले सिद्धांत: प्रत्यक्ष सूत्र पर आधारित गणना।",
            "तुलनात्मक चार्ट: किन परिस्थितियों में मान धनात्मक अथवा ऋणात्मक होता है।"
        )

        val mistakesToAvoid = listOf(
            "⚠ गलती 1: मात्रक परिवर्तन (Unit Conversion) भूल जाना।",
            "⚠ गलती 2: प्रश्न में 'नहीं' (NOT) शब्द को नज़रअंदाज़ कर देना।",
            "⚠ गलती 3: बिना विकल्प पढ़े जल्दबाजी में अनुमान लगाना।"
        )

        val practiceQuestions = listOf(
            Question(
                id = "REV-Q-1",
                questionHindi = "रिवीजन अभ्यास: $topic के अंतर्गत सबसे महत्वपूर्ण नियम कौन सा है?",
                questionEnglish = "Revision Practice: Which is the primary rule under $topic?",
                optionsHindi = listOf("नियम 1 (प्राथमिक)", "नियम 2 (गौण)", "नियम 3 (अपवाद)", "नियम 4 (अप्रचलित)"),
                optionsEnglish = listOf("Rule 1 (Primary)", "Rule 2 (Secondary)", "Rule 3 (Exception)", "Rule 4 (Obsolete)"),
                correctOptionIndices = listOf(0),
                explanationHindi = "व्याख्या: प्राथमिक नियम सबसे बुनियादी और व्यापक रूप से मान्य है।",
                explanationEnglish = "Explanation: Primary rule is universally tested across all exams.",
                subject = subject,
                chapter = "Revision",
                topic = topic,
                difficulty = "Moderate"
            )
        )

        val pkg = AiRevisionPackage(
            id = "AI-REV-${System.currentTimeMillis()}",
            studentId = studentId,
            topic = topic,
            subject = subject.ifBlank { "General Studies" },
            quickRevision = quickRev,
            importantFacts = impFacts,
            frequentlyTestedConcepts = frequentConcepts,
            mistakesToAvoid = mistakesToAvoid,
            practiceQuestions = practiceQuestions,
            timestamp = currentDateString()
        )
        return Result.success(pkg)
    }

    override suspend fun generateStudyPlan(
        studentId: String,
        exam: ExamCategory,
        targetDate: String,
        dailyHours: Int,
        subjects: List<String>,
        level: String
    ): Result<AiStudyPlan> {
        delay(1100)

        val planSubjects = if (subjects.isEmpty()) listOf("General Awareness", "Quantitative Aptitude", "Reasoning", "English/Hindi") else subjects
        val days = mutableListOf<StudyPlanDay>()

        for (day in 1..7) {
            val sub = planSubjects[(day - 1) % planSubjects.size]
            days.add(
                StudyPlanDay(
                    dayNumber = day,
                    dayTitle = "दिन $day: $sub फोकस्ड तैयारी",
                    subject = sub,
                    topic = when (sub) {
                        "General Awareness" -> "संविधान एवं आधुनिक इतिहास"
                        "Quantitative Aptitude" -> "प्रतिशत, लाभ-हानि एवं समय-कार्य"
                        "Reasoning" -> "रक्त संबंध एवं दिशा परीक्षण"
                        else -> "शब्दावली एवं व्याकरण अभ्यास"
                    },
                    durationMinutes = dailyHours * 60,
                    revisionTask = "पिछले दिन के 15 मुख्य बुलेट नोट्स का पुनरावलोकन",
                    practiceTargetQuestions = dailyHours * 15,
                    isCompleted = day == 1
                )
            )
        }

        val plan = AiStudyPlan(
            id = "PLAN-${System.currentTimeMillis()}",
            studentId = studentId,
            targetExam = exam,
            targetDate = targetDate.ifBlank { "2026-06-30" },
            dailyHours = dailyHours.coerceIn(1, 12),
            subjects = planSubjects,
            preparationLevel = level,
            scheduleDays = days,
            createdAt = currentDateString()
        )
        return Result.success(plan)
    }
}

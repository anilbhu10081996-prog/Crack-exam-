package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class CrackExamRepository {

    // Current Session / User
    private val _currentUser = MutableStateFlow(
        UserProfile(
            id = "USR-2026-901",
            fullName = "Aman Kumar Sharma",
            mobile = "+91 98765 43210",
            email = "10081996ak@gmail.com",
            role = UserRole.STUDENT,
            targetExam = ExamCategory.RAILWAY,
            targetSubExam = "RRB NTPC CBT-2",
            state = "Uttar Pradesh",
            preferredLanguage = "Hindi + English",
            preparationLevel = "Intermediate",
            isProSubscriber = true,
            enrolledBatches = listOf("B-RRB-2026-ALPHA"),
            accuracyPercentage = 84,
            totalTestsAttempted = 38,
            overallRank = 142,
            streakDays = 18
        )
    )
    val currentUser: StateFlow<UserProfile> = _currentUser.asStateFlow()

    private val _selectedExam = MutableStateFlow(ExamCategory.RAILWAY)
    val selectedExam: StateFlow<ExamCategory> = _selectedExam.asStateFlow()

    // Test Series Data
    private val _testSeries = MutableStateFlow<List<TestSeries>>(
        listOf(
            TestSeries("TS-RRB-01", ExamCategory.RAILWAY, "RRB NTPC CBT-1 & CBT-2 Full Mock Pack", "NTPC", 30, 18, "Moderate", 78.5, 86.0, false, "Trending"),
            TestSeries("TS-RRB-02", ExamCategory.RAILWAY, "RRB Group D Speed Booster Series", "Group D", 25, 12, "Easy", 81.2, 88.5, true, "Free Mock"),
            TestSeries("TS-RRB-03", ExamCategory.RAILWAY, "RRB ALP & Technician Technical + Non-Tech", "ALP", 20, 5, "Hard", 69.4, 79.0, false, "High Yield"),
            TestSeries("TS-SSC-01", ExamCategory.SSC, "SSC CGL 2026 Tier 1 All India Ranker Test", "CGL", 40, 22, "Hard", 138.0, 84.0, false, "Best Seller"),
            TestSeries("TS-SSC-02", ExamCategory.SSC, "SSC CHSL 10+2 Practice Mocks", "CHSL", 25, 14, "Moderate", 144.5, 87.0, true, "Free Mock"),
            TestSeries("TS-BNK-01", ExamCategory.BANKING, "SBI PO Prelims + Mains Complete Mock", "SBI PO", 35, 16, "Hard", 64.0, 89.2, false, "Top Rated"),
            TestSeries("TS-BNK-02", ExamCategory.BANKING, "IBPS Clerk Speed & Accuracy Drills", "IBPS Clerk", 25, 20, "Moderate", 76.5, 91.0, true, "Free"),
            TestSeries("TS-POL-01", ExamCategory.POLICE, "UP Police Sub-Inspector (SI) Mahamock", "UP SI", 20, 8, "Moderate", 242.0, 83.5, false, "State Special"),
            TestSeries("TS-DEF-01", ExamCategory.DEFENCE, "NDA & NA Mathematics + GAT Comprehensive", "NDA", 15, 6, "Hard", 360.0, 80.0, false, "Strict Timing"),
            TestSeries("TS-UPS-01", ExamCategory.UPSC, "UPSC CSE Prelims GS-1 + CSAT Test Series", "Civil Services", 24, 7, "Hard", 98.0, 78.0, false, "IAS Target")
        )
    )
    val testSeries: StateFlow<List<TestSeries>> = _testSeries.asStateFlow()

    // Full Tests Data
    private val _tests = MutableStateFlow<List<ExamTest>>(
        listOf(
            createSampleLiveTest("TEST-LIVE-01", "RRB NTPC All India Live Test #14", ExamCategory.RAILWAY, "TS-RRB-01", 90, 100, 100.0, 0.33),
            createSampleLiveTest("TEST-LIVE-02", "SSC CGL Tier-1 Super Mock 09", ExamCategory.SSC, "TS-SSC-01", 60, 100, 200.0, 0.25),
            createSampleLiveTest("TEST-LIVE-03", "SBI PO Prelims Daily Speed Test", ExamCategory.BANKING, "TS-BNK-01", 60, 100, 100.0, 0.25)
        )
    )
    val tests: StateFlow<List<ExamTest>> = _tests.asStateFlow()

    // Question Bank Items
    private val _questionBank = MutableStateFlow<List<Question>>(
        getSampleQuestionBank()
    )
    val questionBank: StateFlow<List<Question>> = _questionBank.asStateFlow()

    // Study Notes
    private val _notes = MutableStateFlow<List<StudyNote>>(
        listOf(
            StudyNote(
                id = "NOTE-01",
                examCategory = ExamCategory.RAILWAY,
                subject = "General Science",
                chapter = "Physics - Mechanics",
                topic = "Newton's Laws & Momentum",
                title = "न्यूटन के गति नियम और संवेग संरक्षण (Comprehensive Quick Notes)",
                summary = "First, Second & Third Law with railway exam frequent numerical formulas and real life examples.",
                content = "1. प्रथम नियम (जड़त्व का नियम): कोई वस्तु विराम में है तो विराम में ही रहेगी जब तक बाह्य बल न लगे।\n2. द्वितीय नियम: F = m × a (बल = द्रव्यमान × त्वरण)\n3. तृतीय नियम: क्रिया के बराबर तथा विपरीत दिशा में प्रतिक्रिया होती है।\n★ RRB बारम्बार पूछे जाने वाले बिंदु: रॉकेट प्रणोदन संवेग संरक्षण नियम पर आधारित है।",
                readMinutes = 6,
                isBookmarked = true
            ),
            StudyNote(
                id = "NOTE-02",
                examCategory = ExamCategory.SSC,
                subject = "General Awareness",
                chapter = "Indian Polity",
                topic = "Fundamental Rights & Articles",
                title = "भारतीय संविधान: मूल अधिकार (अनुच्छेद 12 से 35)",
                summary = "Complete breakdown of 6 Fundamental Rights, Writs under Article 32, and amendment exceptions.",
                content = "अनुच्छेद 14: विधि के समक्ष समता\nअनुच्छेद 19: वाक् एवं अभिव्यक्ति की स्वतंत्रता\nअनुच्छेद 21: प्राण और दैहिक स्वतंत्रता का अधिकार\nअनुच्छेद 32: संवैधानिक उपचारों का अधिकार (डॉ. अंबेडकर ने इसे संविधान की आत्मा कहा)।",
                readMinutes = 8,
                isBookmarked = false
            ),
            StudyNote(
                id = "NOTE-03",
                examCategory = ExamCategory.BANKING,
                subject = "Quantitative Aptitude",
                chapter = "Arithmetic",
                topic = "Time, Speed and Distance Tricks",
                title = "Speed, Time & Train Problems Shortcut Formulae",
                summary = "Relative speed, crossing platform vs pole, and average speed harmonic formulas.",
                content = "Formula 1: km/h to m/s -> Multiply by 5/18\nFormula 2: Train crossing pole -> Distance = Length of Train\nFormula 3: Relative speed in opposite direction = S1 + S2\nFormula 4: Relative speed in same direction = |S1 - S2|",
                readMinutes = 5,
                isBookmarked = true
            )
        )
    )
    val notes: StateFlow<List<StudyNote>> = _notes.asStateFlow()

    // Books
    private val _books = MutableStateFlow<List<BookItem>>(
        listOf(
            BookItem("BK-01", "NCERT Science Class 9 & 10 Master Digest", "NCERT Board", "NCERT", ExamCategory.RAILWAY, 320, 16, 4.8, true),
            BookItem("BK-02", "RRB General Awareness 2026 Booster (Hindi)", "Crack Exam Editorial", "Exam Books", ExamCategory.RAILWAY, 410, 24, 4.9, false),
            BookItem("BK-03", "Pinnacle SSC CGL 6500+ TCS MCQ Solved", "Pinnacle Publication", "Practice Books", ExamCategory.SSC, 580, 32, 4.7, false),
            BookItem("BK-04", "Quantitative Aptitude for Competitive Exams", "Dr. R.S. Aggarwal", "Reference Books", ExamCategory.BANKING, 740, 40, 4.8, false),
            BookItem("BK-05", "Monthly Current Affairs Capsule (Last 6 Months)", "Crack Exam Team", "Current Affairs", ExamCategory.UPSC, 180, 6, 4.9, true)
        )
    )
    val books: StateFlow<List<BookItem>> = _books.asStateFlow()

    // Past Results
    private val _results = MutableStateFlow<List<TestResult>>(
        listOf(
            TestResult(
                id = "RES-01",
                testId = "TEST-LIVE-01",
                testTitle = "RRB NTPC All India Live Test #13",
                examCategory = ExamCategory.RAILWAY,
                totalMarks = 100.0,
                scoredMarks = 82.33,
                totalQuestions = 100,
                correctCount = 86,
                wrongCount = 11,
                skippedCount = 3,
                accuracyPercentage = 88.6,
                timeTakenSeconds = 4820,
                rank = 142,
                totalParticipants = 14520,
                percentile = 99.02,
                dateAttempted = "05 Oct 2026"
            ),
            TestResult(
                id = "RES-02",
                testId = "TEST-LIVE-02",
                testTitle = "SSC CGL Tier-1 Super Mock 08",
                examCategory = ExamCategory.SSC,
                totalMarks = 200.0,
                scoredMarks = 154.5,
                totalQuestions = 100,
                correctCount = 82,
                wrongCount = 10,
                skippedCount = 8,
                accuracyPercentage = 89.1,
                timeTakenSeconds = 3410,
                rank = 310,
                totalParticipants = 22400,
                percentile = 98.61,
                dateAttempted = "02 Oct 2026"
            )
        )
    )
    val results: StateFlow<List<TestResult>> = _results.asStateFlow()

    // Leaderboards
    private val _leaderboards = MutableStateFlow<List<LeaderboardEntry>>(
        listOf(
            LeaderboardEntry(1, "Vikramaditya Rathore", "RRB NTPC", 96.67, 98.0, 48, "Rajasthan"),
            LeaderboardEntry(2, "Sneha Mukherjee", "SSC CGL", 95.33, 96.5, 52, "West Bengal"),
            LeaderboardEntry(3, "Deepak Yadav", "RRB ALP", 94.00, 95.2, 44, "Bihar"),
            LeaderboardEntry(4, "Pooja Deshmukh", "Banking PO", 93.33, 94.0, 41, "Maharashtra"),
            LeaderboardEntry(5, "Rahul Meena", "Police SI", 92.67, 93.8, 39, "Madhya Pradesh"),
            LeaderboardEntry(142, "Aman Kumar Sharma (You)", "RRB NTPC", 82.33, 88.6, 38, "Uttar Pradesh", isCurrentUser = true)
        )
    )
    val leaderboards: StateFlow<List<LeaderboardEntry>> = _leaderboards.asStateFlow()

    // Coaching Management Data
    private val _coachingProfile = MutableStateFlow(CoachingProfile())
    val coachingProfile: StateFlow<CoachingProfile> = _coachingProfile.asStateFlow()

    private val _teachers = MutableStateFlow<List<TeacherRecord>>(
        listOf(
            TeacherRecord("TCH-01", "Er. Rajesh Verma", "+91 98111 00222", "rajesh.verma@crackexam.in", listOf("Mathematics", "Reasoning"), listOf("BATCH-01"), "M.Tech, 12 Yrs Exp"),
            TeacherRecord("TCH-02", "Dr. Sunita Sharma", "+91 98222 00333", "sunita.sharma@crackexam.in", listOf("General Science", "Polity"), listOf("BATCH-02"), "Ph.D., GS Topper Mentor"),
            TeacherRecord("TCH-03", "Amit Tripathy", "+91 98333 00444", "amit.t@crackexam.in", listOf("Quantitative Aptitude", "DI"), listOf("BATCH-03"), "Ex-SBI PO, Aptitude Lead"),
            TeacherRecord("TCH-04", "Subhash Yadav", "+91 98444 00555", "subhash.y@crackexam.in", listOf("General Hindi", "State Law"), listOf("BATCH-04"), "M.A. Hindi, Police Special")
        )
    )
    val teachers: StateFlow<List<TeacherRecord>> = _teachers.asStateFlow()

    private val _timetable = MutableStateFlow<List<TimetableEntry>>(
        listOf(
            TimetableEntry("TT-01", "BATCH-01", "RRB NTPC 2026 Alpha Batch", "Mathematics", "Er. Rajesh Verma", "Room 101", "Monday", "08:00 AM - 10:30 AM"),
            TimetableEntry("TT-02", "BATCH-01", "RRB NTPC 2026 Alpha Batch", "General Science", "Dr. Sunita Sharma", "Room 101", "Tuesday", "08:00 AM - 10:30 AM"),
            TimetableEntry("TT-03", "BATCH-02", "SSC CGL 2026 Target Ranker", "Polity & GK", "Dr. Sunita Sharma", "Room 203", "Monday", "11:00 AM - 01:30 PM"),
            TimetableEntry("TT-04", "BATCH-03", "Banking PO Speed & DI Special", "DI & Arithmetic", "Amit Tripathy", "Room 102", "Wednesday", "02:00 PM - 04:30 PM")
        )
    )
    val timetable: StateFlow<List<TimetableEntry>> = _timetable.asStateFlow()

    private val _testFolders = MutableStateFlow<List<TestFolder>>(
        listOf(
            TestFolder("FLD-01", "RRB NTPC CBT-2 Premium Mocks", "Exam", 8),
            TestFolder("FLD-02", "SSC CGL Tier-1 2026 All India Series", "TestSeries", 12),
            TestFolder("FLD-03", "General Science 1000 High Yield MCQs", "Question", 24),
            TestFolder("FLD-04", "Quantitative Aptitude Short Tricks", "Course", 15)
        )
    )
    val testFolders: StateFlow<List<TestFolder>> = _testFolders.asStateFlow()

    private val _coachingBatches = MutableStateFlow<List<CoachingBatch>>(
        listOf(
            CoachingBatch("BATCH-01", "RRB NTPC 2026 Alpha Batch", ExamCategory.RAILWAY, "Er. Rajesh Verma", "Maths & Reasoning", "08:00 AM - 10:30 AM", 120, "Room 101 - Smart Hall"),
            CoachingBatch("BATCH-02", "SSC CGL 2026 Target Ranker", ExamCategory.SSC, "Dr. Sunita Sharma", "English & GS", "11:00 AM - 01:30 PM", 145, "Room 203 - Main Wing"),
            CoachingBatch("BATCH-03", "Banking PO Speed & DI Special", ExamCategory.BANKING, "Amit Tripathy", "Quantitative DI", "02:00 PM - 04:30 PM", 95, "Room 102 - Lab A"),
            CoachingBatch("BATCH-04", "UP Police Constable Mahabatch", ExamCategory.POLICE, "Subhash Yadav", "General Hindi & Law", "05:00 PM - 07:30 PM", 180, "Auditorium Hall")
        )
    )
    val coachingBatches: StateFlow<List<CoachingBatch>> = _coachingBatches.asStateFlow()

    private val _coachingStudents = MutableStateFlow<List<StudentRecord>>(
        listOf(
            StudentRecord("STU-101", "Aman Kumar Sharma", "+91 98765 43210", "aman.sharma@example.com", "BATCH-01", "RRB NTPC Alpha", 94, 142, "Shri R. K. Sharma", "+91 94150 00000", "12 Jan 2026", "Active"),
            StudentRecord("STU-102", "Priya Verma", "+91 98111 22334", "priya.verma@example.com", "BATCH-01", "RRB NTPC Alpha", 98, 24, "Shri S. Verma", "+91 94150 11111", "14 Jan 2026", "Active"),
            StudentRecord("STU-103", "Rohit Choudhary", "+91 97222 33445", "rohit.c@example.com", "BATCH-02", "SSC CGL Ranker", 88, 76, "Shri M. Choudhary", "+91 94150 22222", "15 Jan 2026", "Active"),
            StudentRecord("STU-104", "Kavita Saini", "+91 96333 44556", "kavita.s@example.com", "BATCH-03", "Banking PO Special", 91, 55, "Shri D. Saini", "+91 94150 33333", "18 Jan 2026", "Active"),
            StudentRecord("STU-105", "Manish Tiwari", "+91 95444 55667", "manish.t@example.com", "BATCH-04", "UP Police Mahabatch", 85, 110, "Shri K. Tiwari", "+91 94150 44444", "20 Jan 2026", "Active")
        )
    )
    val coachingStudents: StateFlow<List<StudentRecord>> = _coachingStudents.asStateFlow()

    private val _attendanceHistory = MutableStateFlow<List<AttendanceRecord>>(
        listOf(
            AttendanceRecord("ATT-01", "06 Oct 2026", "BATCH-01", "RRB NTPC Alpha", 112, 6, 2),
            AttendanceRecord("ATT-02", "06 Oct 2026", "BATCH-02", "SSC CGL Ranker", 136, 7, 2),
            AttendanceRecord("ATT-03", "05 Oct 2026", "BATCH-01", "RRB NTPC Alpha", 114, 4, 2),
            AttendanceRecord("ATT-04", "05 Oct 2026", "BATCH-03", "Banking PO Special", 89, 5, 1)
        )
    )
    val attendanceHistory: StateFlow<List<AttendanceRecord>> = _attendanceHistory.asStateFlow()

    // Notices
    private val _notices = MutableStateFlow<List<NoticeItem>>(
        listOf(
            NoticeItem("NOT-01", "RRB NTPC CBT-2 All India Mahamock Live this Sunday 10 AM", "Rank 1 to 10 will receive free 1-year test series and coaching scholarship kit.", "Test", "All Students", "2 hours ago", true),
            NoticeItem("NOT-02", "Special Doubt Session by Er. Rajesh Verma on Compound Interest", "Batch 01 & 02 students must carry their practice modules to Room 101.", "Class", "BATCH-01", "5 hours ago", false),
            NoticeItem("NOT-03", "SSC CGL Tier-1 Official Answer Key Released - Rank Predictor Active", "Check your expected score and normalization shift analysis now in Results tab.", "Result", "All Students", "1 day ago", true)
        )
    )
    val notices: StateFlow<List<NoticeItem>> = _notices.asStateFlow()

    // Audit Logs
    private val _auditLogs = MutableStateFlow<List<AuditLogItem>>(
        listOf(
            AuditLogItem("LOG-01", "Admin Verma", "Super Admin", "PUBLISHED_TEST", "RRB NTPC Live Mock #14", "TEST-01", "10 mins ago", "Success"),
            AuditLogItem("LOG-02", "Content Team 2", "Test Creator", "APPROVED_QUESTIONS", "50 AI Generated Polity Questions", "QB-01", "45 mins ago", "Success"),
            AuditLogItem("LOG-03", "Faculty Rajesh", "Teacher", "RECORDED_ATTENDANCE", "Batch 01 (112 Present)", "BATCH-01", "2 hours ago", "Success"),
            AuditLogItem("LOG-04", "Admin Verma", "Super Admin", "UPDATED_MEMBERSHIP_FEE", "Pro Plan INR 999 -> INR 849 Festival Offer", "MEM-01", "5 hours ago", "Success")
        )
    )
    val auditLogs: StateFlow<List<AuditLogItem>> = _auditLogs.asStateFlow()

    // AI Study Persistent State (Private per student with review workflow)
    private val _aiQuestionAnswers = MutableStateFlow<List<AiQuestionAnswer>>(
        listOf(
            AiQuestionAnswer(
                id = "AI-QA-SAMPLE-1",
                studentId = "USR-2026-901",
                question = "भारतीय संविधान क्या है?",
                language = "Hindi + English",
                explanation = "भारतीय संविधान भारत का सर्वोच्च विधान है जो 26 जनवरी 1950 को लागू हुआ था। यह विश्व का सबसे बड़ा लिखित संविधान है जिसमें 395 अनुच्छेद (वर्तमान में 448+), 12 अनुसूचियां और 25 भाग हैं।",
                importantPoints = listOf(
                    "प्रस्तावना को संविधान की कुंजी और आत्मा कहा जाता है।",
                    "डॉ. बी.आर. अंबेडकर प्रारूप समिति के अध्यक्ष थे।",
                    "संविधान सभा के निर्माण में 2 वर्ष, 11 माह और 18 दिन लगे।"
                ),
                examples = listOf(
                    "उदाहरण 1: भाग-3 मौलिक अधिकार (अनुच्छेद 12-35) नागरिकों को स्वतंत्रता व समानता प्रदान करते हैं।",
                    "उदाहरण 2: भाग-4 राज्य के नीति निदेशक तत्व कल्याणकारी राज्य की स्थापना का मार्ग प्रशस्त करते हैं।"
                ),
                examFacts = listOf(
                    "★ मूल संविधान हस्तलिखित था (प्रेम बिहारी नारायण रायजादा द्वारा लिखा गया)।",
                    "★ 42वें संविधान संशोधन (1976) को 'मिनी संविधान' कहा जाता है।"
                ),
                timestamp = "2026-02-14 10:30",
                isBookmarked = true
            )
        )
    )
    val aiQuestionAnswers: StateFlow<List<AiQuestionAnswer>> = _aiQuestionAnswers.asStateFlow()

    private val _aiDoubts = MutableStateFlow<List<AiDoubtItem>>(
        listOf(
            AiDoubtItem(
                id = "DBT-SAMPLE-1",
                studentId = "USR-2026-901",
                textQuestion = "दो ट्रेनें क्रमशः 54 km/h और 72 km/h से विपरीत दिशा में आ रही हैं। उनकी लंबाई 120m और 160m है। वे एक दूसरे को कितने सेकंड में पार करेंगी?",
                imageUri = null,
                subject = "Mathematics",
                topic = "Speed, Time & Distance",
                stepByStepExplanation = listOf(
                    "चरण 1: कुल दूरी = दोनों ट्रेनों की लंबाई = 120 + 160 = 280 मीटर।",
                    "चरण 2: विपरीत दिशा में सापेक्ष चाल = 54 + 72 = 126 km/h।",
                    "चरण 3: m/s में परिवर्तन = 126 × (5/18) = 7 × 5 = 35 m/s।",
                    "चरण 4: समय = कुल दूरी / सापेक्ष चाल = 280 / 35 = 8 सेकंड।"
                ),
                finalAnswer = "सही उत्तर: 8 सेकंड",
                shortcutTrick = "⚡ ट्रिक: सापेक्ष चाल (km/h) 18 का गुणज है (18×7 = 126), अतः m/s में 5×7 = 35 m/s होगा। समय = 280/35 = 8s तुरंत हल करें।",
                importantExamPoint = "यह प्रश्न RRB NTPC CBT-2 2022 में समान मानों के साथ पूछा गया था।",
                timestamp = "2026-02-13 18:15",
                isBookmarked = true
            )
        )
    )
    val aiDoubts: StateFlow<List<AiDoubtItem>> = _aiDoubts.asStateFlow()

    private val _aiNotesDrafts = MutableStateFlow<List<AiNoteDraft>>(
        listOf(
            AiNoteDraft(
                id = "AI-NOTE-SAMPLE-1",
                studentId = "USR-2026-901",
                topic = "न्यूटन के गति नियम एवं संवेग संरक्षण",
                subject = "General Science",
                examCategory = ExamCategory.RAILWAY,
                shortSummary = "न्यूटन के तीनों नियमों, संवेग संरक्षण सिद्धांत तथा रेलवे व SSC में पूछे जाने वाले उदाहरणों का संपूर्ण संकलन।",
                detailedExplanation = "प्रथम नियम जड़त्व का नियम है। द्वितीय नियम बल की परिभाषा (F = ma) और संवेग परिवर्तन की दर देता है। तृतीय नियम प्रत्येक क्रिया की समान व विपरीत प्रतिक्रिया बताता है।",
                importantFacts = listOf(
                    "रॉकेट प्रणोदन संवेग संरक्षण (Conservation of Momentum) पर आधारित है।",
                    "क्रिकेटर गेंद पकड़ते समय हाथ पीछे खींचता है ताकि आवेग (Impulse) कम हो सके।"
                ),
                keyPoints = listOf("जड़त्व द्रव्यमान का माप है।", "संवेग (p) = m × v (SI मात्रक kg·m/s)"),
                revisionPoints = listOf("संवेग संरक्षण में कुल बाह्य बल शून्य होना चाहिए।"),
                examTricks = listOf("घोड़े की गाड़ी खींचना तृतीय नियम और घर्षण बल का संयुक्त उदाहरण है।"),
                status = ReviewStatus.DRAFT,
                isPublic = false,
                createdAt = "2026-02-12 14:00",
                isBookmarked = false
            )
        )
    )
    val aiNotesDrafts: StateFlow<List<AiNoteDraft>> = _aiNotesDrafts.asStateFlow()

    private val _aiQuizSessions = MutableStateFlow<List<AiQuizSession>>(emptyList())
    val aiQuizSessions: StateFlow<List<AiQuizSession>> = _aiQuizSessions.asStateFlow()

    private val _aiGeneratedTests = MutableStateFlow<List<AiGeneratedTest>>(
        listOf(
            AiGeneratedTest(
                id = "AI-TEST-SAMPLE-1",
                studentId = "USR-2026-901",
                title = "AI Special Practice: भारतीय संविधान व संसद (10 Questions)",
                examCategory = ExamCategory.SSC,
                subject = "Polity",
                chapter = "Parliament",
                topic = "Lok Sabha & Rajya Sabha",
                difficulty = "Moderate",
                questionCount = 10,
                language = "Bilingual",
                questions = getSampleTestQuestions(ExamCategory.SSC).take(10),
                totalMarks = 20.0,
                durationMinutes = 12,
                status = ReviewStatus.DRAFT,
                isPublic = false,
                createdAt = "2026-02-11 11:20"
            )
        )
    )
    val aiGeneratedTests: StateFlow<List<AiGeneratedTest>> = _aiGeneratedTests.asStateFlow()

    private val _aiRevisionPackages = MutableStateFlow<List<AiRevisionPackage>>(
        listOf(
            AiRevisionPackage(
                id = "AI-REV-SAMPLE-1",
                studentId = "USR-2026-901",
                topic = "मौलिक अधिकार (Fundamental Rights)",
                subject = "General Awareness",
                quickRevision = listOf(
                    "अनुच्छेद 12-35 (भाग-3), अमेरिका के संविधान से प्रेरित।",
                    "मूल रूप से 7 थे, 44वें संशोधन (1978) द्वारा संपत्ति का अधिकार हटाया गया।"
                ),
                importantFacts = listOf(
                    "अनुच्छेद 20 और 21 राष्ट्रीय आपातकाल के दौरान भी निलंबित नहीं होते।",
                    "अनुच्छेद 32 के तहत सुप्रीम कोर्ट 5 प्रकार की रिट जारी करता है।"
                ),
                frequentlyTestedConcepts = listOf("विधि के समक्ष समता (अनुच्छेद 14)", "अस्पृश्यता का अंत (अनुच्छेद 17)"),
                mistakesToAvoid = listOf("आपातकाल में अनुच्छेद 19 स्वतः निलंबित होता है, अनुच्छेद 21 नहीं।"),
                practiceQuestions = getSampleTestQuestions(ExamCategory.RAILWAY).take(2),
                timestamp = "2026-02-10 16:40",
                isBookmarked = true
            )
        )
    )
    val aiRevisionPackages: StateFlow<List<AiRevisionPackage>> = _aiRevisionPackages.asStateFlow()

    private val _aiStudyPlans = MutableStateFlow<List<AiStudyPlan>>(
        listOf(
            AiStudyPlan(
                id = "PLAN-SAMPLE-1",
                studentId = "USR-2026-901",
                targetExam = ExamCategory.RAILWAY,
                targetDate = "2026-05-30",
                dailyHours = 4,
                subjects = listOf("Mathematics", "General Science", "Reasoning", "Current Affairs"),
                preparationLevel = "Intermediate",
                scheduleDays = listOf(
                    StudyPlanDay(1, "दिन 1: मैथ्स - समय और दूरी", "Mathematics", "Speed & Distance Formulas", 60, "बुलेट सूत्र दोहराएं", 25, true),
                    StudyPlanDay(2, "दिन 2: साइंस - न्यूटन के नियम", "General Science", "Mechanics & Gravitation", 60, "NCERT बुलेटिन रिवीजन", 30, true),
                    StudyPlanDay(3, "दिन 3: रीजनिंग - दिशा व दूरी", "Reasoning", "Direction Sense Tricks", 60, "गलत प्रश्नों की पुनरावृत्ति", 25, false),
                    StudyPlanDay(4, "दिन 4: करंट अफेयर्स - प्रमुख नियुक्तियां", "Current Affairs", "National & International Events", 60, "मासिक पत्रिका रिवीजन", 20, false),
                    StudyPlanDay(5, "दिन 5: संपूर्ण मॉक टेस्ट", "Full Mock", "RRB NTPC CBT-1 Full Paper", 90, "कमजोर क्षेत्रों का विश्लेषण", 100, false)
                ),
                createdAt = "2026-02-09"
            )
        )
    )
    val aiStudyPlans: StateFlow<List<AiStudyPlan>> = _aiStudyPlans.asStateFlow()

    private val _aiHistory = MutableStateFlow<List<AiHistoryItem>>(
        listOf(
            AiHistoryItem("HIST-01", "USR-2026-901", AiActivityType.QUESTION_ANSWER, "भारतीय संविधान क्या है?", "26 जनवरी 1950, 395 अनुच्छेद, प्रारूप समिति", "Today, 10:30 AM", "AI-QA-SAMPLE-1", true),
            AiHistoryItem("HIST-02", "USR-2026-901", AiActivityType.DOUBT_SOLVER, "ट्रेन स्पीड टाइम दूरी डाउट", "सापेक्ष चाल 126 km/h, समय 8s", "Yesterday, 06:15 PM", "DBT-SAMPLE-1", true),
            AiHistoryItem("HIST-03", "USR-2026-901", AiActivityType.NOTES, "न्यूटन के गति नियम नोट्स (Draft)", "General Science • Physics Mechanics", "2 days ago", "AI-NOTE-SAMPLE-1", false),
            AiHistoryItem("HIST-04", "USR-2026-901", AiActivityType.TEST_GENERATOR, "AI Mock: संविधान व संसद", "10 Questions • Moderate • Bilingual", "3 days ago", "AI-TEST-SAMPLE-1", false),
            AiHistoryItem("HIST-05", "USR-2026-901", AiActivityType.REVISION, "मौलिक अधिकार क्विक रिवीजन", "अनुच्छेद 12-35, 5 रिटें, आपातकाल प्रभाव", "4 days ago", "AI-REV-SAMPLE-1", true),
            AiHistoryItem("HIST-06", "USR-2026-901", AiActivityType.STUDY_PLANNER, "RRB NTPC 4-Hour Daily Plan", "Target May 2026 • 5 Schedule Blocks", "5 days ago", "PLAN-SAMPLE-1", false)
        )
    )
    val aiHistory: StateFlow<List<AiHistoryItem>> = _aiHistory.asStateFlow()

    // AI Content Review Queue (For Authorized Roles: SUPER_ADMIN, EXAM_ADMIN, TEST_CREATOR, CONTENT_ADMIN)
    private val _aiReviewSubmissions = MutableStateFlow<List<AiReviewSubmission>>(
        listOf(
            AiReviewSubmission(
                id = "REV-SUB-01",
                contentId = "AI-NOTE-SAMPLE-1",
                contentType = "NOTE",
                title = "न्यूटन के गति नियम एवं संवेग संरक्षण",
                authorStudentName = "Aman Kumar Sharma",
                authorStudentId = "USR-2026-901",
                examCategory = ExamCategory.RAILWAY,
                subject = "General Science",
                status = ReviewStatus.REVIEW,
                submittedAt = "2026-02-14 11:00"
            )
        )
    )
    val aiReviewSubmissions: StateFlow<List<AiReviewSubmission>> = _aiReviewSubmissions.asStateFlow()

    // Membership Plans
    private val _membershipPlans = MutableStateFlow<List<MembershipPlan>>(
        listOf(
            MembershipPlan(
                id = "PLAN-FREE",
                name = "FREE ASPIRANT",
                priceInr = 0,
                originalPriceInr = 0,
                validityMonths = 1,
                isPopular = false,
                features = listOf("3 Daily Practice Mocks", "Basic NCERT Notes", "Daily Current Affairs Quiz", "Standard Solutions")
            ),
            MembershipPlan(
                id = "PLAN-PRO-PASS",
                name = "CRACK EXAM PRO PASS",
                priceInr = 849,
                originalPriceInr = 1999,
                validityMonths = 12,
                isPopular = true,
                features = listOf(
                    "Unlimited 500+ Test Series (Railway, SSC, Banking, Police)",
                    "Full Detailed Video Solutions & Bilingual Explanations",
                    "AI Doubt Solver & AI Study Assistant (Unlimited)",
                    "Complete Printable PDF Notes & Formula Sheets",
                    "All India Rank, Percentile & AI Weakness Diagnostic",
                    "Offline Test Mode + Coaching Batch Sync"
                )
            ),
            MembershipPlan(
                id = "PLAN-LIFETIME",
                name = "LIFETIME SELECTION BATCH",
                priceInr = 2499,
                originalPriceInr = 5999,
                validityMonths = 36,
                isPopular = false,
                features = listOf(
                    "All Pro Pass Features for 3 Full Years",
                    "1-on-1 Faculty Mentorship Call Every Fortnight",
                    "Exclusive Handwritten Topper Notes Delivered to Home",
                    "Interview Guidance + Typing Test Simulator"
                )
            )
        )
    )
    val membershipPlans: StateFlow<List<MembershipPlan>> = _membershipPlans.asStateFlow()

    // Actions
    fun updateUserProfile(profile: UserProfile) {
        _currentUser.value = profile
        addAuditLog("UPDATED_PROFILE", profile.fullName)
    }

    fun verifyUserEmail() {
        _currentUser.value = _currentUser.value.copy(isVerified = true)
        addAuditLog("VERIFIED_EMAIL", _currentUser.value.email)
    }

    fun setSelectedExam(exam: ExamCategory) {
        _selectedExam.value = exam
    }

    fun switchRole(newRole: UserRole) {
        _currentUser.value = _currentUser.value.copy(role = newRole)
        addAuditLog("Switch role to ${newRole.displayName}", "User Profile")
    }

    fun addAuditLog(action: String, resource: String) {
        val newLog = AuditLogItem(
            id = "LOG-${System.currentTimeMillis()}",
            actor = _currentUser.value.fullName,
            role = _currentUser.value.role.displayName,
            action = action,
            resource = resource,
            timestamp = "Just now"
        )
        _auditLogs.value = listOf(newLog) + _auditLogs.value
    }

    fun addTest(test: ExamTest) {
        _tests.value = listOf(test) + _tests.value
        addAuditLog("CREATED_TEST", test.title)
    }

    fun updateTestStatus(testId: String, newStatus: ReviewStatus) {
        _tests.value = _tests.value.map {
            if (it.id == testId) it.copy(status = newStatus) else it
        }
        addAuditLog("UPDATED_TEST_STATUS ($newStatus)", "Test ID: $testId")
    }

    fun deleteTest(testId: String) {
        _tests.value = _tests.value.filterNot { it.id == testId }
        addAuditLog("DELETED_TEST", "Test ID: $testId")
    }

    fun addQuestion(question: Question) {
        _questionBank.value = listOf(question) + _questionBank.value
        addAuditLog("CREATED_QUESTION", "${question.subject} - ${question.topic}")
    }

    fun updateQuestionStatus(questionId: String, newStatus: ReviewStatus) {
        _questionBank.value = _questionBank.value.map {
            if (it.id == questionId) it.copy(reviewStatus = newStatus) else it
        }
        addAuditLog("UPDATED_QUESTION_STATUS ($newStatus)", "Question ID: $questionId")
    }

    fun addTeacher(teacher: TeacherRecord) {
        _teachers.value = listOf(teacher) + _teachers.value
        addAuditLog("ADDED_TEACHER", teacher.name)
    }

    fun updateCoachingProfile(profile: CoachingProfile) {
        _coachingProfile.value = profile
        addAuditLog("UPDATED_COACHING_PROFILE", profile.coachingName)
    }

    fun addTimetableEntry(entry: TimetableEntry) {
        _timetable.value = listOf(entry) + _timetable.value
        addAuditLog("ADDED_TIMETABLE", "${entry.batchName} - ${entry.subject}")
    }

    fun addFolder(folder: TestFolder) {
        _testFolders.value = listOf(folder) + _testFolders.value
        addAuditLog("CREATED_FOLDER", folder.name)
    }

    fun deleteFolder(folderId: String) {
        _testFolders.value = _testFolders.value.filterNot { it.id == folderId }
        addAuditLog("DELETED_FOLDER", "Folder ID: $folderId")
    }

    fun duplicateTest(testId: String) {
        val original = _tests.value.find { it.id == testId } ?: return
        val copy = original.copy(
            id = "TEST-COPY-${System.currentTimeMillis()}",
            title = "${original.title} (Copy)",
            status = ReviewStatus.DRAFT,
            lifecycleStatus = TestLifecycleStatus.DRAFT
        )
        _tests.value = listOf(copy) + _tests.value
        addAuditLog("DUPLICATE_TEST", copy.title)
    }

    fun updateTestLifecycle(testId: String, newStatus: TestLifecycleStatus) {
        _tests.value = _tests.value.map {
            if (it.id == testId) {
                it.copy(
                    lifecycleStatus = newStatus,
                    status = if (newStatus == TestLifecycleStatus.PUBLISHED) ReviewStatus.PUBLISHED else ReviewStatus.DRAFT
                )
            } else it
        }
        addAuditLog("UPDATE_TEST_LIFECYCLE ($newStatus)", "Test ID: $testId")
    }

    fun addBatch(batch: CoachingBatch) {
        _coachingBatches.value = listOf(batch) + _coachingBatches.value
        addAuditLog("CREATED_BATCH", batch.name)
    }

    fun addStudent(student: StudentRecord) {
        _coachingStudents.value = listOf(student) + _coachingStudents.value
        addAuditLog("ADMISSION_STUDENT", student.name)
    }

    fun recordAttendance(batchId: String, present: Int, absent: Int, leave: Int) {
        val batch = _coachingBatches.value.find { it.id == batchId }
        val record = AttendanceRecord(
            id = "ATT-${System.currentTimeMillis()}",
            date = "Today",
            batchId = batchId,
            batchName = batch?.name ?: "Batch $batchId",
            totalPresent = present,
            totalAbsent = absent,
            totalLeave = leave
        )
        _attendanceHistory.value = listOf(record) + _attendanceHistory.value
        addAuditLog("SUBMITTED_ATTENDANCE", "${batch?.name} (P:$present, A:$absent)")
    }

    fun submitTestAttempt(
        test: ExamTest,
        userAnswers: Map<String, List<Int>>,
        timeTakenSeconds: Int
    ): TestResult {
        var correctCount = 0
        var wrongCount = 0
        var skippedCount = 0
        var scoredMarks = 0.0

        for (q in test.questions) {
            val selected = userAnswers[q.id]
            if (selected == null || selected.isEmpty()) {
                skippedCount++
            } else if (selected == q.correctOptionIndices) {
                correctCount++
                scoredMarks += q.marks
            } else {
                wrongCount++
                scoredMarks -= (q.marks * test.negativeMarkRatio)
            }
        }

        val accuracy = if (correctCount + wrongCount > 0) {
            (correctCount.toDouble() / (correctCount + wrongCount)) * 100
        } else 0.0

        val totalCalculatedMarks = maxOf(0.0, scoredMarks)
        val rank = (50..350).random()
        val totalParticipants = 15420
        val percentile = (1.0 - (rank.toDouble() / totalParticipants)) * 100

        val result = TestResult(
            id = "RES-${System.currentTimeMillis()}",
            testId = test.id,
            testTitle = test.title,
            examCategory = test.examCategory,
            totalMarks = test.totalMarks,
            scoredMarks = totalCalculatedMarks,
            totalQuestions = test.questions.size,
            correctCount = correctCount,
            wrongCount = wrongCount,
            skippedCount = skippedCount,
            accuracyPercentage = accuracy,
            timeTakenSeconds = timeTakenSeconds,
            rank = rank,
            totalParticipants = totalParticipants,
            percentile = percentile,
            dateAttempted = "Today"
        )

        _results.value = listOf(result) + _results.value
        addAuditLog("SUBMITTED_TEST", test.title)
        return result
    }

    // AI Actions
    fun saveAiQuestionAnswer(item: AiQuestionAnswer) {
        _aiQuestionAnswers.value = listOf(item) + _aiQuestionAnswers.value.filterNot { it.id == item.id }
        addAiHistory(
            studentId = item.studentId,
            type = AiActivityType.QUESTION_ANSWER,
            title = item.question.take(40),
            subtitle = item.explanation.take(50),
            refId = item.id
        )
    }

    fun deleteAiQuestionAnswer(id: String) {
        _aiQuestionAnswers.value = _aiQuestionAnswers.value.filterNot { it.id == id }
        _aiHistory.value = _aiHistory.value.filterNot { it.referenceId == id }
    }

    fun saveAiDoubt(item: AiDoubtItem) {
        _aiDoubts.value = listOf(item) + _aiDoubts.value.filterNot { it.id == item.id }
        addAiHistory(
            studentId = item.studentId,
            type = AiActivityType.DOUBT_SOLVER,
            title = (item.textQuestion.ifBlank { "${item.subject} Doubt" }).take(40),
            subtitle = item.finalAnswer.take(50),
            refId = item.id
        )
    }

    fun deleteAiDoubt(id: String) {
        _aiDoubts.value = _aiDoubts.value.filterNot { it.id == id }
        _aiHistory.value = _aiHistory.value.filterNot { it.referenceId == id }
    }

    fun saveAiNoteDraft(note: AiNoteDraft) {
        _aiNotesDrafts.value = listOf(note) + _aiNotesDrafts.value.filterNot { it.id == note.id }
        addAiHistory(
            studentId = note.studentId,
            type = AiActivityType.NOTES,
            title = note.topic.take(40),
            subtitle = "${note.subject} • Status: ${note.status.name}",
            refId = note.id
        )
    }

    fun deleteAiNoteDraft(id: String) {
        _aiNotesDrafts.value = _aiNotesDrafts.value.filterNot { it.id == id }
        _aiReviewSubmissions.value = _aiReviewSubmissions.value.filterNot { it.contentId == id }
        _aiHistory.value = _aiHistory.value.filterNot { it.referenceId == id }
    }

    fun submitAiNoteForReview(noteId: String) {
        val note = _aiNotesDrafts.value.find { it.id == noteId } ?: return
        val updated = note.copy(status = ReviewStatus.REVIEW)
        _aiNotesDrafts.value = _aiNotesDrafts.value.map { if (it.id == noteId) updated else it }
        val submission = AiReviewSubmission(
            id = "REV-SUB-${System.currentTimeMillis()}",
            contentId = note.id,
            contentType = "NOTE",
            title = note.topic,
            authorStudentName = _currentUser.value.fullName,
            authorStudentId = _currentUser.value.id,
            examCategory = note.examCategory,
            subject = note.subject,
            status = ReviewStatus.REVIEW,
            submittedAt = "Just now"
        )
        _aiReviewSubmissions.value = listOf(submission) + _aiReviewSubmissions.value.filterNot { it.contentId == noteId }
        addAuditLog("SUBMITTED_AI_NOTE_FOR_REVIEW", note.topic)
    }

    fun saveAiQuizSession(session: AiQuizSession) {
        _aiQuizSessions.value = listOf(session) + _aiQuizSessions.value.filterNot { it.id == session.id }
        addAiHistory(
            studentId = session.studentId,
            type = AiActivityType.QUIZ,
            title = "Quiz: ${session.config.topic}".take(40),
            subtitle = "Score: ${session.score} • Accuracy: ${session.accuracyPercentage.toInt()}%",
            refId = session.id
        )
    }

    fun saveAiGeneratedTest(test: AiGeneratedTest) {
        _aiGeneratedTests.value = listOf(test) + _aiGeneratedTests.value.filterNot { it.id == test.id }
        addAiHistory(
            studentId = test.studentId,
            type = AiActivityType.TEST_GENERATOR,
            title = test.title.take(40),
            subtitle = "${test.questions.size} Questions • ${test.difficulty}",
            refId = test.id
        )
    }

    fun submitAiTestForReview(testId: String) {
        val test = _aiGeneratedTests.value.find { it.id == testId } ?: return
        val updated = test.copy(status = ReviewStatus.REVIEW)
        _aiGeneratedTests.value = _aiGeneratedTests.value.map { if (it.id == testId) updated else it }
        val submission = AiReviewSubmission(
            id = "REV-SUB-${System.currentTimeMillis()}",
            contentId = test.id,
            contentType = "TEST",
            title = test.title,
            authorStudentName = _currentUser.value.fullName,
            authorStudentId = _currentUser.value.id,
            examCategory = test.examCategory,
            subject = test.subject,
            status = ReviewStatus.REVIEW,
            submittedAt = "Just now"
        )
        _aiReviewSubmissions.value = listOf(submission) + _aiReviewSubmissions.value.filterNot { it.contentId == testId }
        addAuditLog("SUBMITTED_AI_TEST_FOR_REVIEW", test.title)
    }

    fun saveAiRevisionPackage(pkg: AiRevisionPackage) {
        _aiRevisionPackages.value = listOf(pkg) + _aiRevisionPackages.value.filterNot { it.id == pkg.id }
        addAiHistory(
            studentId = pkg.studentId,
            type = AiActivityType.REVISION,
            title = "Revision: ${pkg.topic}".take(40),
            subtitle = "${pkg.quickRevision.size} Key Points • ${pkg.importantFacts.size} Facts",
            refId = pkg.id
        )
    }

    fun saveAiStudyPlan(plan: AiStudyPlan) {
        _aiStudyPlans.value = listOf(plan) + _aiStudyPlans.value.filterNot { it.id == plan.id }
        addAiHistory(
            studentId = plan.studentId,
            type = AiActivityType.STUDY_PLANNER,
            title = "${plan.targetExam.name} Study Plan (${plan.dailyHours}h/day)".take(40),
            subtitle = "Target: ${plan.targetDate} • ${plan.scheduleDays.size} Days",
            refId = plan.id
        )
    }

    fun toggleStudyPlanDay(planId: String, dayNumber: Int) {
        _aiStudyPlans.value = _aiStudyPlans.value.map { plan ->
            if (plan.id == planId) {
                val updatedDays = plan.scheduleDays.map { day ->
                    if (day.dayNumber == dayNumber) day.copy(isCompleted = !day.isCompleted) else day
                }
                plan.copy(scheduleDays = updatedDays)
            } else plan
        }
    }

    fun addAiHistory(studentId: String, type: AiActivityType, title: String, subtitle: String, refId: String) {
        val item = AiHistoryItem(
            id = "HIST-${System.currentTimeMillis()}",
            studentId = studentId,
            activityType = type,
            title = title,
            subtitle = subtitle,
            timestamp = "Just now",
            referenceId = refId,
            isBookmarked = false
        )
        _aiHistory.value = listOf(item) + _aiHistory.value
    }

    fun deleteAiHistoryItem(id: String) {
        _aiHistory.value = _aiHistory.value.filterNot { it.id == id }
    }

    fun toggleBookmarkHistory(id: String) {
        _aiHistory.value = _aiHistory.value.map {
            if (it.id == id) it.copy(isBookmarked = !it.isBookmarked) else it
        }
    }

    // Authorized Review Actions (Admin & Test Creators only)
    fun approveAndPublishAiSubmission(submissionId: String) {
        val sub = _aiReviewSubmissions.value.find { it.id == submissionId } ?: return
        if (sub.contentType == "NOTE") {
            val noteDraft = _aiNotesDrafts.value.find { it.id == sub.contentId }
            if (noteDraft != null) {
                val publicNote = StudyNote(
                    id = "NOTE-PUB-${System.currentTimeMillis()}",
                    examCategory = noteDraft.examCategory,
                    subject = noteDraft.subject,
                    chapter = "AI Curated",
                    topic = noteDraft.topic,
                    title = noteDraft.topic,
                    summary = noteDraft.shortSummary,
                    content = noteDraft.detailedExplanation + "\n\n★ Important Facts:\n" + noteDraft.importantFacts.joinToString("\n") { "• $it" },
                    readMinutes = 5,
                    isBookmarked = false,
                    isProOnly = false
                )
                _notes.value = listOf(publicNote) + _notes.value
                _aiNotesDrafts.value = _aiNotesDrafts.value.map {
                    if (it.id == noteDraft.id) it.copy(status = ReviewStatus.PUBLISHED, isPublic = true) else it
                }
            }
        } else if (sub.contentType == "TEST") {
            val testDraft = _aiGeneratedTests.value.find { it.id == sub.contentId }
            if (testDraft != null) {
                val publicTest = ExamTest(
                    id = "TEST-PUB-${System.currentTimeMillis()}",
                    examCategory = testDraft.examCategory,
                    testSeriesId = "TS-RRB-01",
                    title = testDraft.title,
                    description = "Curated and verified AI test covering ${testDraft.topic}",
                    durationMinutes = testDraft.durationMinutes,
                    totalQuestions = testDraft.questions.size,
                    totalMarks = testDraft.totalMarks,
                    negativeMarkRatio = 0.33,
                    languages = listOf("Hindi", "English"),
                    sections = listOf(testDraft.subject),
                    questions = testDraft.questions.map { it.copy(reviewStatus = ReviewStatus.PUBLISHED) },
                    status = ReviewStatus.PUBLISHED,
                    lifecycleStatus = TestLifecycleStatus.PUBLISHED
                )
                _tests.value = listOf(publicTest) + _tests.value
                _aiGeneratedTests.value = _aiGeneratedTests.value.map {
                    if (it.id == testDraft.id) it.copy(status = ReviewStatus.PUBLISHED, isPublic = true) else it
                }
            }
        }
        _aiReviewSubmissions.value = _aiReviewSubmissions.value.map {
            if (it.id == submissionId) it.copy(status = ReviewStatus.PUBLISHED) else it
        }
        addAuditLog("APPROVED_AND_PUBLISHED_AI_CONTENT", sub.title)
    }

    fun rejectAiSubmission(submissionId: String, feedback: String) {
        val sub = _aiReviewSubmissions.value.find { it.id == submissionId } ?: return
        _aiReviewSubmissions.value = _aiReviewSubmissions.value.map {
            if (it.id == submissionId) it.copy(status = ReviewStatus.DRAFT, reviewerFeedback = feedback) else it
        }
        addAuditLog("REJECTED_AI_CONTENT ($feedback)", sub.title)
    }

    private fun createSampleLiveTest(
        id: String,
        title: String,
        category: ExamCategory,
        seriesId: String,
        duration: Int,
        totalQ: Int,
        totalMarks: Double,
        negRatio: Double
    ): ExamTest {
        return ExamTest(
            id = id,
            examCategory = category,
            testSeriesId = seriesId,
            title = title,
            description = "Strict exam simulation according to the latest 2026 TCS exam pattern with real negative marking and section bifurcation.",
            durationMinutes = duration,
            totalQuestions = totalQ,
            totalMarks = totalMarks,
            negativeMarkRatio = negRatio,
            languages = listOf("Hindi", "English"),
            sections = listOf("General Awareness", "Mathematics", "Reasoning Ability", "General Science"),
            questions = getSampleTestQuestions(category)
        )
    }

    private fun getSampleTestQuestions(category: ExamCategory): List<Question> {
        return listOf(
            Question(
                id = "Q-01",
                questionHindi = "भारत के संविधान में समवर्ती सूची (Concurrent List) की संकल्पना किस देश के संविधान से ली गई है?",
                questionEnglish = "From which country's constitution was the concept of the 'Concurrent List' adopted in the Indian Constitution?",
                optionsHindi = listOf("यू.एस.ए. (USA)", "कनाडा (Canada)", "ऑस्ट्रेलिया (Australia)", "जर्मनी (Germany)"),
                optionsEnglish = listOf("USA", "Canada", "Australia", "Germany"),
                correctOptionIndices = listOf(2),
                explanationHindi = "भारतीय संविधान में समवर्ती सूची (सातवीं अनुसूची) ऑस्ट्रेलिया के संविधान से ली गई है। इस पर केंद्र और राज्य दोनों विधि बना सकते हैं।",
                explanationEnglish = "The Concurrent List concept is borrowed from the Australian Constitution. Both Centre and States can legislate on it.",
                subject = "General Awareness",
                chapter = "Indian Polity",
                topic = "Sources of Constitution",
                difficulty = "Medium",
                marks = 2.0,
                negativeMarks = 0.66
            ),
            Question(
                id = "Q-02",
                questionHindi = "यदि एक ट्रेन 72 किमी/घंटा की गति से चल रही है, तो वह 250 मीटर लंबे प्लेटफॉर्म को 20 सेकंड में पार करती है। ट्रेन की लंबाई ज्ञात कीजिए?",
                questionEnglish = "If a train is running at a speed of 72 km/h and crosses a 250 m long platform in 20 seconds, what is the length of the train?",
                optionsHindi = listOf("150 मीटर", "200 मीटर", "180 मीटर", "220 मीटर"),
                optionsEnglish = listOf("150 meters", "200 meters", "180 meters", "220 meters"),
                correctOptionIndices = listOf(0),
                explanationHindi = "गति = 72 × (5/18) = 20 m/s। कुल दूरी = गति × समय = 20 × 20 = 400 मीटर। ट्रेन की लंबाई = 400 - 250 = 150 मीटर।",
                explanationEnglish = "Speed = 72 * (5/18) = 20 m/s. Total distance = 20 * 20 = 400 m. Train length = 400 - 250 = 150 m.",
                subject = "Mathematics",
                chapter = "Speed, Time & Distance",
                topic = "Trains",
                difficulty = "Easy",
                marks = 2.0,
                negativeMarks = 0.66
            ),
            Question(
                id = "Q-03",
                questionHindi = "ध्वनि की गति (Speed of Sound) निम्नलिखित में से किस माध्यम में सर्वाधिक होती है?",
                questionEnglish = "In which of the following media does sound travel at the highest speed?",
                optionsHindi = listOf("वायु (Air)", "जल (Water)", "स्टील / ठोस (Steel/Solid)", "निर्वात (Vacuum)"),
                optionsEnglish = listOf("Air", "Water", "Steel / Solid", "Vacuum"),
                correctOptionIndices = listOf(2),
                explanationHindi = "ध्वनि एक यांत्रिक तरंग (mechanical wave) है जिसे माध्यम की आवश्यकता होती है। ठोसों में इसका वेग अधिकतम (स्टील में लगभग 5960 m/s) होता है और निर्वात में यह गमन नहीं कर सकती।",
                explanationEnglish = "Sound is a mechanical wave requiring medium. Speed is highest in solids (steel ~5960 m/s), and it cannot travel in a vacuum.",
                subject = "General Science",
                chapter = "Physics",
                topic = "Sound Waves",
                difficulty = "Easy",
                marks = 2.0,
                negativeMarks = 0.66
            ),
            Question(
                id = "Q-04",
                questionHindi = "दी गई श्रृंखला में लुप्त पद ज्ञात कीजिए: 4, 9, 25, 49, 121, ?",
                questionEnglish = "Find the missing term in the given series: 4, 9, 25, 49, 121, ?",
                optionsHindi = listOf("144", "169", "196", "225"),
                optionsEnglish = listOf("144", "169", "196", "225"),
                correctOptionIndices = listOf(1),
                explanationHindi = "श्रृंखला अभाज्य संख्याओं (Prime numbers) के वर्ग हैं: 2²=4, 3²=9, 5²=25, 7²=49, 11²=121, अगली अभाज्य संख्या 13² = 169 होगी।",
                explanationEnglish = "The sequence represents squares of consecutive prime numbers: 2, 3, 5, 7, 11, and the next is 13² = 169.",
                subject = "Reasoning Ability",
                chapter = "Number Series",
                topic = "Prime Squares",
                difficulty = "Medium",
                marks = 2.0,
                negativeMarks = 0.66
            ),
            Question(
                id = "Q-05",
                questionHindi = "हाल ही में घोषित 'प्रधानमंत्री गति शक्ति राष्ट्रीय मास्टर प्लान' का प्राथमिक उद्देश्य क्या है?",
                questionEnglish = "What is the primary objective of the PM Gati Shakti National Master Plan?",
                optionsHindi = listOf(
                    "डिजिटल मुद्रा को बढ़ावा देना",
                    "मल्टी-मॉडल कनेक्टिविटी और लॉजिस्टिक्स इन्फ्रास्ट्रक्चर",
                    "कृषि ऋण माफी योजना",
                    "अंतरिक्ष अनुसंधान में सुधार"
                ),
                optionsEnglish = listOf(
                    "Promoting digital currency",
                    "Multi-modal connectivity & logistics infrastructure",
                    "Agricultural loan waiver",
                    "Space research improvement"
                ),
                correctOptionIndices = listOf(1),
                explanationHindi = "पीएम गति शक्ति योजना भारत में 16 मंत्रालयों को एक डिजिटल प्लेटफॉर्म पर जोड़कर मल्टीमॉडल कनेक्टिविटी बुनियादी ढांचे का त्वरित विकास करती है।",
                explanationEnglish = "PM Gati Shakti integrates 16 ministries on a digital platform for coordinated multimodal connectivity infrastructure.",
                subject = "Current Affairs",
                chapter = "Government Schemes",
                topic = "Infrastructure Policy",
                difficulty = "Medium",
                marks = 2.0,
                negativeMarks = 0.66
            )
        )
    }

    private fun getSampleQuestionBank(): List<Question> {
        val testQ = getSampleTestQuestions(ExamCategory.RAILWAY)
        val extra = listOf(
            Question(
                id = "QB-101",
                questionHindi = "कौन सा विटामिन रक्त का थक्का जमने (Blood Clotting) के लिए आवश्यक है?",
                questionEnglish = "Which vitamin is essential for blood clotting?",
                optionsHindi = listOf("विटामिन A", "विटामिन C", "विटामिन K", "विटामिन D"),
                optionsEnglish = listOf("Vitamin A", "Vitamin C", "Vitamin K", "Vitamin D"),
                correctOptionIndices = listOf(2),
                explanationHindi = "विटामिन K प्रोथ्रोम्बिन के संश्लेषण में सहायक होता है जो रक्त का थक्का जमाने के लिए आवश्यक है।",
                explanationEnglish = "Vitamin K synthesizes prothrombin required for blood coagulation.",
                subject = "General Science",
                chapter = "Biology",
                topic = "Vitamins & Deficiencies",
                difficulty = "Easy"
            ),
            Question(
                id = "QB-102",
                questionHindi = "प्रसिद्ध काजीरंगा राष्ट्रीय उद्यान किस राज्य में स्थित है और किसके लिए प्रसिद्ध है?",
                questionEnglish = "In which state is Kaziranga National Park located and what is it famous for?",
                optionsHindi = listOf("असम (एक सींग वाला गैंडा)", "पश्चिम बंगाल (रॉयल बंगाल टाइगर)", "केरल (हाथी)", "गुजरात (एशियाई शेर)"),
                optionsEnglish = listOf("Assam (One-horned Rhino)", "West Bengal (Bengal Tiger)", "Kerala (Elephant)", "Gujarat (Asiatic Lion)"),
                correctOptionIndices = listOf(0),
                explanationHindi = "काजीरंगा राष्ट्रीय उद्यान असम में स्थित है और यह विश्व प्रसिद्ध एक सींग वाले गैंडे का प्रमुख निवास स्थान है।",
                explanationEnglish = "Kaziranga National Park is located in Assam, famous for one-horned rhinoceros.",
                subject = "General Awareness",
                chapter = "Geography & Ecology",
                topic = "National Parks of India",
                difficulty = "Easy"
            )
        )
        return testQ + extra
    }
}

package com.example.data

import com.example.BuildConfig
import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
class SupabaseAuthService(context:Context){
 private val prefs=context.getSharedPreferences("crack_exam_auth",Context.MODE_PRIVATE); private val client=OkHttpClient(); private val type="application/json".toMediaType(); private val base=BuildConfig.SUPABASE_URL.trimEnd('/'); private val key=BuildConfig.SUPABASE_ANON_KEY
 fun userId():String?=prefs.getString("user_id",null)
 fun hasSession():Boolean=!prefs.getString("access_token",null).isNullOrBlank()
 fun accessToken():String?=prefs.getString("access_token",null)
 fun signIn(email:String,password:String)=request("/auth/v1/token?grant_type=password",JSONObject().apply{put("email",email.trim());put("password",password)})
 fun signUp(name:String,mobile:String,email:String,password:String)=request("/auth/v1/signup",JSONObject().apply{put("email",email.trim());put("password",password);put("data",JSONObject().apply{put("full_name",name);put("mobile",mobile)})})
 fun signOut(){prefs.edit().clear().apply()}
 private fun request(path:String,payload:JSONObject):Result<String>{ if(base.isBlank()||key.isBlank()) return Result.failure(IllegalStateException("Supabase अभी configure नहीं है।")); return runCatching{val r=Request.Builder().url(base+path).addHeader("apikey",key).addHeader("Content-Type","application/json").post(payload.toString().toRequestBody(type)).build();client.newCall(r).execute().use{res->val b=res.body?.string().orEmpty();if(!res.isSuccessful)error(runCatching{JSONObject(b).optString("msg").ifBlank{JSONObject(b).optString("error_description")}}.getOrNull().orEmpty().ifBlank{"Authentication failed (${res.code})"});val j=JSONObject(b);val t=j.optString("access_token");if(t.isNotBlank())prefs.edit().putString("access_token",t).putString("user_id",j.optJSONObject("user")?.optString("id")).apply();b}}
}

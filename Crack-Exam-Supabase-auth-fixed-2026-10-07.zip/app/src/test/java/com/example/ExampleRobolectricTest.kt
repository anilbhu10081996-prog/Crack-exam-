package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.CrackExamRepository
import com.example.data.ai.AiStudyServiceImpl
import com.example.model.*
import com.example.viewmodel.CrackExamViewModel
import com.example.viewmodel.ScreenDestination
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Crack Exam", appName)
    }

    @Test
    fun `verify student role permissions`() {
        assertTrue(RolePermissions.hasPermission(UserRole.STUDENT, Permission.TEST_ATTEMPT))
        assertTrue(RolePermissions.hasPermission(UserRole.STUDENT, Permission.TEST_VIEW))
        assertFalse(RolePermissions.hasPermission(UserRole.STUDENT, Permission.ADMIN_DASHBOARD))
        assertFalse(RolePermissions.hasPermission(UserRole.STUDENT, Permission.TEST_CREATE))
    }

    @Test
    fun `verify super admin has full permissions`() {
        assertTrue(RolePermissions.hasPermission(UserRole.SUPER_ADMIN, Permission.ADMIN_DASHBOARD))
        assertTrue(RolePermissions.hasPermission(UserRole.SUPER_ADMIN, Permission.TEST_CREATE))
        assertTrue(RolePermissions.hasPermission(UserRole.SUPER_ADMIN, Permission.TEST_DELETE))
        assertTrue(RolePermissions.hasPermission(UserRole.SUPER_ADMIN, Permission.AUDIT_VIEW))
    }

    @Test
    fun `verify access denied redirection for unauthorized screen`() {
        val viewModel = CrackExamViewModel()
        // Default role is STUDENT
        assertEquals(UserRole.STUDENT, viewModel.currentUser.value.role)

        // Attempt navigation to Admin Dashboard
        viewModel.navigateTo(ScreenDestination.AdminDashboard)
        assertTrue(viewModel.currentScreen.value is ScreenDestination.AccessDenied)

        // Switch to SUPER_ADMIN and navigate again
        viewModel.switchRole(UserRole.SUPER_ADMIN)
        viewModel.navigateTo(ScreenDestination.AdminDashboard)
        assertEquals(ScreenDestination.AdminDashboard, viewModel.currentScreen.value)
    }

    @Test
    fun `verify AI Service generates question answer and doubt solving`() = runBlocking {
        val service = AiStudyServiceImpl()

        // 1. Question Answer
        val qaResult = service.generateQuestionAnswer("USR-TEST-1", "भारतीय संविधान क्या है?", "Hindi")
        assertTrue(qaResult.isSuccess)
        val qa = qaResult.getOrThrow()
        assertNotNull(qa.explanation)
        assertTrue(qa.importantPoints.isNotEmpty())
        assertTrue(qa.examFacts.isNotEmpty())

        // 2. Doubt Solver
        val doubtResult = service.solveDoubt("USR-TEST-1", "ट्रेन गति समस्या", "Mathematics", "Speed & Distance", null)
        assertTrue(doubtResult.isSuccess)
        val doubt = doubtResult.getOrThrow()
        assertTrue(doubt.stepByStepExplanation.isNotEmpty())
        assertTrue(doubt.shortcutTrick.isNotEmpty())
    }

    @Test
    fun `verify AI Notes draft status and review publication workflow`() = runBlocking {
        val service = AiStudyServiceImpl()
        val repository = CrackExamRepository()
        val initialPublicNotesCount = repository.notes.value.size

        // 1. AI generates note draft
        val noteResult = service.generateNotesDraft(
            studentId = "USR-2026-901",
            topic = "भारत के प्रमुख टाइगर रिजर्व",
            subject = "Geography",
            examCategory = ExamCategory.RAILWAY
        )
        assertTrue(noteResult.isSuccess)
        val draft = noteResult.getOrThrow()
        assertEquals(ReviewStatus.DRAFT, draft.status)
        assertFalse(draft.isPublic)

        // 2. Save draft into student's private collection
        repository.saveAiNoteDraft(draft)
        // Verify public notes count did NOT change!
        assertEquals(initialPublicNotesCount, repository.notes.value.size)

        // 3. Student submits note for review
        repository.submitAiNoteForReview(draft.id)
        val submittedDraft = repository.aiNotesDrafts.value.find { it.id == draft.id }
        assertEquals(ReviewStatus.REVIEW, submittedDraft?.status)

        // 4. Authorized admin approves and publishes
        val submission = repository.aiReviewSubmissions.value.find { it.contentId == draft.id }
        assertNotNull(submission)
        repository.approveAndPublishAiSubmission(submission!!.id)

        // 5. Verify public notes library now has the newly published note
        assertEquals(initialPublicNotesCount + 1, repository.notes.value.size)
    }

    @Test
    fun `verify AI Quiz scoring and student history isolation`() = runBlocking {
        val service = AiStudyServiceImpl()
        val repository = CrackExamRepository()
        val studentId = repository.currentUser.value.id

        val quizConfig = AiQuizConfig(
            topic = "भारतीय संविधान",
            subject = "Polity",
            questionCount = 5,
            questionType = "MCQ"
        )
        val quizResult = service.generateQuiz(studentId, quizConfig)
        assertTrue(quizResult.isSuccess)
        val questions = quizResult.getOrThrow()
        assertEquals(5, questions.size)

        val completedSession = AiQuizSession(
            id = "QZ-SESS-TEST",
            studentId = studentId,
            config = quizConfig,
            questions = questions,
            userAnswers = mapOf(0 to 0, 1 to 1),
            isSubmitted = true,
            score = 4.0,
            correctCount = 2,
            wrongCount = 0,
            accuracyPercentage = 100.0,
            timeTakenSeconds = 45,
            completedAt = "Just now"
        )
        repository.saveAiQuizSession(completedSession)

        // Verify history contains quiz
        val history = repository.aiHistory.value.filter { it.studentId == studentId }
        assertTrue(history.any { it.activityType == AiActivityType.QUIZ })

        // Check another student isolation
        val otherStudentHistory = repository.aiHistory.value.filter { it.studentId == "DIFFERENT-STUDENT-ID" }
        assertTrue(otherStudentHistory.isEmpty())
    }

    @Test
    fun `verify AI Study Planner and day completion toggle`() = runBlocking {
        val service = AiStudyServiceImpl()
        val repository = CrackExamRepository()
        val studentId = repository.currentUser.value.id

        val planResult = service.generateStudyPlan(
            studentId = studentId,
            exam = ExamCategory.RAILWAY,
            targetDate = "2026-06-30",
            dailyHours = 4,
            subjects = listOf("Mathematics", "General Science"),
            level = "Intermediate"
        )
        assertTrue(planResult.isSuccess)
        val plan = planResult.getOrThrow()
        assertEquals(7, plan.scheduleDays.size)

        repository.saveAiStudyPlan(plan)
        val initialStatus = repository.aiStudyPlans.value.first().scheduleDays[1].isCompleted
        repository.toggleStudyPlanDay(plan.id, 2)
        val updatedStatus = repository.aiStudyPlans.value.first().scheduleDays[1].isCompleted
        assertNotEquals(initialStatus, updatedStatus)
    }
}
